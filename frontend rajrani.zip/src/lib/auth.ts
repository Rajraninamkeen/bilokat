import { cookies } from "next/headers";
import { db } from "@/db";
import { users, vendors, type User, type Vendor } from "@/db/schema";
import { eq } from "drizzle-orm";
import { ensureDatabaseReady } from "@/db/init";

export const SESSION_COOKIE_NAME = "bazaar_session_user";
export const DEFAULT_DEMO_USER_ID = "usr_priya"; // Sarah Jenkins (Customer)

export interface AuthSession {
  user: User;
  vendor: Vendor | null;
}

export async function getCurrentUser(): Promise<AuthSession | null> {
  await ensureDatabaseReady();

  const cookieStore = await cookies();
  const userIdCookie = cookieStore.get(SESSION_COOKIE_NAME)?.value;
  const targetUserId = userIdCookie || DEFAULT_DEMO_USER_ID;

  try {
    const userResult = await db.select().from(users).where(eq(users.id, targetUserId)).limit(1);
    const user = userResult[0];

    if (!user) {
      // Fallback to first user in database
      const firstUser = (await db.select().from(users).limit(1))[0];
      if (!firstUser) return null;
      
      const vendorResult = await db.select().from(vendors).where(eq(vendors.userId, firstUser.id)).limit(1);
      return {
        user: firstUser,
        vendor: vendorResult[0] || null,
      };
    }

    const vendorResult = await db.select().from(vendors).where(eq(vendors.userId, user.id)).limit(1);

    return {
      user,
      vendor: vendorResult[0] || null,
    };
  } catch (err) {
    console.error("getCurrentUser error:", err);
    return null;
  }
}

import { db } from "./index";
import { users, products, categories, vendors } from "./schema";
import { seedDatabase } from "./seed";
import { sql } from "drizzle-orm";

let isInitialized = false;

export async function ensureDatabaseReady() {
  if (isInitialized) return;

  try {
    // Check if users table exists and has data
    const existingUsers = await db.select({ count: sql<number>`count(*)` }).from(users);
    const count = Number(existingUsers[0]?.count || 0);

    if (count === 0) {
      console.log("No users found. Running initial seed...");
      await seedDatabase();
    }
    isInitialized = true;
  } catch (error) {
    console.error("Database ready check failed or table missing, attempting seed...", error);
    try {
      await seedDatabase();
      isInitialized = true;
    } catch (seedErr) {
      console.error("Seed failed:", seedErr);
    }
  }
}

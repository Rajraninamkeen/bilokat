import "dotenv/config";
import { seedDatabase } from "./seed";
import { pool } from "./index";

async function main() {
  try {
    await seedDatabase();
  } catch (err) {
    console.error("Seed error", err);
  } finally {
    await pool.end();
  }
}

main();

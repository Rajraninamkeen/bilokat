import { pgTable, text, timestamp, boolean, integer, doublePrecision, jsonb } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

// 1. Users table (Customers, Sellers, Admins)
export const users = pgTable("users", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash"),
  role: text("role").notNull().default("customer"), // 'customer' | 'seller' | 'admin'
  avatar: text("avatar"),
  phone: text("phone"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// 2. Vendors table (Store profile, settings, commission)
export const vendors = pgTable("vendors", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  storeName: text("store_name").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description"),
  logoUrl: text("logo_url"),
  bannerUrl: text("banner_url"),
  contactEmail: text("contact_email"),
  contactPhone: text("contact_phone"),
  status: text("status").notNull().default("active"), // 'active' | 'pending_approval' | 'suspended'
  isVerified: boolean("is_verified").notNull().default(true),
  commissionRate: doublePrecision("commission_rate").default(10.0), // % cut taken by marketplace
  bankName: text("bank_name"),
  bankAccountNumber: text("bank_account_number"),
  routingNumber: text("routing_number"),
  totalSales: doublePrecision("total_sales").default(0),
  rating: doublePrecision("rating").default(4.8),
  reviewCount: integer("review_count").default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// 3. Categories table
export const categories = pgTable("categories", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description"),
  icon: text("icon"), // Icon name (e.g. 'Laptop', 'Shirt', 'Home', 'Sparkles', 'Dumbbell', 'Coffee')
  imageUrl: text("image_url"),
  parentId: text("parent_id"), // for nested subcategories
  isFeatured: boolean("is_featured").default(false),
  displayOrder: integer("display_order").default(0),
});

// 4. Products table
export const products = pgTable("products", {
  id: text("id").primaryKey(),
  vendorId: text("vendor_id").notNull().references(() => vendors.id, { onDelete: "cascade" }),
  categoryId: text("category_id").notNull().references(() => categories.id, { onDelete: "restrict" }),
  title: text("title").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description").notNull(),
  shortDescription: text("short_description"),
  price: doublePrecision("price").notNull(),
  compareAtPrice: doublePrecision("compare_at_price"), // Original / strike-through price
  costPrice: doublePrecision("cost_price"), // Internal vendor cost
  sku: text("sku"),
  stockQuantity: integer("stock_quantity").notNull().default(10),
  images: jsonb("images").$type<string[]>().default([]),
  tags: jsonb("tags").$type<string[]>().default([]),
  attributes: jsonb("attributes").$type<Record<string, string[] | string>>().default({}),
  status: text("status").notNull().default("active"), // 'active' | 'draft' | 'archived' | 'out_of_stock'
  isFeatured: boolean("is_featured").default(false),
  isApproved: boolean("is_approved").default(true),
  rating: doublePrecision("rating").default(5.0),
  reviewCount: integer("review_count").default(0),
  salesCount: integer("sales_count").default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// 5. Coupons table
export const coupons = pgTable("coupons", {
  id: text("id").primaryKey(),
  code: text("code").notNull().unique(),
  description: text("description"),
  discountType: text("discount_type").notNull().default("percentage"), // 'percentage' | 'fixed'
  discountValue: doublePrecision("discount_value").notNull(), // e.g. 15 for 15% or 20 for $20
  minSpend: doublePrecision("min_spend").default(0),
  maxDiscount: doublePrecision("max_discount"),
  vendorId: text("vendor_id"), // null = store-wide coupon, or vendor-specific
  usageLimit: integer("usage_limit").default(1000),
  timesUsed: integer("times_used").default(0),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// 6. Orders table (Master platform order)
export const orders = pgTable("orders", {
  id: text("id").primaryKey(),
  orderNumber: text("order_number").notNull().unique(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  status: text("status").notNull().default("processing"), // 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled' | 'refunded'
  subtotal: doublePrecision("subtotal").notNull(),
  discountTotal: doublePrecision("discount_total").default(0),
  couponCode: text("coupon_code"),
  shippingFee: doublePrecision("shipping_fee").default(0),
  tax: doublePrecision("tax").default(0),
  grandTotal: doublePrecision("grand_total").notNull(),
  platformCommissionTotal: doublePrecision("platform_commission_total").default(0),
  paymentStatus: text("payment_status").notNull().default("paid"), // 'paid' | 'pending' | 'failed' | 'refunded'
  paymentMethod: text("payment_method").notNull().default("credit_card"),
  shippingAddress: jsonb("shipping_address").$type<{
    fullName: string;
    email: string;
    phone: string;
    addressLine1: string;
    addressLine2?: string;
    city: string;
    state: string;
    postalCode: string;
    country: string;
  }>().notNull(),
  billingAddress: jsonb("billing_address").$type<{
    fullName: string;
    addressLine1: string;
    city: string;
    state: string;
    postalCode: string;
    country: string;
  }>(),
  shippingMethod: text("shipping_method").default("standard"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// 7. Order Items (vendor split fulfillments)
export const orderItems = pgTable("order_items", {
  id: text("id").primaryKey(),
  orderId: text("order_id").notNull().references(() => orders.id, { onDelete: "cascade" }),
  vendorId: text("vendor_id").notNull().references(() => vendors.id, { onDelete: "restrict" }),
  productId: text("product_id").notNull().references(() => products.id, { onDelete: "restrict" }),
  productTitle: text("product_title").notNull(),
  productImage: text("product_image"),
  selectedVariant: jsonb("selected_variant").$type<Record<string, string>>(),
  unitPrice: doublePrecision("unit_price").notNull(),
  quantity: integer("quantity").notNull().default(1),
  totalPrice: doublePrecision("total_price").notNull(),
  vendorCommissionRate: doublePrecision("vendor_commission_rate").default(10.0),
  platformCommission: doublePrecision("platform_commission").default(0),
  vendorEarnings: doublePrecision("vendor_earnings").default(0),
  status: text("status").notNull().default("processing"), // 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled'
  carrierName: text("carrier_name"),
  trackingNumber: text("tracking_number"),
  shippedAt: timestamp("shipped_at"),
  deliveredAt: timestamp("delivered_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// 8. Reviews table
export const reviews = pgTable("reviews", {
  id: text("id").primaryKey(),
  productId: text("product_id").notNull().references(() => products.id, { onDelete: "cascade" }),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  vendorId: text("vendor_id").notNull().references(() => vendors.id, { onDelete: "cascade" }),
  rating: integer("rating").notNull(), // 1 to 5
  title: text("title"),
  comment: text("comment").notNull(),
  isVerifiedPurchase: boolean("is_verified_purchase").default(true),
  helpfulCount: integer("helpful_count").default(0),
  vendorReply: text("vendor_reply"),
  vendorRepliedAt: timestamp("vendor_replied_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// 9. Wishlists table
export const wishlists = pgTable("wishlists", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  productId: text("product_id").notNull().references(() => products.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// 10. Cart items (Database cart storage)
export const cartItems = pgTable("cart_items", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull(), // can be user ID or guest session token
  productId: text("product_id").notNull().references(() => products.id, { onDelete: "cascade" }),
  vendorId: text("vendor_id").notNull().references(() => vendors.id, { onDelete: "cascade" }),
  quantity: integer("quantity").notNull().default(1),
  selectedVariant: jsonb("selected_variant").$type<Record<string, string>>(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// 11. Vendor payouts table
export const vendorPayouts = pgTable("vendor_payouts", {
  id: text("id").primaryKey(),
  vendorId: text("vendor_id").notNull().references(() => vendors.id, { onDelete: "cascade" }),
  amount: doublePrecision("amount").notNull(),
  fee: doublePrecision("fee").default(0),
  netAmount: doublePrecision("net_amount").notNull(),
  status: text("status").notNull().default("completed"), // 'completed' | 'pending' | 'rejected'
  method: text("method").default("bank_transfer"), // 'bank_transfer' | 'stripe' | 'paypal'
  referenceNumber: text("reference_number"),
  notes: text("notes"),
  processedAt: timestamp("processed_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// 12. Platform Settings table
export const platformSettings = pgTable("platform_settings", {
  id: text("id").primaryKey(),
  key: text("key").notNull().unique(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Relations definitions
export const usersRelations = relations(users, ({ one, many }) => ({
  vendor: one(vendors, {
    fields: [users.id],
    references: [vendors.userId],
  }),
  orders: many(orders),
  reviews: many(reviews),
  wishlists: many(wishlists),
}));

export const vendorsRelations = relations(vendors, ({ one, many }) => ({
  user: one(users, {
    fields: [vendors.userId],
    references: [users.id],
  }),
  products: many(products),
  orderItems: many(orderItems),
  reviews: many(reviews),
  payouts: many(vendorPayouts),
}));

export const categoriesRelations = relations(categories, ({ one, many }) => ({
  products: many(products),
  parent: one(categories, {
    fields: [categories.parentId],
    references: [categories.id],
    relationName: "subcategories",
  }),
  subcategories: many(categories, {
    relationName: "subcategories",
  }),
}));

export const productsRelations = relations(products, ({ one, many }) => ({
  vendor: one(vendors, {
    fields: [products.vendorId],
    references: [vendors.id],
  }),
  category: one(categories, {
    fields: [products.categoryId],
    references: [categories.id],
  }),
  reviews: many(reviews),
  orderItems: many(orderItems),
  wishlists: many(wishlists),
}));

export const ordersRelations = relations(orders, ({ one, many }) => ({
  user: one(users, {
    fields: [orders.userId],
    references: [users.id],
  }),
  items: many(orderItems),
}));

export const orderItemsRelations = relations(orderItems, ({ one, many }) => ({
  order: one(orders, {
    fields: [orderItems.orderId],
    references: [orders.id],
  }),
  vendor: one(vendors, {
    fields: [orderItems.vendorId],
    references: [vendors.id],
  }),
  product: one(products, {
    fields: [orderItems.productId],
    references: [products.id],
  }),
}));

export const reviewsRelations = relations(reviews, ({ one }) => ({
  product: one(products, {
    fields: [reviews.productId],
    references: [products.id],
  }),
  user: one(users, {
    fields: [reviews.userId],
    references: [users.id],
  }),
  vendor: one(vendors, {
    fields: [reviews.vendorId],
    references: [vendors.id],
  }),
}));

export const wishlistsRelations = relations(wishlists, ({ one }) => ({
  user: one(users, {
    fields: [wishlists.userId],
    references: [users.id],
  }),
  product: one(products, {
    fields: [wishlists.productId],
    references: [products.id],
  }),
}));

// Export inferred types
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export type Vendor = typeof vendors.$inferSelect;
export type InsertVendor = typeof vendors.$inferInsert;

export type Category = typeof categories.$inferSelect;
export type InsertCategory = typeof categories.$inferInsert;

export type Product = typeof products.$inferSelect;
export type InsertProduct = typeof products.$inferInsert;

export type Coupon = typeof coupons.$inferSelect;
export type InsertCoupon = typeof coupons.$inferInsert;

export type Order = typeof orders.$inferSelect;
export type InsertOrder = typeof orders.$inferInsert;

export type OrderItem = typeof orderItems.$inferSelect;
export type InsertOrderItem = typeof orderItems.$inferInsert;

export type Review = typeof reviews.$inferSelect;
export type InsertReview = typeof reviews.$inferInsert;

export type WishlistItem = typeof wishlists.$inferSelect;
export type CartItem = typeof cartItems.$inferSelect;
export type VendorPayout = typeof vendorPayouts.$inferSelect;
export type PlatformSetting = typeof platformSettings.$inferSelect;

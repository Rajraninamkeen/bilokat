"use client";

import React, { createContext, useContext, useState, useEffect, useCallback } from "react";
import { useAuth } from "./AuthContext";

interface WishlistContextType {
  wishlistProductIds: string[];
  wishlistItems: any[];
  toggleWishlist: (productId: string) => Promise<boolean>;
  isInWishlist: (productId: string) => boolean;
  wishlistCount: number;
  refreshWishlist: () => Promise<void>;
  isLoading: boolean;
}

const WishlistContext = createContext<WishlistContextType | undefined>(undefined);

export function WishlistProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const [wishlistItems, setWishlistItems] = useState<any[]>([]);
  const [wishlistProductIds, setWishlistProductIds] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const fetchWishlist = useCallback(async () => {
    if (!user) {
      setWishlistItems([]);
      setWishlistProductIds([]);
      return;
    }

    try {
      setIsLoading(true);
      const res = await fetch("/api/wishlist");
      if (res.ok) {
        const data = await res.json();
        const items = data.wishlist || [];
        setWishlistItems(items);
        setWishlistProductIds(items.map((i: any) => i.productId));
      }
    } catch (e) {
      console.error("Failed to fetch wishlist", e);
    } finally {
      setIsLoading(false);
    }
  }, [user]);

  useEffect(() => {
    fetchWishlist();
  }, [fetchWishlist]);

  const isInWishlist = (productId: string) => {
    return wishlistProductIds.includes(productId);
  };

  const toggleWishlist = async (productId: string): Promise<boolean> => {
    if (!user) {
      return false;
    }

    // Optimistic toggle
    const currentlyIn = wishlistProductIds.includes(productId);
    const newProductIds = currentlyIn
      ? wishlistProductIds.filter((id) => id !== productId)
      : [...wishlistProductIds, productId];

    setWishlistProductIds(newProductIds);

    try {
      const res = await fetch("/api/wishlist", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productId }),
      });

      if (res.ok) {
        const data = await res.json();
        fetchWishlist();
        return data.inWishlist;
      } else {
        // Rollback
        setWishlistProductIds(wishlistProductIds);
        return currentlyIn;
      }
    } catch (e) {
      // Rollback
      setWishlistProductIds(wishlistProductIds);
      return currentlyIn;
    }
  };

  return (
    <WishlistContext.Provider
      value={{
        wishlistProductIds,
        wishlistItems,
        toggleWishlist,
        isInWishlist,
        wishlistCount: wishlistProductIds.length,
        refreshWishlist: fetchWishlist,
        isLoading,
      }}
    >
      {children}
    </WishlistContext.Provider>
  );
}

export function useWishlist() {
  const context = useContext(WishlistContext);
  if (!context) {
    throw new Error("useWishlist must be used within a WishlistProvider");
  }
  return context;
}

"use client";

import React, { createContext, useContext, useState, useEffect, useMemo } from "react";

export interface CartItem {
  id: string;
  productId: string;
  vendorId: string;
  vendorName: string;
  title: string;
  price: number;
  image: string;
  quantity: number;
  selectedVariant?: Record<string, string>;
  maxStock?: number;
}

export interface AppliedCoupon {
  id: string;
  code: string;
  description: string | null;
  discountType: string;
  discountValue: number;
  discountAmount: number;
}

interface CartContextType {
  items: CartItem[];
  addItem: (product: {
    id: string;
    vendorId: string;
    vendorName?: string;
    title: string;
    price: number;
    images?: string[];
    stockQuantity?: number;
  }, quantity?: number, selectedVariant?: Record<string, string>) => void;
  removeItem: (itemId: string) => void;
  updateQuantity: (itemId: string, quantity: number) => void;
  clearCart: () => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  toggleCart: () => void;
  appliedCoupon: AppliedCoupon | null;
  applyCoupon: (code: string) => Promise<{ success: boolean; message: string }>;
  removeCoupon: () => void;
  subtotal: number;
  discount: number;
  shipping: number;
  tax: number;
  grandTotal: number;
  itemCount: number;
  freeShippingThreshold: number;
  freeShippingProgress: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);
const CART_STORAGE_KEY = "bilokat_store_cart";

export const INR = (n: number) =>
  "₹" + n.toLocaleString("en-IN", { minimumFractionDigits: n % 1 === 0 ? 0 : 2, maximumFractionDigits: 2 });

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [appliedCoupon, setAppliedCoupon] = useState<AppliedCoupon | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);

  // Free delivery above ₹499
  const freeShippingThreshold = 499;

  useEffect(() => {
    try {
      const saved = localStorage.getItem(CART_STORAGE_KEY);
      if (saved) setItems(JSON.parse(saved));
    } catch (e) {
      console.error("Failed to load cart", e);
    } finally {
      setIsLoaded(true);
    }
  }, []);

  useEffect(() => {
    if (isLoaded) {
      try {
        localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(items));
      } catch (e) {
        console.error("Failed to save cart", e);
      }
    }
  }, [items, isLoaded]);

  const addItem = (
    product: {
      id: string;
      vendorId: string;
      vendorName?: string;
      title: string;
      price: number;
      images?: string[];
      stockQuantity?: number;
    },
    quantity = 1,
    selectedVariant: Record<string, string> = {}
  ) => {
    const variantKey = Object.entries(selectedVariant)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([k, v]) => `${k}:${v}`)
      .join("-");
    const itemId = variantKey ? `${product.id}__${variantKey}` : product.id;

    setItems((prev) => {
      const existing = prev.find((i) => i.id === itemId);
      if (existing) {
        return prev.map((i) =>
          i.id === itemId ? { ...i, quantity: Math.min(i.quantity + quantity, product.stockQuantity || 99) } : i
        );
      }
      return [
        ...prev,
        {
          id: itemId,
          productId: product.id,
          vendorId: product.vendorId,
          vendorName: product.vendorName || "RAJRANI NAMKEEN CENTRE",
          title: product.title,
          price: product.price,
          image: product.images?.[0] || "/images/hero-namkeen.jpg",
          quantity,
          selectedVariant,
          maxStock: product.stockQuantity || 99,
        },
      ];
    });
    setIsCartOpen(true);
  };

  const removeItem = (itemId: string) => setItems((prev) => prev.filter((i) => i.id !== itemId));

  const updateQuantity = (itemId: string, quantity: number) => {
    if (quantity <= 0) return removeItem(itemId);
    setItems((prev) =>
      prev.map((i) => (i.id === itemId ? { ...i, quantity: Math.min(quantity, i.maxStock || 99) } : i))
    );
  };

  const clearCart = () => {
    setItems([]);
    setAppliedCoupon(null);
  };

  const toggleCart = () => setIsCartOpen((prev) => !prev);

  const subtotal = useMemo(() => items.reduce((acc, i) => acc + i.price * i.quantity, 0), [items]);
  const itemCount = useMemo(() => items.reduce((acc, i) => acc + i.quantity, 0), [items]);

  const discount = useMemo(() => {
    if (!appliedCoupon) return 0;
    if (appliedCoupon.discountType === "percentage") return (subtotal * appliedCoupon.discountValue) / 100;
    return Math.min(appliedCoupon.discountValue, subtotal);
  }, [appliedCoupon, subtotal]);

  // Standard delivery: free ≥ ₹499 else ₹49
  const shipping = useMemo(() => {
    if (items.length === 0) return 0;
    return subtotal >= freeShippingThreshold ? 0 : 49;
  }, [items.length, subtotal, freeShippingThreshold]);

  // GST 12% (bundled on taxable amount)
  const tax = useMemo(() => {
    if (items.length === 0) return 0;
    return Math.round(Math.max(0, subtotal - discount) * 0.12 * 100) / 100;
  }, [items.length, subtotal, discount]);

  const grandTotal = useMemo(() => {
    if (items.length === 0) return 0;
    return Math.round((Math.max(0, subtotal - discount) + shipping + tax) * 100) / 100;
  }, [items.length, subtotal, discount, shipping, tax]);

  const freeShippingProgress = useMemo(() => {
    if (subtotal >= freeShippingThreshold) return 100;
    return Math.min(100, Math.round((subtotal / freeShippingThreshold) * 100));
  }, [subtotal, freeShippingThreshold]);

  const applyCoupon = async (code: string) => {
    if (!code?.trim()) return { success: false, message: "Please enter a coupon code" };
    try {
      const res = await fetch("/api/coupons/validate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: code.trim(), subtotal }),
      });
      const data = await res.json();
      if (data.valid && data.coupon) {
        setAppliedCoupon(data.coupon);
        return {
          success: true,
          message: `Coupon "${data.coupon.code}" applied! You saved ₹${data.coupon.discountAmount.toFixed(0)}`,
        };
      }
      return { success: false, message: data.error || "Invalid coupon code" };
    } catch {
      return { success: false, message: "Failed to validate coupon" };
    }
  };

  const removeCoupon = () => setAppliedCoupon(null);

  return (
    <CartContext.Provider
      value={{
        items,
        addItem,
        removeItem,
        updateQuantity,
        clearCart,
        isCartOpen,
        setIsCartOpen,
        toggleCart,
        appliedCoupon,
        applyCoupon,
        removeCoupon,
        subtotal,
        discount,
        shipping,
        tax,
        grandTotal,
        itemCount,
        freeShippingThreshold,
        freeShippingProgress,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) throw new Error("useCart must be used within a CartProvider");
  return context;
}

"use client";

import React, { createContext, useContext, useState, useEffect, useCallback } from "react";

export interface DemoPersona {
  id: string;
  name: string;
  email: string;
  role: "customer" | "seller" | "admin";
  avatar: string | null;
  storeName: string | null;
  vendorId: string | null;
}

export interface UserSession {
  id: string;
  name: string;
  email: string;
  role: "customer" | "seller" | "admin";
  avatar: string | null;
  phone: string | null;
}

export interface VendorProfile {
  id: string;
  userId: string;
  storeName: string;
  slug: string;
  description: string | null;
  logoUrl: string | null;
  bannerUrl: string | null;
  contactEmail: string | null;
  contactPhone: string | null;
  status: string;
  isVerified: boolean;
  commissionRate: number;
  bankName?: string | null;
  bankAccountNumber?: string | null;
  routingNumber?: string | null;
  totalSales: number;
  rating: number;
  reviewCount: number;
}

interface AuthContextType {
  user: UserSession | null;
  vendor: VendorProfile | null;
  demoPersonas: DemoPersona[];
  isLoading: boolean;
  isAuthModalOpen: boolean;
  authModalTab: "login" | "register";
  openAuthModal: (tab?: "login" | "register") => void;
  closeAuthModal: () => void;
  switchUser: (userId: string) => Promise<void>;
  refreshSession: () => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<UserSession | null>(null);
  const [vendor, setVendor] = useState<VendorProfile | null>(null);
  const [demoPersonas, setDemoPersonas] = useState<DemoPersona[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalTab, setAuthModalTab] = useState<"login" | "register">("login");

  const fetchSession = useCallback(async () => {
    try {
      const res = await fetch("/api/auth/me");
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
        setVendor(data.vendor);
        if (data.demoPersonas) {
          setDemoPersonas(data.demoPersonas);
        }
      }
    } catch (err) {
      console.error("Failed to load auth session", err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchSession();
  }, [fetchSession]);

  const switchUser = async (userId: string) => {
    setIsLoading(true);
    try {
      const res = await fetch("/api/auth/switch-user", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId }),
      });
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
        setVendor(data.vendor);
      }
    } catch (err) {
      console.error("Failed to switch persona", err);
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    // Switch to default customer Sarah
    await switchUser("usr_priya");
  };

  const openAuthModal = (tab: "login" | "register" = "login") => {
    setAuthModalTab(tab);
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setIsAuthModalOpen(false);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        vendor,
        demoPersonas,
        isLoading,
        isAuthModalOpen,
        authModalTab,
        openAuthModal,
        closeAuthModal,
        switchUser,
        refreshSession: fetchSession,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}

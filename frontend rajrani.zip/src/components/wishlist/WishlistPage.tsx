"use client";

import React from "react";
import { useWishlist } from "@/context/WishlistContext";
import { useCart } from "@/context/CartContext";
import { ProductCard } from "@/components/product/ProductCard";
import {
  Heart,
  ShoppingBag,
  ArrowRight,
  Store,
  Sparkles,
  Trash2,
} from "lucide-react";

interface WishlistPageProps {
  onSelectProduct: (product: any) => void;
  onExploreClick: () => void;
}

export function WishlistPage({ onSelectProduct, onExploreClick }: WishlistPageProps) {
  const { wishlistItems, toggleWishlist, isLoading } = useWishlist();
  const { addItem } = useCart();

  const handleMoveAllToCart = () => {
    wishlistItems.forEach((item) => {
      if (item.product) {
        addItem(
          {
            id: item.product.id,
            vendorId: item.product.vendorId,
            vendorName: item.product.vendor?.storeName,
            title: item.product.title,
            price: item.product.price,
            images: item.product.images,
            stockQuantity: item.product.stockQuantity,
          },
          1
        );
      }
    });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-gray-200">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center">
              <Heart className="w-4 h-4 fill-rose-600" />
            </div>
            <h1 className="text-2xl font-black text-gray-900 tracking-tight">
              My Saved Wishlist
            </h1>
          </div>
          <p className="text-xs text-gray-500 mt-1">
            {wishlistItems.length} curated items saved for future checkout
          </p>
        </div>

        {wishlistItems.length > 0 && (
          <button
            onClick={handleMoveAllToCart}
            className="px-5 py-2.5 bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold rounded-xl shadow-md shadow-orange-600/20 flex items-center gap-2 transition-all cursor-pointer"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>Move All Items to Cart</span>
          </button>
        )}
      </div>

      {/* Wishlist Grid or Empty State */}
      {wishlistItems.length === 0 ? (
        <div className="bg-white rounded-3xl border border-gray-200 p-16 text-center max-w-lg mx-auto space-y-4 shadow-2xs">
          <div className="w-16 h-16 rounded-full bg-rose-50 text-rose-400 flex items-center justify-center mx-auto">
            <Heart className="w-8 h-8 stroke-1" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-bold text-gray-900">Your wishlist is empty</h3>
            <p className="text-xs text-gray-500">
              Save audio equipment, Scandinavian furniture, clean skincare, and athletic gear as you browse.
            </p>
          </div>
          <button
            onClick={onExploreClick}
            className="px-6 py-2.5 bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold rounded-xl shadow-md transition-all inline-flex items-center gap-1.5"
          >
            <span>Continue Shopping Catalog</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {wishlistItems.map((item) => (
            <ProductCard
              key={item.id}
              product={item.product}
              onSelectProduct={onSelectProduct}
            />
          ))}
        </div>
      )}
    </div>
  );
}

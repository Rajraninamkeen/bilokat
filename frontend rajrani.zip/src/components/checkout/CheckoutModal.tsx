"use client";

import React, { useState } from "react";
import { useCart, INR } from "@/context/CartContext";
import { useAuth } from "@/context/AuthContext";
import confetti from "canvas-confetti";
import {
  X,
  CheckCircle2,
  Truck,
  CreditCard,
  ShieldCheck,
  MapPin,
  ArrowRight,
  ArrowLeft,
  Banknote,
  Smartphone,
  Store,
  Clock,
  BanknoteArrowDown,
  Check,
  Zap,
} from "lucide-react";

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOrderSuccess: (orderId: string, orderNumber: string) => void;
}

export function CheckoutModal({ isOpen, onClose, onOrderSuccess }: CheckoutModalProps) {
  const { items, subtotal, discount, shipping, tax, grandTotal, appliedCoupon, clearCart } = useCart();
  const { user } = useAuth();

  const [currentStep, setCurrentStep] = useState<1 | 2 | 3 | 4>(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [orderCompleteData, setOrderCompleteData] = useState<{ id: string; orderNumber: string } | null>(null);

  const [shippingAddress, setShippingAddress] = useState({
    fullName: user?.name || "Priya Sharma",
    email: user?.email || "priya.sharma@gmail.com",
    phone: user?.phone || "+91 98765 43210",
    addressLine1: "14-B, Shastri Nagar, Near Axis Bank",
    addressLine2: "Second Floor",
    city: "Jaipur",
    state: "Rajasthan",
    postalCode: "302016",
    country: "India",
  });

  const [shippingMethod, setShippingMethod] = useState<"standard" | "express" | "next_day">("standard");
  const [paymentMethod, setPaymentMethod] = useState<"upi" | "credit_card" | "cod">("upi");

  const [upiId, setUpiId] = useState("");
  const [upiVerified, setUpiVerified] = useState(false);
  const [cardDetails, setCardDetails] = useState({
    cardNumber: "4123 4567 8910 1112",
    cardHolder: user?.name || "Priya Sharma",
    expiry: "09/28",
    cvv: "321",
  });
  const [orderNotes, setOrderNotes] = useState("");

  if (!isOpen) return null;

  const shippingPrice = (method: string) => {
    if (method === "express") return 99;
    if (method === "next_day") return 149;
    return subtotal >= 499 ? 0 : 49;
  };

  const totalForMethod = () => {
    const taxable = Math.max(0, subtotal - discount);
    const shipFee = shippingPrice(shippingMethod);
    return Math.round((taxable + shipFee + tax) * 100) / 100;
  };

  const handlePlaceOrder = async () => {
    setIsSubmitting(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          items: items.map((i) => ({
            productId: i.productId,
            quantity: i.quantity,
            selectedVariant: i.selectedVariant,
          })),
          shippingAddress,
          shippingMethod,
          paymentMethod,
          couponCode: appliedCoupon ? appliedCoupon.code : null,
          notes: orderNotes,
        }),
      });
      const data = await res.json();
      if (data.success && data.order) {
        confetti({ particleCount: 110, spread: 75, origin: { y: 0.6 }, colors: ["#f97316", "#eab308", "#b91c1c", "#16a34a"] });
        setOrderCompleteData({ id: data.order.id, orderNumber: data.order.orderNumber });
        clearCart();
      } else {
        alert(data.error || "Failed to place order. Please try again.");
      }
    } catch (e) {
      alert("An unexpected error occurred during checkout.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Packages are grouped by seller (single-store: one package, but structure kept)
  const vendorGroups = items.reduce((acc, item) => {
    if (!acc[item.vendorId]) acc[item.vendorId] = { vendorName: item.vendorName, items: [] };
    acc[item.vendorId].items.push(item);
    return acc;
  }, {} as Record<string, { vendorName: string; items: typeof items }>);

  const steps = [
    { step: 1, label: "Address" },
    { step: 2, label: "Delivery" },
    { step: 3, label: "Payment" },
    { step: 4, label: "Review" },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto p-4 sm:p-6">
      <div onClick={onClose} className="fixed inset-0 bg-stone-950/60 backdrop-blur-xs transition-opacity" />

      <div className="relative w-full max-w-3xl bg-white rounded-3xl shadow-2xl overflow-hidden z-10 border border-orange-100 animate-in zoom-in-95 duration-200">
        {orderCompleteData ? (
          <div className="p-8 sm:p-12 text-center space-y-6">
            <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner animate-in zoom-in-50 duration-300">
              <CheckCircle2 className="w-12 h-12" />
            </div>
            <div className="space-y-2">
              <span className="text-xs uppercase font-bold tracking-widest text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
                Order Confirmed
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-gray-900">Dhanyawaad! Order placed.</h2>
              <p className="text-sm text-gray-500 max-w-md mx-auto">
                Fresh batch packed at Rajrani Namkeen Centre. Tracking SMS & email sent to <strong>{shippingAddress.phone}</strong> and <strong>{shippingAddress.email}</strong>.
              </p>
            </div>
            <div className="bg-orange-50/70 border border-orange-100 rounded-2xl p-6 max-w-md mx-auto text-left space-y-3 text-xs">
              <div className="flex justify-between text-gray-500">
                <span>Order Number</span>
                <span className="font-mono font-bold text-gray-900">{orderCompleteData.orderNumber}</span>
              </div>
              <div className="flex justify-between text-gray-500">
                <span>Amount Paid</span>
                <span className="font-bold text-orange-700">{INR(totalForMethod())}</span>
              </div>
              <div className="flex justify-between text-gray-500">
                <span>Payment</span>
                <span className="font-semibold text-gray-800 uppercase">{paymentMethod === "upi" ? "UPI" : paymentMethod === "cod" ? "Cash on Delivery" : "Card"}</span>
              </div>
              <div className="flex justify-between text-gray-500">
                <span>Delivery To</span>
                <span className="text-gray-700 text-right font-medium">
                  {shippingAddress.city}, {shippingAddress.state} {shippingAddress.postalCode}
                </span>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
              <button
                onClick={() => {
                  onClose();
                  onOrderSuccess(orderCompleteData.id, orderCompleteData.orderNumber);
                }}
                className="px-6 py-3 bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold rounded-xl shadow-lg shadow-orange-600/30 transition-all flex items-center justify-center gap-2"
              >
                <Truck className="w-4 h-4" />
                <span>Track My Order</span>
              </button>
              <button onClick={onClose} className="px-6 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-bold rounded-xl transition-all">
                Continue Shopping
              </button>
            </div>
          </div>
        ) : (
          <div>
            <div className="p-6 border-b border-orange-100 bg-orange-50/60 flex items-center justify-between">
              <div>
                <h3 className="text-lg font-extrabold text-gray-900">Secure Checkout</h3>
                <p className="text-xs text-gray-500">BILOKAT · Fresh from Rajrani Namkeen Centre, Bikaner</p>
              </div>
              <button onClick={onClose} className="p-1.5 text-gray-400 hover:text-gray-700 hover:bg-orange-100 rounded-full transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="px-6 py-3 bg-white border-b border-orange-50">
              <div className="flex items-center justify-between max-w-lg mx-auto">
                {steps.map((s) => (
                  <div key={s.step} className="flex items-center gap-2">
                    <div
                      className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                        currentStep === s.step
                          ? "bg-orange-600 text-white ring-4 ring-orange-100"
                          : currentStep > s.step
                          ? "bg-emerald-600 text-white"
                          : "bg-orange-50 text-orange-300"
                      }`}
                    >
                      {currentStep > s.step ? <Check className="w-3.5 h-3.5" /> : s.step}
                    </div>
                    <span className={`text-xs font-medium hidden sm:inline ${currentStep === s.step ? "text-gray-900 font-bold" : "text-gray-400"}`}>
                      {s.label}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-6 max-h-[60vh] overflow-y-auto">
              {/* STEP 1: Address */}
              {currentStep === 1 && (
                <div className="space-y-4">
                  <h4 className="text-sm font-bold text-gray-900 flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-orange-600" />
                    <span>Delivery Address</span>
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div>
                      <label className="block text-gray-700 font-medium mb-1">Full Name</label>
                      <input
                        value={shippingAddress.fullName}
                        onChange={(e) => setShippingAddress({ ...shippingAddress, fullName: e.target.value })}
                        className="w-full bg-orange-50/60 border border-orange-100 rounded-xl px-3 py-2 focus:bg-white focus:border-orange-400 outline-hidden"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-700 font-medium mb-1">Mobile Number</label>
                      <input
                        value={shippingAddress.phone}
                        onChange={(e) => setShippingAddress({ ...shippingAddress, phone: e.target.value })}
                        className="w-full bg-orange-50/60 border border-orange-100 rounded-xl px-3 py-2 focus:bg-white focus:border-orange-400 outline-hidden"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block text-gray-700 font-medium mb-1">Flat / House No., Street, Landmark</label>
                      <input
                        value={shippingAddress.addressLine1}
                        onChange={(e) => setShippingAddress({ ...shippingAddress, addressLine1: e.target.value })}
                        className="w-full bg-orange-50/60 border border-orange-100 rounded-xl px-3 py-2 focus:bg-white focus:border-orange-400 outline-hidden"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-700 font-medium mb-1">City</label>
                      <input
                        value={shippingAddress.city}
                        onChange={(e) => setShippingAddress({ ...shippingAddress, city: e.target.value })}
                        className="w-full bg-orange-50/60 border border-orange-100 rounded-xl px-3 py-2 focus:bg-white focus:border-orange-400 outline-hidden"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-gray-700 font-medium mb-1">State</label>
                        <input
                          value={shippingAddress.state}
                          onChange={(e) => setShippingAddress({ ...shippingAddress, state: e.target.value })}
                          className="w-full bg-orange-50/60 border border-orange-100 rounded-xl px-3 py-2 focus:bg-white focus:border-orange-400 outline-hidden"
                        />
                      </div>
                      <div>
                        <label className="block text-gray-700 font-medium mb-1">Pincode</label>
                        <input
                          value={shippingAddress.postalCode}
                          onChange={(e) => setShippingAddress({ ...shippingAddress, postalCode: e.target.value })}
                          className="w-full bg-orange-50/60 border border-orange-100 rounded-xl px-3 py-2 focus:bg-white focus:border-orange-400 outline-hidden font-mono"
                        />
                      </div>
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block text-gray-700 font-medium mb-1">Email (for tracking updates)</label>
                      <input
                        type="email"
                        value={shippingAddress.email}
                        onChange={(e) => setShippingAddress({ ...shippingAddress, email: e.target.value })}
                        className="w-full bg-orange-50/60 border border-orange-100 rounded-xl px-3 py-2 focus:bg-white focus:border-orange-400 outline-hidden"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* STEP 2: Delivery speed */}
              {currentStep === 2 && (
                <div className="space-y-4">
                  <h4 className="text-sm font-bold text-gray-900 flex items-center gap-2">
                    <Truck className="w-4 h-4 text-orange-600" />
                    <span>Delivery Speed (Delhivery · Blue Dart · DTDC)</span>
                  </h4>
                  <div className="space-y-3">
                    {[
                      {
                        id: "standard",
                        title: "Standard Delivery",
                        time: "3–5 days across India",
                        price: subtotal >= 499 ? "FREE" : "₹49",
                        desc: "Reliable ground shipping. Free above ₹499.",
                      },
                      {
                        id: "express",
                        title: "Express Delivery",
                        time: "2–3 days across India",
                        price: "₹99",
                        desc: "Priority air routing for fresh namkeen.",
                      },
                      {
                        id: "next_day",
                        title: "Next-Day Delivery (Metro Cities)",
                        time: "1 day (order before 2 PM)",
                        price: "₹149",
                        desc: "Available in Delhi, Mumbai, Jaipur, Pune, Ahmedabad & Bengaluru.",
                      },
                    ].map((opt) => (
                      <label
                        key={opt.id}
                        className={`flex items-start gap-3 p-4 rounded-2xl border cursor-pointer transition-all ${
                          shippingMethod === opt.id
                            ? "bg-orange-50 border-orange-400 ring-2 ring-orange-100"
                            : "bg-white border-orange-100 hover:bg-orange-50/50"
                        }`}
                      >
                        <input
                          type="radio"
                          name="shippingMethod"
                          checked={shippingMethod === opt.id}
                          onChange={() => setShippingMethod(opt.id as any)}
                          className="mt-1 text-orange-600 focus:ring-orange-500"
                        />
                        <div className="flex-1">
                          <div className="flex items-center justify-between text-xs font-bold text-gray-900">
                            <span>{opt.title}</span>
                            <span className="text-orange-700">{opt.price}</span>
                          </div>
                          <div className="flex items-center gap-2 text-xs text-gray-500 mt-0.5">
                            <Clock className="w-3.5 h-3.5 text-gray-400" />
                            <span>{opt.time}</span>
                          </div>
                          <p className="text-[11px] text-gray-400 mt-1">{opt.desc}</p>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>
              )}

              {/* STEP 3: Payment */}
              {currentStep === 3 && (
                <div className="space-y-5">
                  <h4 className="text-sm font-bold text-gray-900 flex items-center gap-2">
                    <Banknote className="w-4 h-4 text-orange-600" />
                    <span>Payment Method</span>
                  </h4>

                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { id: "upi", label: "UPI / GPay", icon: Smartphone },
                      { id: "credit_card", label: "Card", icon: CreditCard },
                      { id: "cod", label: "COD", icon: BanknoteArrowDown },
                    ].map((pm) => (
                      <button
                        key={pm.id}
                        type="button"
                        onClick={() => setPaymentMethod(pm.id as any)}
                        className={`p-3 rounded-xl border text-xs font-bold transition-all flex flex-col items-center gap-1.5 ${
                          paymentMethod === pm.id
                            ? "bg-orange-50 border-orange-500 text-orange-700"
                            : "bg-white border-orange-100 text-gray-600 hover:bg-orange-50/50"
                        }`}
                      >
                        <pm.icon className="w-5 h-5" />
                        <span>{pm.label}</span>
                      </button>
                    ))}
                  </div>

                  {paymentMethod === "upi" && (
                    <div className="bg-orange-50/70 border border-orange-100 rounded-2xl p-4 space-y-3 text-xs">
                      <label className="block text-gray-700 font-medium">Your UPI ID (GPay / PhonePe / Paytm)</label>
                      <div className="flex gap-2">
                        <input
                          value={upiId}
                          onChange={(e) => {
                            setUpiId(e.target.value);
                            setUpiVerified(false);
                          }}
                          placeholder="yourname@ybl"
                          className="flex-1 bg-white border border-orange-200 rounded-xl px-3 py-2 font-mono text-sm"
                        />
                        <button
                          type="button"
                          onClick={() => setUpiVerified(!!upiId.trim())}
                          className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl text-xs"
                        >
                          Verify
                        </button>
                      </div>
                      {upiVerified && (
                        <p className="flex items-center gap-1.5 text-emerald-700 font-semibold">
                          <Check className="w-3.5 h-3.5" /> UPI ID verified — collect request will be sent at order time.
                        </p>
                      )}
                    </div>
                  )}

                  {paymentMethod === "credit_card" && (
                    <div className="bg-orange-50/70 border border-orange-100 rounded-2xl p-4 space-y-3 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="text-gray-700 font-medium">Card Details</span>
                        <button
                          type="button"
                          onClick={() =>
                            setCardDetails({ cardNumber: "4123 4567 8910 1112", cardHolder: user?.name || "Priya Sharma", expiry: "09/28", cvv: "321" })
                          }
                          className="text-orange-700 font-semibold hover:underline flex items-center gap-1"
                        >
                          <Zap className="w-3.5 h-3.5" />
                          <span>Autofill saved card</span>
                        </button>
                      </div>
                      <input
                        value={cardDetails.cardNumber}
                        onChange={(e) => setCardDetails({ ...cardDetails, cardNumber: e.target.value })}
                        className="w-full bg-white border border-orange-200 rounded-xl px-3 py-2 font-mono"
                      />
                      <div className="grid grid-cols-2 gap-2">
                        <input
                          value={cardDetails.expiry}
                          onChange={(e) => setCardDetails({ ...cardDetails, expiry: e.target.value })}
                          className="bg-white border border-orange-200 rounded-xl px-3 py-2 font-mono"
                        />
                        <input
                          value={cardDetails.cvv}
                          onChange={(e) => setCardDetails({ ...cardDetails, cvv: e.target.value })}
                          className="bg-white border border-orange-200 rounded-xl px-3 py-2 font-mono"
                        />
                      </div>
                    </div>
                  )}

                  {paymentMethod === "cod" && (
                    <div className="bg-amber-50 border border-amber-200 text-amber-800 rounded-2xl p-3.5 text-xs flex items-start gap-2">
                      <BanknoteArrowDown className="w-4 h-4 mt-0.5 shrink-0" />
                      <span>Pay cash / UPI to the delivery partner when your namkeen arrives. Please keep exact change ready.</span>
                    </div>
                  )}

                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Delivery instructions (optional)</label>
                    <input
                      value={orderNotes}
                      onChange={(e) => setOrderNotes(e.target.value)}
                      placeholder="e.g. Deliver to security, call before arriving"
                      className="w-full bg-orange-50/60 border border-orange-100 rounded-xl px-3 py-2 text-xs"
                    />
                  </div>
                </div>
              )}

              {/* STEP 4: Review */}
              {currentStep === 4 && (
                <div className="space-y-4 text-xs">
                  <div className="flex items-center justify-between pb-2 border-b border-orange-100">
                    <h4 className="text-sm font-bold text-gray-900">Review Your Order</h4>
                    <span className="text-orange-700 font-semibold">Fresh Bikaner Pack</span>
                  </div>

                  {Object.entries(vendorGroups).map(([vendorId, group]) => (
                    <div key={vendorId} className="bg-orange-50/60 border border-orange-100 rounded-2xl p-3.5">
                      <div className="flex items-center gap-1.5 pb-2 border-b border-orange-100 font-bold text-gray-800 text-[11px]">
                        <Store className="w-3.5 h-3.5 text-orange-600" />
                        <span>
                          Packed fresh by: <strong>{group.vendorName}</strong>
                        </span>
                      </div>
                      <div className="divide-y divide-orange-100 mt-2">
                        {group.items.map((i) => (
                          <div key={i.id} className="py-2 flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <img src={i.image} alt={i.title} className="w-8 h-8 rounded-md object-cover" />
                              <div>
                                <p className="font-semibold text-gray-900 line-clamp-1">{i.title}</p>
                                <p className="text-[10px] text-gray-500">Qty: {i.quantity}</p>
                              </div>
                            </div>
                            <span className="font-bold text-gray-900">{INR(i.price * i.quantity)}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}

                  <div className="bg-orange-50/70 border border-orange-100 rounded-2xl p-4 space-y-1.5">
                    <div className="flex justify-between text-gray-600">
                      <span>Subtotal</span>
                      <span className="font-medium text-gray-900">₹{subtotal}</span>
                    </div>
                    {discount > 0 && (
                      <div className="flex justify-between text-emerald-700 font-semibold">
                        <span>Coupon Discount ({appliedCoupon?.code})</span>
                        <span>-₹{discount.toFixed(0)}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-gray-600">
                      <span>Delivery ({shippingMethod === "standard" ? "Standard" : shippingMethod === "express" ? "Express" : "Next-Day"})</span>
                      <span>{shippingPrice(shippingMethod) === 0 ? "FREE" : `₹${shippingPrice(shippingMethod)}`}</span>
                    </div>
                    <div className="flex justify-between text-gray-600">
                      <span>GST (12%)</span>
                      <span>₹{tax.toFixed(0)}</span>
                    </div>
                    <div className="flex justify-between text-sm font-extrabold text-gray-900 pt-2 border-t border-orange-200">
                      <span>Total to Pay</span>
                      <span className="text-orange-700">₹{totalForMethod()}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="p-4 sm:p-6 border-t border-orange-100 bg-orange-50/60 flex items-center justify-between">
              {currentStep > 1 ? (
                <button
                  onClick={() => setCurrentStep((prev) => (prev - 1) as any)}
                  className="px-4 py-2 text-xs font-semibold text-gray-700 hover:bg-orange-100 rounded-xl transition-colors flex items-center gap-1.5"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back</span>
                </button>
              ) : (
                <div />
              )}
              {currentStep < 4 ? (
                <button
                  onClick={() => setCurrentStep((prev) => (prev + 1) as any)}
                  className="px-6 py-2.5 bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold rounded-xl shadow-md transition-all flex items-center gap-1.5"
                >
                  <span>Continue</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              ) : (
                <button
                  onClick={handlePlaceOrder}
                  disabled={isSubmitting}
                  className="px-8 py-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-extrabold rounded-xl shadow-lg shadow-emerald-600/30 transition-all flex items-center gap-2 cursor-pointer"
                >
                  {isSubmitting ? (
                    <span>Placing your order...</span>
                  ) : (
                    <>
                      <ShieldCheck className="w-4 h-4" />
                      <span>Place Order · ₹{totalForMethod()}</span>
                    </>
                  )}
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

"use client";

import React, { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import {
  Package,
  Truck,
  CheckCircle2,
  Clock,
  ExternalLink,
  Store,
  ChevronRight,
  ShoppingBag,
  ArrowRight,
  ShieldCheck,
} from "lucide-react";

interface OrdersPageProps {
  onOpenTracking: (orderId: string) => void;
  onExploreClick: () => void;
  onSelectProduct?: (productId: string) => void;
}

export function OrdersPage({ onOpenTracking, onExploreClick, onSelectProduct }: OrdersPageProps) {
  const { user } = useAuth();
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setOrderStatusFilter] = useState("all");

  const fetchOrders = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/orders");
      if (res.ok) {
        const data = await res.json();
        setOrders(data.orders || []);
      }
    } catch (e) {
      console.error("Failed to fetch customer orders", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, [user]);

  const filteredOrders = orders.filter((o) => {
    if (statusFilter === "all") return true;
    return o.status === statusFilter;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-gray-200">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-orange-50 text-orange-600 flex items-center justify-center">
              <Package className="w-4 h-4" />
            </div>
            <h1 className="text-2xl font-black text-gray-900 tracking-tight">
              Order History & Tracking
            </h1>
          </div>
          <p className="text-xs text-gray-500 mt-1">
            Track your fresh namkeen orders, delivery partners and receipts
          </p>
        </div>

        {/* Status Filter Pills */}
        <div className="flex items-center gap-1.5 bg-gray-100 p-1 rounded-xl text-xs font-semibold">
          {["all", "processing", "shipped", "delivered"].map((st) => (
            <button
              key={st}
              onClick={() => setOrderStatusFilter(st)}
              className={`px-3 py-1.5 rounded-lg capitalize transition-all ${
                statusFilter === st
                  ? "bg-white text-orange-600 shadow-xs"
                  : "text-gray-600 hover:text-gray-900"
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Orders List or Empty State */}
      {loading ? (
        <div className="py-20 flex flex-col items-center justify-center space-y-3">
          <div className="w-10 h-10 border-4 border-orange-600 border-t-transparent rounded-full animate-spin" />
          <p className="text-xs font-semibold text-gray-500">Loading order records...</p>
        </div>
      ) : filteredOrders.length === 0 ? (
        <div className="bg-white rounded-3xl border border-gray-200 p-16 text-center max-w-lg mx-auto space-y-4 shadow-2xs">
          <div className="w-16 h-16 rounded-full bg-orange-50 text-orange-400 flex items-center justify-center mx-auto">
            <ShoppingBag className="w-8 h-8 stroke-1" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-bold text-gray-900">No orders found</h3>
            <p className="text-xs text-gray-500">
              You haven&apos;t placed any orders matching the selected filter yet.
            </p>
          </div>
          <button
            onClick={onExploreClick}
            className="px-6 py-2.5 bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold rounded-xl shadow-md transition-all inline-flex items-center gap-1.5"
          >
            <span>Start Shopping</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredOrders.map((order) => (
            <div
              key={order.id}
              className="bg-white rounded-3xl border border-gray-200 hover:border-orange-300 shadow-2xs transition-all p-5 sm:p-6 space-y-4"
            >
              {/* Order Card Top Bar */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-gray-100 gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gray-50 border border-gray-200 flex items-center justify-center text-gray-700 font-bold text-xs shrink-0">
                    📦
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-gray-900 text-sm">{order.orderNumber}</span>
                      <span
                        className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                          order.status === "delivered"
                            ? "bg-emerald-50 text-emerald-700 border border-emerald-200"
                            : order.status === "shipped"
                            ? "bg-blue-50 text-blue-700 border border-blue-200"
                            : "bg-amber-50 text-amber-700 border border-amber-200"
                        }`}
                      >
                        {order.status}
                      </span>
                    </div>
                    <p className="text-xs text-gray-500 mt-0.5">
                      Placed on {new Date(order.createdAt).toLocaleDateString()} • {order.items?.length || 1} items
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right sm:block hidden">
                    <span className="text-[11px] text-gray-400 block">Total</span>
                    <span className="text-sm font-black text-gray-900">â¹{order.grandTotal?.toFixed(2)}</span>
                  </div>

                  <button
                    onClick={() => onOpenTracking(order.id)}
                    className="px-4 py-2 bg-orange-50 hover:bg-orange-600 text-orange-700 hover:text-white text-xs font-bold rounded-xl transition-all flex items-center gap-1.5"
                  >
                    <Truck className="w-3.5 h-3.5" />
                    <span>Track Shipment</span>
                  </button>
                </div>
              </div>

              {/* Order Items Preview */}
              <div className="divide-y divide-gray-50">
                {(order.items || []).map((item: any) => (
                  <div key={item.id} className="py-2.5 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-3">
                      <img
                        src={item.productImage}
                        alt={item.productTitle}
                        className="w-12 h-12 rounded-xl object-cover bg-gray-100 shrink-0"
                      />
                      <div>
                        <h4 className="font-bold text-gray-900 line-clamp-1">{item.productTitle}</h4>
                        <div className="text-[11px] text-gray-500 flex items-center gap-2 mt-0.5">
                          <span>Qty: {item.quantity}</span>
                          <span>•</span>
                          <span className="text-orange-600 font-medium">
                            {item.vendor?.storeName || "Vendor Direct"}
                          </span>
                          {item.carrierName && item.trackingNumber && (
                            <>
                              <span>•</span>
                              <span className="font-mono text-gray-600">
                                {item.carrierName}: {item.trackingNumber}
                              </span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    <span className="font-black text-gray-900">â¹{item.totalPrice?.toFixed(2)}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

"use client";

import React, { useState, useEffect } from "react";
import {
  X,
  Truck,
  CheckCircle2,
  Clock,
  Package,
  MapPin,
  Store,
  ExternalLink,
  Download,
  Copy,
  Check,
  ShieldCheck,
} from "lucide-react";

interface OrderTrackingModalProps {
  orderId: string | null;
  onClose: () => void;
  onSelectProduct?: (productId: string) => void;
}

export function OrderTrackingModal({ orderId, onClose, onSelectProduct }: OrderTrackingModalProps) {
  const [order, setOrder] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [copiedTracking, setCopiedTracking] = useState<string | null>(null);

  useEffect(() => {
    if (!orderId) return;
    setLoading(true);
    fetch(`/api/orders/${orderId}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.order) {
          setOrder(data.order);
        }
      })
      .catch((e) => console.error("Error fetching order tracking", e))
      .finally(() => setLoading(false));
  }, [orderId]);

  if (!orderId) return null;

  const handleCopyTracking = (trk: string) => {
    navigator.clipboard.writeText(trk);
    setCopiedTracking(trk);
    setTimeout(() => setCopiedTracking(null), 2000);
  };

  const steps = [
    { key: "pending", label: "Order Placed", desc: "Payment verified & order recorded" },
    { key: "processing", label: "Vendor Processing", desc: "Sellers preparing your items" },
    { key: "shipped", label: "Dispatched & In Transit", desc: "Carrier priority tracking active" },
    { key: "delivered", label: "Delivered", desc: "Safely received at address" },
  ];

  const getStepIndex = (status: string) => {
    switch (status) {
      case "delivered":
        return 3;
      case "shipped":
        return 2;
      case "processing":
        return 1;
      case "pending":
      default:
        return 0;
    }
  };

  const currentStepIdx = order ? getStepIndex(order.status) : 1;

  // Group items by vendor
  const vendorPackages = order?.items?.reduce((acc: any, item: any) => {
    if (!acc[item.vendorId]) {
      acc[item.vendorId] = {
        vendor: item.vendor,
        status: item.status,
        carrierName: item.carrierName,
        trackingNumber: item.trackingNumber,
        shippedAt: item.shippedAt,
        deliveredAt: item.deliveredAt,
        items: [],
      };
    }
    acc[item.vendorId].items.push(item);
    return acc;
  }, {}) || {};

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity"
      />

      {/* Modal Dialog */}
      <div className="relative w-full max-w-3xl bg-white rounded-3xl shadow-2xl overflow-hidden z-10 border border-gray-100 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-gray-100 bg-gray-50/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-orange-100 text-orange-700 flex items-center justify-center">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-extrabold text-gray-900">
                  Order Tracking: {order?.orderNumber || "Loading..."}
                </h3>
                {order && (
                  <span
                    className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                      order.status === "delivered"
                        ? "bg-emerald-100 text-emerald-800"
                        : order.status === "shipped"
                        ? "bg-blue-100 text-blue-800"
                        : "bg-amber-100 text-amber-800"
                    }`}
                  >
                    {order.status}
                  </span>
                )}
              </div>
              <p className="text-xs text-gray-500">
                Placed on {order ? new Date(order.createdAt).toLocaleDateString() : ""} • {order?.items?.length || 0} items
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-gray-700 hover:bg-gray-200 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {loading || !order ? (
          <div className="p-16 flex flex-col items-center justify-center space-y-3">
            <div className="w-10 h-10 border-4 border-orange-600 border-t-transparent rounded-full animate-spin" />
            <p className="text-xs font-semibold text-gray-500">Fetching live tracking information...</p>
          </div>
        ) : (
          <div className="p-6 sm:p-8 overflow-y-auto space-y-8 text-xs">
            {/* Visual Timeline Stepper */}
            <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 relative overflow-hidden">
              <h4 className="text-xs font-bold uppercase tracking-wider text-orange-300 mb-6">
                Live Shipment Progress
              </h4>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 relative">
                {steps.map((st, idx) => {
                  const isDone = idx <= currentStepIdx;
                  const isCurrent = idx === currentStepIdx;
                  return (
                    <div key={st.key} className="flex flex-col items-start gap-2 relative">
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs transition-all ${
                          isDone
                            ? "bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/30 ring-4 ring-emerald-500/20"
                            : "bg-slate-800 text-slate-500"
                        }`}
                      >
                        {isDone ? <Check className="w-4 h-4 stroke-[3]" /> : idx + 1}
                      </div>
                      <div className="space-y-0.5">
                        <div
                          className={`font-bold text-xs ${
                            isCurrent ? "text-emerald-400" : isDone ? "text-white" : "text-slate-500"
                          }`}
                        >
                          {st.label}
                        </div>
                        <p className="text-[10px] text-slate-400 leading-tight">{st.desc}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Multi-Vendor Split Packages Breakdown */}
            <div className="space-y-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-gray-900">
                Multi-Vendor Dispatches ({Object.keys(vendorPackages).length} Independent Packages)
              </h4>

              <div className="space-y-4">
                {Object.entries(vendorPackages).map(([vendorId, pkg]: any) => (
                  <div key={vendorId} className="bg-gray-50 border border-gray-200 rounded-2xl p-4 space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-gray-200/80 gap-2">
                      <div className="flex items-center gap-2">
                        <Store className="w-4 h-4 text-orange-600" />
                        <span className="font-bold text-gray-900 text-xs">
                          {pkg.vendor?.storeName || "Marketplace Vendor"}
                        </span>
                        <span
                          className={`text-[9px] font-bold uppercase px-2 py-0.5 rounded-full ${
                            pkg.status === "delivered"
                              ? "bg-emerald-100 text-emerald-800"
                              : pkg.status === "shipped"
                              ? "bg-blue-100 text-blue-800"
                              : "bg-amber-100 text-amber-800"
                          }`}
                        >
                          {pkg.status}
                        </span>
                      </div>

                      {/* Carrier & Tracking Code */}
                      {pkg.trackingNumber ? (
                        <div className="flex items-center gap-2 bg-white px-2.5 py-1 rounded-xl border border-gray-200 shadow-2xs">
                          <span className="text-[10px] text-gray-500 font-medium">
                            {pkg.carrierName || "Carrier"}:
                          </span>
                          <span className="font-mono font-bold text-orange-600">{pkg.trackingNumber}</span>
                          <button
                            onClick={() => handleCopyTracking(pkg.trackingNumber)}
                            className="p-1 text-gray-400 hover:text-gray-700 transition-colors"
                            title="Copy Tracking Number"
                          >
                            {copiedTracking === pkg.trackingNumber ? (
                              <Check className="w-3 h-3 text-emerald-600" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </button>
                        </div>
                      ) : (
                        <span className="text-[11px] text-amber-700 font-medium">
                          Processing in warehouse
                        </span>
                      )}
                    </div>

                    {/* Items in this package */}
                    <div className="divide-y divide-gray-100">
                      {pkg.items.map((item: any) => (
                        <div key={item.id} className="py-2.5 flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <img
                              src={item.productImage}
                              alt={item.productTitle}
                              className="w-11 h-11 rounded-lg object-cover bg-gray-100 shrink-0"
                            />
                            <div>
                              <div className="font-bold text-gray-900 line-clamp-1">{item.productTitle}</div>
                              <div className="text-[10px] text-gray-500">Qty: {item.quantity} • ${item.unitPrice?.toFixed(2)} each</div>
                            </div>
                          </div>
                          <span className="font-black text-gray-900">â¹{item.totalPrice?.toFixed(2)}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Shipping Address & Receipt Summary */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-gray-50 border border-gray-200 rounded-2xl p-4 space-y-2">
                <div className="flex items-center gap-1.5 font-bold text-gray-900">
                  <MapPin className="w-3.5 h-3.5 text-orange-600" />
                  <span>Destination Address</span>
                </div>
                <div className="text-gray-600 leading-relaxed text-[11px]">
                  <p className="font-semibold text-gray-900">{order.shippingAddress?.fullName}</p>
                  <p>{order.shippingAddress?.addressLine1}</p>
                  <p>{order.shippingAddress?.city}, {order.shippingAddress?.state} {order.shippingAddress?.postalCode}</p>
                  <p>{order.shippingAddress?.country}</p>
                </div>
              </div>

              <div className="bg-orange-50/60 border border-orange-100 rounded-2xl p-4 space-y-1.5">
                <h4 className="font-bold text-gray-900 mb-2">Itemized Receipt</h4>
                <div className="flex justify-between text-gray-600">
                  <span>Subtotal</span>
                  <span className="font-semibold text-gray-900">â¹{order.subtotal?.toFixed(2)}</span>
                </div>
                {order.discountTotal > 0 && (
                  <div className="flex justify-between text-emerald-700 font-semibold">
                    <span>Discount ({order.couponCode || "PROMO"})</span>
                    <span>-${order.discountTotal?.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-gray-600">
                  <span>Shipping Fee</span>
                  <span>{order.shippingFee === 0 ? "FREE" : `â¹{order.shippingFee?.toFixed(2)}`}</span>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span>GST (12%)</span>
                  <span>â¹{order.tax?.toFixed(2)}</span>
                </div>
                <div className="flex justify-between font-black text-gray-900 pt-2 border-t border-orange-200 text-sm">
                  <span>Grand Total</span>
                  <span className="text-orange-600">â¹{order.grandTotal?.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

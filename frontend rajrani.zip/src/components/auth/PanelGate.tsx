"use client";

import React from "react";
import { useAuth } from "@/context/AuthContext";
import { Lock, ShieldCheck, ArrowLeft, LogIn } from "lucide-react";

interface PanelGateProps {
  panelName: string;
  ownerOnly?: boolean;
  onBackToShop: () => void;
}

export function AccessDenied({ panelName, ownerOnly = false, onBackToShop }: PanelGateProps) {
  const { openAuthModal } = useAuth();

  return (
    <div className="max-w-7xl mx-auto px-4 py-24 flex items-center justify-center">
      <div className="bg-white border border-orange-100 rounded-3xl shadow-2xs p-10 max-w-md w-full text-center space-y-5">
        <div className="w-16 h-16 rounded-full bg-red-50 border border-red-100 text-red-700 flex items-center justify-center mx-auto">
          <Lock className="w-7 h-7" />
        </div>
        <div className="space-y-2">
          <h2 className="text-xl font-black text-gray-900">Restricted Area</h2>
          <p className="text-sm text-gray-500 leading-relaxed">
            The <strong className="text-gray-800">{panelName}</strong>{" "}
            is only accessible to{" "}
            {ownerOnly ? (
              <>
                the <strong className="text-red-800">store owner</strong>. Staff accounts can use the Store Panel instead.
              </>
            ) : (
              <>
                the <strong className="text-red-800">store owner</strong> and{" "}
                <strong className="text-orange-700">authorised staff</strong>.
              </>
            )}
          </p>
          <p className="text-xs text-gray-400">Yahan sirf owner aur unki team aata hai.</p>
        </div>
        <div className="flex flex-col gap-2 pt-1">
          <button
            onClick={() => openAuthModal("login")}
            className="w-full py-3 bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold rounded-xl shadow-md shadow-orange-600/20 transition-all flex items-center justify-center gap-2"
          >
            <LogIn className="w-4 h-4" />
            <span>Sign in as Owner / Staff</span>
          </button>
          <button
            onClick={onBackToShop}
            className="w-full py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Shop</span>
          </button>
          <p className="text-[10px] text-gray-400 flex items-center justify-center gap-1 pt-1">
            <ShieldCheck className="w-3 h-3 text-emerald-600" />
            Staff access is granted by the owner from Owner Panel → Team Access
          </p>
        </div>
      </div>
    </div>
  );
}

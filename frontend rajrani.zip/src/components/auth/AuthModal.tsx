"use client";

import React, { useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { X, UserRound, Sparkles, ArrowRight, ShieldCheck, Wheat } from "lucide-react";

export function AuthModal() {
  const {
    isAuthModalOpen,
    closeAuthModal,
    authModalTab,
    demoPersonas,
    switchUser,
    refreshSession,
  } = useAuth();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState("");

  if (!isAuthModalOpen) return null;

  const personas = demoPersonas;

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError("");
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, phone, role: "customer" }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        await refreshSession();
        closeAuthModal();
      } else {
        setError(data.error || "Could not create your account");
      }
    } catch {
      setError("Something went wrong, please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div onClick={closeAuthModal} className="fixed inset-0 bg-stone-950/60 backdrop-blur-xs transition-opacity" />
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl overflow-hidden z-10 border border-orange-100 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-orange-100 bg-gradient-to-r from-red-950 to-orange-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-yellow-400/20 border border-yellow-300/40 flex items-center justify-center text-yellow-300">
              <Wheat className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold">
                {authModalTab === "login" ? "Sign in to BILOKAT" : "Create your BILOKAT account"}
              </h3>
              <p className="text-xs text-orange-100/70">
                {authModalTab === "login"
                  ? "Owner dashboard & customer accounts"
                  : "Order faster, track deliveries & earn loyalty"}
              </p>
            </div>
          </div>
          <button
            onClick={closeAuthModal}
            className="p-1.5 text-orange-200 hover:text-white hover:bg-white/10 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs">
          {/* Quick sign-in */}
          <div className="space-y-3">
            <div className="flex items-center gap-1.5 text-orange-700 font-bold uppercase tracking-wider text-[11px]">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Quick Sign-in</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {personas.slice(0, 4).map((p) => (
                <button
                  key={p.id}
                  onClick={() => {
                    switchUser(p.id);
                    closeAuthModal();
                  }}
                  className="flex items-center gap-2.5 p-2.5 rounded-xl border border-orange-100 hover:border-orange-400 hover:bg-orange-50 text-left transition-all group"
                >
                  <img
                    src={p.avatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80"}
                    alt={p.name}
                    className="w-8 h-8 rounded-full object-cover shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="font-bold text-gray-900 truncate group-hover:text-orange-700 flex items-center gap-1">
                      <span>{p.name}</span>
                      {p.role === "admin" && <ShieldCheck className="w-3 h-3 text-red-700 shrink-0" />}
                    </div>
                    <div className="text-[10px] text-gray-500 truncate">
                      {p.role === "admin"
                        ? "Owner · Rajrani Namkeen Centre"
                        : p.role === "seller"
                        ? "Staff · Store Panel"
                        : "Customer"}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div className="relative flex items-center justify-center">
            <div className="border-t border-orange-100 w-full" />
            <span className="bg-white px-3 text-[11px] font-bold text-gray-400 uppercase tracking-wider absolute">
              New customer registration
            </span>
          </div>

          <form onSubmit={handleRegister} className="space-y-4">
            {error && (
              <div className="bg-rose-50 border border-rose-200 text-rose-700 p-3 rounded-xl text-xs">{error}</div>
            )}
            <div>
              <label className="block text-gray-700 font-bold mb-1">Full Name</label>
              <input
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Rohit Agarwal"
                className="w-full bg-orange-50/60 border border-orange-100 rounded-xl px-3 py-2 text-xs focus:bg-white focus:border-orange-400 outline-hidden"
              />
            </div>
            <div>
              <label className="block text-gray-700 font-bold mb-1">Email Address</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="rohit@gmail.com"
                className="w-full bg-orange-50/60 border border-orange-100 rounded-xl px-3 py-2 text-xs focus:bg-white focus:border-orange-400 outline-hidden"
              />
            </div>
            <div>
              <label className="block text-gray-700 font-bold mb-1">Mobile Number (optional)</label>
              <div className="flex items-center gap-2">
                <span className="bg-orange-100 text-orange-800 font-bold rounded-xl px-3 py-2 text-xs">+91</span>
                <input
                  value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/[^0-9\s-]/g, ""))}
                  placeholder="98XXX XXXXX"
                  className="flex-1 bg-orange-50/60 border border-orange-100 rounded-xl px-3 py-2 text-xs focus:bg-white focus:border-orange-400 outline-hidden font-mono"
                />
              </div>
              <p className="text-[11px] text-gray-400 mt-1 flex items-center gap-1">
                <UserRound className="w-3 h-3" />
                Used for delivery coordination & order SMS alerts.
              </p>
            </div>
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 bg-orange-600 hover:bg-orange-700 disabled:opacity-50 text-white font-bold rounded-xl shadow-md shadow-orange-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>{isSubmitting ? "Creating account..." : "Create Account & Start Shopping"}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <p className="text-[10px] text-gray-400 text-center">
              By continuing you agree to store policies · Fresh item deliveries within Bikaner only.
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}

"use client";

import React, { useState, useEffect, useCallback } from "react";
import { useAuth } from "@/context/AuthContext";
import {
  ShieldCheck,
  TrendingUp,
  ShoppingBag,
  IndianRupee,
  Tag,
  Settings,
  Trash2,
  Plus,
  RefreshCw,
  Percent,
  Search,
  Eye,
  Check,
  ReceiptText,
  PackageOpen,
  Users,
} from "lucide-react";

interface AdminDashboardProps {
  onOpenProductDetail?: (productId: string) => void;
}

export function AdminDashboard({ onOpenProductDetail }: AdminDashboardProps) {
  const { refreshSession } = useAuth();
  const [activeTab, setActiveTab] = useState<"overview" | "products" | "orders" | "coupons" | "team" | "settings">("overview");
  const [teamList, setTeamList] = useState<any[]>([]);
  const [staffName, setStaffName] = useState("");
  const [staffEmail, setStaffEmail] = useState("");
  const [staffPhone, setStaffPhone] = useState("");
  const [isAddingStaff, setIsAddingStaff] = useState(false);
  const [staffError, setStaffError] = useState("");
  const [analytics, setAnalytics] = useState<any>(null);
  const [productsList, setProductsList] = useState<any[]>([]);
  const [ordersList, setOrdersList] = useState<any[]>([]);
  const [couponsList, setCouponsList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [productSearch, setProductSearch] = useState("");
  const [settingsSaved, setSettingsSaved] = useState(false);
  const [gstRate, setGstRate] = useState("12");
  const [freeShip, setFreeShip] = useState("499");

  const [isNewCouponOpen, setIsNewCouponOpen] = useState(false);
  const [couponCode, setCouponCode] = useState("");
  const [couponDesc, setCouponDesc] = useState("");
  const [couponDiscount, setCouponDiscount] = useState("10");
  const [couponType, setCouponType] = useState<"percentage" | "fixed">("percentage");
  const [couponMinSpend, setCouponMinSpend] = useState("299");

  const fetchAllData = useCallback(async () => {
    setLoading(true);
    try {
      const [analyticsRes, productsRes, ordersRes, couponsRes, teamRes] = await Promise.all([
        fetch("/api/admin/analytics"),
        fetch("/api/products?status=all&limit=100"),
        fetch("/api/orders"),
        fetch("/api/coupons"),
        fetch("/api/staff"),
      ]);
      if (analyticsRes.ok) setAnalytics(await analyticsRes.json());
      if (productsRes.ok) setProductsList((await productsRes.json()).products || []);
      if (ordersRes.ok) setOrdersList((await ordersRes.json()).orders || []);
      if (couponsRes.ok) setCouponsList((await couponsRes.json()).coupons || []);
      if (teamRes.ok) setTeamList((await teamRes.json()).team || []);
    } catch (e) {
      console.error("Owner data fetch error", e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchAllData();
  }, [fetchAllData]);

  const handleToggleFeatured = async (product: any) => {
    const next = !product.isFeatured;
    setProductsList((prev) => prev.map((p) => (p.id === product.id ? { ...p, isFeatured: next } : p)));
    await fetch(`/api/products/${product.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isFeatured: next }),
    });
  };

  const handleDeleteProduct = async (id: string) => {
    if (!confirm("Delete this product permanently?")) return;
    setProductsList((prev) => prev.filter((p) => p.id !== id));
    await fetch(`/api/products/${id}`, { method: "DELETE" });
  };

  const handleUpdateOrderStatus = async (orderId: string, status: string) => {
    setOrdersList((prev) => prev.map((o) => (o.id === orderId ? { ...o, status } : o)));
    await fetch(`/api/orders/${orderId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
  };

  const handleCreateCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch("/api/coupons", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        code: couponCode,
        description: couponDesc,
        discountValue: couponDiscount,
        discountType: couponType,
        minSpend: couponMinSpend,
      }),
    });
    if (res.ok) {
      const data = await res.json();
      setCouponsList((prev) => [data.coupon, ...prev]);
      setIsNewCouponOpen(false);
      setCouponCode("");
      setCouponDesc("");
    } else {
      alert("Coupon code already exists or invalid details.");
    }
  };

  const handleDeleteCoupon = async (id: string) => {
    if (!confirm("Delete this coupon?")) return;
    setCouponsList((prev) => prev.filter((c) => c.id !== id));
    await fetch(`/api/coupons?id=${id}`, { method: "DELETE" });
  };

  const handleAddStaff = async (e: React.FormEvent) => {
    e.preventDefault();
    setStaffError("");
    setIsAddingStaff(true);
    try {
      const res = await fetch("/api/staff", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: staffName, email: staffEmail, phone: staffPhone }),
      });
      const data = await res.json();
      if (res.ok && data.staff) {
        setTeamList((prev) => [data.staff, ...prev]);
        setStaffName("");
        setStaffEmail("");
        setStaffPhone("");
        // refresh switcher list so you can sign in as the new staff member
        await refreshSession();
      } else {
        setStaffError(data.error || "Could not add staff member");
      }
    } catch {
      setStaffError("Something went wrong. Try again.");
    } finally {
      setIsAddingStaff(false);
    }
  };

  const handleRevokeStaff = async (member: any) => {
    if (!confirm(`Revoke Store Panel access for ${member.name}?`)) return;
    setTeamList((prev) => prev.filter((m) => m.id !== member.id));
    await fetch(`/api/staff?id=${member.id}`, { method: "DELETE" });
    await refreshSession();
  };

  const metrics = analytics?.metrics || {};
  const timeline = analytics?.revenueTimeline || [
    { month: "Jan", gmv: 342000 },
    { month: "Feb", gmv: 428500 },
    { month: "Mar", gmv: 519000 },
    { month: "Apr", gmv: 634000 },
    { month: "May", gmv: 761000 },
    { month: "Jun", gmv: 825400 },
  ];
  const maxGmv = Math.max(...timeline.map((t: any) => t.gmv), 1);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in duration-200">
      {/* Header */}
      <div className="bg-gradient-to-r from-red-950 via-red-900 to-orange-900 rounded-3xl p-6 sm:p-8 text-white flex flex-col md:flex-row items-start md:items-center justify-between gap-6 shadow-xl border border-red-900/60">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="bg-yellow-400/20 text-yellow-300 text-xs font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full border border-yellow-400/40 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Owner Panel · Since 1985</span>
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">Business Control Room</h1>
          <p className="text-xs sm:text-sm text-orange-100/70 mt-1">
            Sales analytics, GST summary, product moderation, order status control & coupon engine for BILOKAT.
          </p>
        </div>
        <button
          onClick={fetchAllData}
          disabled={loading}
          className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white text-xs font-semibold rounded-xl border border-white/20 flex items-center gap-2 transition-all"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
          <span>Refresh Live Data</span>
        </button>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-orange-100 shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-gray-500">
            <span className="text-xs font-bold uppercase tracking-wider">Total Sales</span>
            <div className="w-8 h-8 rounded-lg bg-orange-50 text-orange-600 flex items-center justify-center">
              <IndianRupee className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-gray-900">
            ₹{Math.round(metrics.gmv || 0).toLocaleString("en-IN")}
          </div>
          <p className="text-[11px] text-emerald-600 font-medium flex items-center gap-1">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>+18.6% vs last month</span>
          </p>
        </div>
        <div className="bg-white p-5 rounded-2xl border border-orange-100 shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-gray-500">
            <span className="text-xs font-bold uppercase tracking-wider">GST Collected (12%)</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <ReceiptText className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-emerald-600">
            ₹{Math.round(ordersList.reduce((a: number, o: any) => a + (o.tax || 0), 0)).toLocaleString("en-IN")}
          </div>
          <p className="text-[11px] text-gray-500">Auto-reports for GSTR filing</p>
        </div>
        <div className="bg-white p-5 rounded-2xl border border-orange-100 shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-gray-500">
            <span className="text-xs font-bold uppercase tracking-wider">Total Orders</span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
              <ShoppingBag className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-gray-900">{ordersList.length}</div>
          <p className="text-[11px] text-gray-500">
            Avg order: ₹
            {ordersList.length
              ? Math.round(ordersList.reduce((a: number, o: any) => a + (o.grandTotal || 0), 0) / ordersList.length).toLocaleString("en-IN")
              : 0}
          </p>
        </div>
        <div className="bg-white p-5 rounded-2xl border border-orange-100 shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-gray-500">
            <span className="text-xs font-bold uppercase tracking-wider">Live Products</span>
            <div className="w-8 h-8 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center">
              <PackageOpen className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-gray-900">{productsList.length}</div>
          <p className="text-[11px] text-gray-500">
            {productsList.filter((p: any) => p.stockQuantity <= 20).length} low-stock alerts
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-orange-100 pb-2 overflow-x-auto">
        {[
          { id: "overview", label: "Sales Analytics", icon: TrendingUp },
          { id: "products", label: `Products (${productsList.length})`, icon: PackageOpen },
          { id: "orders", label: `Orders (${ordersList.length})`, icon: ShoppingBag },
          { id: "coupons", label: `Coupons (${couponsList.length})`, icon: Tag },
          { id: "team", label: `Team Access (${teamList.length})`, icon: Users },
          { id: "settings", label: "Settings & GST", icon: Settings },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center gap-2 ${
              activeTab === tab.id ? "bg-red-900 text-white shadow-md" : "text-orange-900/60 hover:bg-orange-100"
            }`}
          >
            <tab.icon className="w-3.5 h-3.5" />
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* OVERVIEW */}
      {activeTab === "overview" && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-orange-100 shadow-2xs">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-extrabold text-gray-900">Monthly Sales (₹)</h3>
                <p className="text-xs text-gray-500">Last 6 months revenue trend</p>
              </div>
            </div>
            <div className="grid grid-cols-6 gap-3 sm:gap-6 items-end h-52 pt-4">
              {timeline.map((t: any, idx: number) => (
                <div key={idx} className="flex flex-col items-center gap-2 h-full justify-end group">
                  <div className="text-[10px] font-mono text-gray-400 group-hover:text-orange-600 font-bold opacity-0 group-hover:opacity-100 transition-opacity">
                    ₹{(t.gmv / 1000).toFixed(0)}k
                  </div>
                  <div className="w-full max-w-[56px] h-40 bg-orange-50 rounded-xl p-1 flex items-end">
                    <div
                      className="w-full bg-gradient-to-t from-orange-500 to-yellow-400 rounded-lg transition-all"
                      style={{ height: `${Math.max(6, Math.round((t.gmv / maxGmv) * 100))}%` }}
                    />
                  </div>
                  <span className="text-xs font-bold text-gray-700">{t.month}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-3xl border border-orange-100 shadow-2xs space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-gray-900">Category Mix (est. revenue)</h4>
              {[
                { name: "Bhujia & Sev", pct: 34, rev: "₹2.8L" },
                { name: "Festive Combos & Gifts", pct: 22, rev: "₹1.8L" },
                { name: "Mixtures", pct: 21, rev: "₹1.7L" },
                { name: "Mathri & Papadi", pct: 12, rev: "₹1.0L" },
                { name: "Fresh Counter Items", pct: 11, rev: "₹0.9L" },
              ].map((c) => (
                <div key={c.name} className="space-y-1 text-xs">
                  <div className="flex justify-between font-semibold">
                    <span className="text-gray-800">{c.name}</span>
                    <span className="text-orange-700">
                      {c.rev} ({c.pct}%)
                    </span>
                  </div>
                  <div className="w-full bg-orange-50 rounded-full h-2">
                    <div className="bg-gradient-to-r from-orange-500 to-yellow-400 h-full rounded-full" style={{ width: `${c.pct}%` }} />
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-white p-6 rounded-3xl border border-orange-100 shadow-2xs space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-gray-900">Recent Orders</h4>
              <div className="divide-y divide-orange-50">
                {ordersList.slice(0, 5).map((o: any) => (
                  <div key={o.id} className="py-3 flex items-center justify-between text-xs">
                    <div>
                      <div className="font-mono font-bold text-orange-700">{o.orderNumber}</div>
                      <div className="text-[11px] text-gray-500">
                        {o.shippingAddress?.fullName} · {o.shippingAddress?.city}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-black text-gray-900">₹{o.grandTotal}</div>
                      <span
                        className={`text-[10px] font-bold uppercase ${
                          o.status === "delivered" ? "text-emerald-600" : o.status === "shipped" ? "text-blue-600" : "text-amber-600"
                        }`}
                      >
                        {o.status}
                      </span>
                    </div>
                  </div>
                ))}
                {ordersList.length === 0 && <p className="text-xs text-gray-400 py-6 text-center">No orders yet.</p>}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* PRODUCTS */}
      {activeTab === "products" && (
        <div className="space-y-4">
          <div className="relative w-full sm:w-80">
            <input
              placeholder="Search products..."
              value={productSearch}
              onChange={(e) => setProductSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-white border border-orange-200 rounded-xl text-xs focus:outline-hidden focus:border-orange-400"
            />
            <Search className="w-4 h-4 text-orange-300 absolute left-3 top-2.5" />
          </div>
          <div className="bg-white rounded-3xl border border-orange-100 overflow-hidden shadow-2xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-orange-50/70 text-orange-900/60 uppercase tracking-wider font-bold border-b border-orange-100 text-[10px]">
                  <tr>
                    <th className="p-4">Product</th>
                    <th className="p-4">Price</th>
                    <th className="p-4">Stock</th>
                    <th className="p-4">Units Sold</th>
                    <th className="p-4">Bestseller</th>
                    <th className="p-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-orange-50">
                  {productsList
                    .filter((p: any) => p.title.toLowerCase().includes(productSearch.toLowerCase()))
                    .map((prod: any) => (
                      <tr key={prod.id} className="hover:bg-orange-50/40 transition-colors">
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <img src={prod.images?.[0]} alt="" className="w-10 h-10 rounded-lg object-cover bg-orange-50" />
                            <div>
                              <div className="font-bold text-gray-900 max-w-xs truncate">{prod.title}</div>
                              <div className="text-[11px] text-gray-500">{prod.category?.name}</div>
                            </div>
                          </div>
                        </td>
                        <td className="p-4 font-black text-gray-900">₹{prod.price}</td>
                        <td className="p-4">
                          <span className={`font-bold ${prod.stockQuantity <= 20 ? "text-amber-600" : "text-emerald-700"}`}>
                            {prod.stockQuantity} packs
                          </span>
                        </td>
                        <td className="p-4 text-gray-600 font-medium">{prod.salesCount || 0}</td>
                        <td className="p-4">
                          <button
                            onClick={() => handleToggleFeatured(prod)}
                            className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase transition-all ${
                              prod.isFeatured
                                ? "bg-orange-100 text-orange-700 border border-orange-200"
                                : "bg-gray-100 text-gray-500 hover:bg-gray-200"
                            }`}
                          >
                            {prod.isFeatured ? "★ Featured" : "Normal"}
                          </button>
                        </td>
                        <td className="p-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => onOpenProductDetail && onOpenProductDetail(prod.id)}
                              className="p-1.5 text-gray-500 hover:text-orange-600 hover:bg-orange-50 rounded-lg"
                            >
                              <Eye className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleDeleteProduct(prod.id)}
                              className="p-1.5 text-gray-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ORDERS */}
      {activeTab === "orders" && (
        <div className="bg-white rounded-3xl border border-orange-100 overflow-hidden shadow-2xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-orange-50/70 text-orange-900/60 uppercase tracking-wider font-bold border-b border-orange-100 text-[10px]">
                <tr>
                  <th className="p-4">Order #</th>
                  <th className="p-4">Customer</th>
                  <th className="p-4">Items</th>
                  <th className="p-4">Total</th>
                  <th className="p-4">Payment</th>
                  <th className="p-4">Status</th>
                  <th className="p-4">Placed</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-orange-50">
                {ordersList.map((order: any) => (
                  <tr key={order.id} className="hover:bg-orange-50/40 transition-colors">
                    <td className="p-4 font-mono font-bold text-orange-700">{order.orderNumber}</td>
                    <td className="p-4">
                      <div className="font-semibold text-gray-900">{order.shippingAddress?.fullName}</div>
                      <div className="text-[11px] text-gray-500">
                        {order.shippingAddress?.city}, {order.shippingAddress?.state}
                      </div>
                    </td>
                    <td className="p-4 text-gray-600">{order.items?.length || 0} packs</td>
                    <td className="p-4 font-black text-gray-900">₹{order.grandTotal}</td>
                    <td className="p-4 uppercase text-[11px] font-bold text-gray-600">
                      {order.paymentMethod === "upi" ? "UPI" : order.paymentMethod === "cod" ? "COD" : "Card"}
                    </td>
                    <td className="p-4">
                      <select
                        value={order.status}
                        onChange={(e) => handleUpdateOrderStatus(order.id, e.target.value)}
                        className={`text-[11px] font-bold uppercase px-2 py-1 rounded-lg border outline-hidden ${
                          order.status === "delivered"
                            ? "bg-emerald-50 text-emerald-700 border-emerald-200"
                            : order.status === "shipped"
                            ? "bg-blue-50 text-blue-700 border-blue-200"
                            : order.status === "cancelled"
                            ? "bg-rose-50 text-rose-700 border-rose-200"
                            : "bg-amber-50 text-amber-700 border-amber-200"
                        }`}
                      >
                        <option value="processing">Processing</option>
                        <option value="shipped">Shipped</option>
                        <option value="delivered">Delivered</option>
                        <option value="cancelled">Cancelled</option>
                      </select>
                    </td>
                    <td className="p-4 text-gray-400 text-[11px]">{new Date(order.createdAt).toLocaleDateString("en-IN")}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* COUPONS */}
      {activeTab === "coupons" && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-extrabold text-gray-900">Active Coupons</h3>
            <button
              onClick={() => setIsNewCouponOpen(true)}
              className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-md shadow-orange-600/20"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Create Coupon</span>
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {couponsList.map((cpn: any) => (
              <div key={cpn.id} className="bg-white border border-orange-100 rounded-2xl p-4 shadow-2xs space-y-2 relative">
                <button
                  onClick={() => handleDeleteCoupon(cpn.id)}
                  className="absolute top-3 right-3 text-gray-300 hover:text-rose-500"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
                <span className="font-mono font-black text-lg text-orange-700 bg-orange-50 px-2.5 py-0.5 rounded-lg inline-block">
                  {cpn.code}
                </span>
                <p className="text-xs text-gray-600">{cpn.description}</p>
                <div className="flex items-center justify-between text-[11px] text-gray-500">
                  <span>
                    Min order: <strong className="text-gray-800">₹{cpn.minSpend}</strong>
                  </span>
                  <span className="text-emerald-700 font-bold">
                    {cpn.discountType === "percentage" ? `${cpn.discountValue}% off` : `₹${cpn.discountValue} off`}
                  </span>
                </div>
                <p className="text-[11px] text-gray-400">Used {cpn.timesUsed || 0} times</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TEAM ACCESS — who can open Store Panel */}
      {activeTab === "team" && (
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          {/* Add staff form */}
          <form
            onSubmit={handleAddStaff}
            className="lg:col-span-2 bg-white p-6 rounded-3xl border border-orange-100 shadow-2xs space-y-4 text-xs self-start"
          >
            <div>
              <h3 className="text-base font-bold text-gray-900 flex items-center gap-2">
                <Users className="w-4 h-4 text-orange-600" />
                <span>Add Staff Member</span>
              </h3>
              <p className="text-xs text-gray-500 mt-1">
                Staff gets <strong>Store Panel</strong> access (products, orders, fulfilment, sales view) — but
                <strong> not</strong> the Owner Panel, payouts or bank settings.
              </p>
            </div>

            {staffError && (
              <div className="bg-rose-50 border border-rose-200 text-rose-700 p-3 rounded-xl">{staffError}</div>
            )}

            <div>
              <label className="block text-gray-700 font-bold mb-1">Staff Name</label>
              <input
                required
                value={staffName}
                onChange={(e) => setStaffName(e.target.value)}
                placeholder="e.g. Kishore Yadav"
                className="w-full bg-orange-50/60 border border-orange-100 rounded-xl px-3 py-2"
              />
            </div>
            <div>
              <label className="block text-gray-700 font-bold mb-1">Email / Login ID</label>
              <input
                type="email"
                required
                value={staffEmail}
                onChange={(e) => setStaffEmail(e.target.value)}
                placeholder="staff@rajrani.in"
                className="w-full bg-orange-50/60 border border-orange-100 rounded-xl px-3 py-2"
              />
            </div>
            <div>
              <label className="block text-gray-700 font-bold mb-1">Mobile (optional)</label>
              <input
                value={staffPhone}
                onChange={(e) => setStaffPhone(e.target.value)}
                placeholder="+91 98XXX XXXXX"
                className="w-full bg-orange-50/60 border border-orange-100 rounded-xl px-3 py-2 font-mono"
              />
            </div>
            <button
              type="submit"
              disabled={isAddingStaff}
              className="w-full py-2.5 bg-orange-600 hover:bg-orange-700 disabled:opacity-50 text-white font-bold rounded-xl shadow-md shadow-orange-600/20 transition-all flex items-center justify-center gap-2"
            >
              <Plus className="w-4 h-4" />
              <span>{isAddingStaff ? "Adding..." : "Grant Store Panel Access"}</span>
            </button>
          </form>

          {/* Team list */}
          <div className="lg:col-span-3 bg-white rounded-3xl border border-orange-100 shadow-2xs overflow-hidden self-start">
            <div className="px-6 py-4 border-b border-orange-50 bg-orange-50/50">
              <h3 className="text-sm font-extrabold text-gray-900">People With Panel Access</h3>
              <p className="text-xs text-gray-500">Sirf ye log Store Panel khol sakte hain</p>
            </div>
            <div className="divide-y divide-orange-50">
              {teamList.map((member) => (
                <div key={member.id} className="p-4 px-6 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={member.avatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80"}
                      alt={member.name}
                      className="w-10 h-10 rounded-full object-cover"
                    />
                    <div>
                      <div className="text-xs font-bold text-gray-900 flex items-center gap-2">
                        <span>{member.name}</span>
                        <span
                          className={`text-[9px] font-bold px-1.5 py-0.5 rounded-sm uppercase tracking-wider ${
                            member.role === "admin" ? "bg-red-100 text-red-700" : "bg-amber-100 text-amber-800"
                          }`}
                        >
                          {member.role === "admin" ? "Owner — Full Access" : "Staff — Store Panel"}
                        </span>
                      </div>
                      <div className="text-[11px] text-gray-500 mt-0.5">
                        {member.email} {member.phone ? `· ${member.phone}` : ""}
                      </div>
                    </div>
                  </div>
                  {member.role !== "admin" && (
                    <button
                      onClick={() => handleRevokeStaff(member)}
                      className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-bold rounded-xl transition-colors shrink-0"
                    >
                      Revoke
                    </button>
                  )}
                </div>
              ))}
              {teamList.length === 0 && (
                <p className="text-xs text-gray-400 p-8 text-center">No staff yet — add your first helper above.</p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* SETTINGS */}
      {activeTab === "settings" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-3xl border border-orange-100 shadow-2xs space-y-4 text-xs">
            <div>
              <h3 className="text-base font-bold text-gray-900">Store & Pricing Settings</h3>
              <p className="text-xs text-gray-500 mt-0.5">Applied to all checkout calculations</p>
            </div>
            <div>
              <label className="block text-gray-700 font-bold mb-1">GST Rate (%)</label>
              <input
                value={gstRate}
                onChange={(e) => setGstRate(e.target.value)}
                className="w-full bg-orange-50/60 border border-orange-100 rounded-xl px-3 py-2 font-bold text-gray-900"
              />
              <p className="text-[11px] text-gray-500 mt-1">Branded namkeen HSN 2106 90 — current slab 12%.</p>
            </div>
            <div>
              <label className="block text-gray-700 font-bold mb-1">Free Delivery Above (₹)</label>
              <input
                value={freeShip}
                onChange={(e) => setFreeShip(e.target.value)}
                className="w-full bg-orange-50/60 border border-orange-100 rounded-xl px-3 py-2 font-bold text-gray-900"
              />
            </div>
            <button
              onClick={() => {
                setSettingsSaved(true);
                setTimeout(() => setSettingsSaved(false), 2500);
              }}
              className="px-6 py-2.5 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl shadow-md transition-all flex items-center gap-2"
            >
              {settingsSaved ? <Check className="w-4 h-4" /> : <Settings className="w-4 h-4" />}
              <span>{settingsSaved ? "Saved!" : "Save Settings"}</span>
            </button>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-orange-100 shadow-2xs space-y-3 text-xs">
            <h3 className="text-base font-bold text-gray-900">Registration & Compliance</h3>
            {[
              ["GSTIN", "08AABCR3456F1Z5"],
              ["FSSAI License", "12214034001234"],
              ["Legal Name", "Rajrani Namkeen Centre, Bikaner"],
              ["Registered Address", "Shop 12, Main Bhujia Bazaar, Bikaner, Rajasthan 334001"],
              ["Settlement Account", "HDFC Bank ·••• 4521 (Current A/C)"],
              ["IFSC", "HDFC0000456"],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between gap-4 py-2 border-b border-orange-50 last:border-0">
                <span className="text-gray-500">{k}</span>
                <span className="font-mono font-semibold text-gray-900 text-right">{v}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* New Coupon Modal */}
      {isNewCouponOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <form
            onSubmit={handleCreateCoupon}
            className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-orange-100 space-y-4 text-xs"
          >
            <h3 className="text-sm font-bold text-gray-900">Create Store Coupon</h3>
            <div>
              <label className="block text-gray-700 font-medium mb-1">Coupon Code</label>
              <input
                required
                value={couponCode}
                onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                placeholder="e.g. BHAJIA20"
                className="w-full bg-orange-50/60 border border-orange-100 uppercase font-mono rounded-xl px-3 py-2"
              />
            </div>
            <div>
              <label className="block text-gray-700 font-medium mb-1">Description</label>
              <input
                value={couponDesc}
                onChange={(e) => setCouponDesc(e.target.value)}
                placeholder="e.g. 20% off on bhujia range"
                className="w-full bg-orange-50/60 border border-orange-100 rounded-xl px-3 py-2"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-gray-700 font-medium mb-1">Type</label>
                <select
                  value={couponType}
                  onChange={(e) => setCouponType(e.target.value as any)}
                  className="w-full bg-orange-50/60 border border-orange-100 rounded-xl px-3 py-2"
                >
                  <option value="percentage">Percentage (%)</option>
                  <option value="fixed">Flat Amount (₹)</option>
                </select>
              </div>
              <div>
                <label className="block text-gray-700 font-medium mb-1">Value</label>
                <input
                  required
                  type="number"
                  value={couponDiscount}
                  onChange={(e) => setCouponDiscount(e.target.value)}
                  className="w-full bg-orange-50/60 border border-orange-100 rounded-xl px-3 py-2"
                />
              </div>
            </div>
            <div>
              <label className="block text-gray-700 font-medium mb-1">Minimum Order (₹)</label>
              <input
                type="number"
                value={couponMinSpend}
                onChange={(e) => setCouponMinSpend(e.target.value)}
                className="w-full bg-orange-50/60 border border-orange-100 rounded-xl px-3 py-2"
              />
            </div>
            <div className="flex gap-2 justify-end pt-2">
              <button
                type="button"
                onClick={() => setIsNewCouponOpen(false)}
                className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold rounded-xl"
              >
                Cancel
              </button>
              <button type="submit" className="px-5 py-2 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl">
                Create Coupon
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}

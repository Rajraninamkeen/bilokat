"use client";

import React, { useState, useEffect } from "react";
import { ProductCard } from "@/components/product/ProductCard";
import {
  Store,
  Star,
  ShieldCheck,
  Mail,
  Phone,
  ArrowLeft,
  Search,
  Filter,
  Layers,
  Sparkles,
} from "lucide-react";

interface SellerStorefrontProps {
  vendorSlug: string;
  onBack: () => void;
  onSelectProduct: (product: any) => void;
}

export function SellerStorefront({ vendorSlug, onBack, onSelectProduct }: SellerStorefrontProps) {
  const [vendorData, setVendorData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");

  useEffect(() => {
    setLoading(true);
    fetch(`/api/vendors/${vendorSlug}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.vendor) {
          setVendorData(data.vendor);
        }
      })
      .catch((e) => console.error("Error fetching vendor storefront", e))
      .finally(() => setLoading(false));
  }, [vendorSlug]);

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-16 flex flex-col items-center justify-center space-y-3">
        <div className="w-10 h-10 border-4 border-orange-600 border-t-transparent rounded-full animate-spin" />
        <p className="text-xs font-semibold text-gray-500">Loading seller storefront...</p>
      </div>
    );
  }

  if (!vendorData) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-16 text-center space-y-4">
        <h2 className="text-xl font-bold text-gray-900">Vendor Not Found</h2>
        <button
          onClick={onBack}
          className="px-4 py-2 bg-orange-600 text-white text-xs font-bold rounded-xl"
        >
          Return to Marketplace
        </button>
      </div>
    );
  }

  const products = vendorData.products || [];
  const filteredProducts = products.filter((p: any) => {
    const matchesSearch = p.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "all" || p.category?.slug === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  // Extract unique categories
  const categories = Array.from(new Set(products.map((p: any) => p.category?.name).filter(Boolean)));

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* 1. Back button & Store Banner */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-1.5 text-xs font-bold text-gray-600 hover:text-orange-600 bg-white px-3 py-1.5 rounded-xl border border-gray-200 transition-colors shadow-2xs mb-4"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Marketplace</span>
        </button>
      </div>

      {/* Store Banner & Bio Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl overflow-hidden bg-slate-900 border border-gray-200 shadow-xl">
          {/* Banner Image */}
          <div className="h-44 sm:h-64 w-full relative">
            <img
              src={vendorData.bannerUrl || "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1200&q=80"}
              alt={vendorData.storeName}
              className="w-full h-full object-cover opacity-60"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
          </div>

          {/* Store Info Overlay */}
          <div className="p-6 sm:p-8 relative -mt-16 sm:-mt-20 flex flex-col md:flex-row items-start md:items-end justify-between gap-6 text-white">
            <div className="flex flex-col sm:flex-row items-start sm:items-end gap-5">
              <img
                src={vendorData.logoUrl || "https://images.unsplash.com/photo-1550009158-9ebf69173e03?auto=format&fit=crop&w=200&q=80"}
                alt={vendorData.storeName}
                className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl object-cover border-4 border-slate-900 shadow-2xl bg-white shrink-0"
              />
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h1 className="text-2xl sm:text-3xl font-black tracking-tight">{vendorData.storeName}</h1>
                  <span className="bg-emerald-500/20 text-emerald-300 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border border-emerald-400/30 flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3 text-emerald-400" />
                    <span>Verified Seller</span>
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
                  {vendorData.description}
                </p>
                <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400 pt-2">
                  <span className="flex items-center text-amber-400 font-bold">
                    <Star className="w-4 h-4 fill-amber-400 mr-1" />
                    {(vendorData.rating || 4.9).toFixed(1)} Rating
                  </span>
                  <span>•</span>
                  <span>{products.length} Products Available</span>
                  <span>•</span>
                  <span>{vendorData.reviewCount || 100}+ Customer Reviews</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Store Catalog & Filters */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-white p-4 rounded-2xl border border-gray-200 shadow-2xs">
          <div className="relative w-full sm:w-80">
            <input
              type="text"
              placeholder={`Search ${vendorData.storeName}...`}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-xs focus:bg-white focus:outline-hidden focus:border-orange-500"
            />
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
          </div>

          <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto text-xs">
            <button
              onClick={() => setSelectedCategory("all")}
              className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
                selectedCategory === "all"
                  ? "bg-slate-900 text-white shadow-xs"
                  : "bg-gray-100 text-gray-600 hover:bg-gray-200"
              }`}
            >
              All Items ({products.length})
            </button>
            {categories.map((catName: any) => (
              <button
                key={catName}
                onClick={() => setSelectedCategory(catName)}
                className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
                  selectedCategory === catName
                    ? "bg-slate-900 text-white shadow-xs"
                    : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                }`}
              >
                {catName}
              </button>
            ))}
          </div>
        </div>

        {/* Product Grid */}
        {filteredProducts.length === 0 ? (
          <div className="bg-white rounded-3xl border border-gray-200 p-12 text-center space-y-3">
            <Store className="w-12 h-12 text-gray-300 mx-auto" />
            <h3 className="text-sm font-bold text-gray-900">No products match your filter</h3>
            <p className="text-xs text-gray-500">Try clearing the search query to view all store listings.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
            {filteredProducts.map((product: any) => (
              <ProductCard
                key={product.id}
                product={{
                  ...product,
                  vendor: {
                    id: vendorData.id,
                    storeName: vendorData.storeName,
                    slug: vendorData.slug,
                    rating: vendorData.rating,
                  },
                }}
                onSelectProduct={onSelectProduct}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

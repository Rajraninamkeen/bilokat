"use client";

import React, { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import {
  Store,
  DollarSign,
  ShoppingBag,
  Truck,
  AlertTriangle,
  Plus,
  Edit,
  Trash2,
  ExternalLink,
  CheckCircle2,
  TrendingUp,
  Percent,
  Search,
  Eye,
  Check,
  Send,
  Building2,
  X,
  Sparkles,
} from "lucide-react";

interface SellerDashboardProps {
  onOpenStorefront?: (vendorSlug: string) => void;
  onOpenProductDetail?: (productId: string) => void;
}

export function SellerDashboard({ onOpenStorefront, onOpenProductDetail }: SellerDashboardProps) {
  const { vendor, user, refreshSession } = useAuth();

  const [activeTab, setActiveTab] = useState<"overview" | "products" | "orders" | "payouts" | "settings">("overview");
  const [analytics, setAnalytics] = useState<any>(null);
  const [productsList, setProductsList] = useState<any[]>([]);
  const [categoriesList, setCategoriesList] = useState<any[]>([]);
  const [ordersList, setOrdersList] = useState<any[]>([]);
  const [payoutsList, setPayoutsList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Search & Filter
  const [productSearch, setProductSearch] = useState("");
  const [orderStatusFilter, setOrderStatusFilter] = useState("all");

  // Product Create/Edit Modal state
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [editingProductId, setEditingProductId] = useState<string | null>(null);
  const [productForm, setProductForm] = useState({
    title: "",
    description: "",
    shortDescription: "",
    price: "",
    compareAtPrice: "",
    sku: "",
    stockQuantity: "25",
    categoryId: "",
    images: "",
    tags: "",
    isFeatured: false,
  });

  // Fulfillment modal state
  const [fulfillingItem, setFulfillingItem] = useState<any>(null);
  const [carrierName, setCarrierName] = useState("FedEx Express");
  const [trackingNumber, setTrackingNumber] = useState("");

  // Payout request modal state
  const [isPayoutModalOpen, setIsPayoutModalOpen] = useState(false);
  const [payoutAmount, setPayoutAmount] = useState("1000");

  // Store Settings Form state
  const [storeForm, setStoreForm] = useState({
    storeName: vendor?.storeName || "",
    description: vendor?.description || "",
    contactEmail: vendor?.contactEmail || "",
    logoUrl: vendor?.logoUrl || "",
    bannerUrl: vendor?.bannerUrl || "",
    bankName: vendor?.bankName || "",
    bankAccountNumber: vendor?.bankAccountNumber || "",
  });

  const fetchData = async () => {
    setLoading(true);
    try {
      const [analyticsRes, productsRes, catsRes, ordersRes, payoutsRes] = await Promise.all([
        fetch("/api/seller/analytics"),
        fetch(`/api/products?vendorId=${vendor?.id || "all"}&limit=100`),
        fetch("/api/categories"),
        fetch("/api/orders"),
        fetch("/api/seller/payouts"),
      ]);

      if (analyticsRes.ok) setAnalytics(await analyticsRes.json());
      if (productsRes.ok) {
        const pData = await productsRes.json();
        // filter for this vendor
        if (vendor) {
          setProductsList(pData.products.filter((p: any) => p.vendorId === vendor.id));
        } else {
          setProductsList(pData.products);
        }
      }
      if (catsRes.ok) setCategoriesList((await catsRes.json()).categories || []);
      if (ordersRes.ok) setOrdersList((await ordersRes.json()).orders || []);
      if (payoutsRes.ok) setPayoutsList((await payoutsRes.json()).payouts || []);
    } catch (e) {
      console.error("Seller data fetch error", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [vendor]);

  useEffect(() => {
    if (vendor) {
      setStoreForm({
        storeName: vendor.storeName || "",
        description: vendor.description || "",
        contactEmail: vendor.contactEmail || "",
        logoUrl: vendor.logoUrl || "",
        bannerUrl: vendor.bannerUrl || "",
        bankName: vendor.bankName || "Silicon Valley Bank",
        bankAccountNumber: vendor.bankAccountNumber || "•••• 8492",
      });
    }
  }, [vendor]);

  const handleOpenCreateProduct = () => {
    setEditingProductId(null);
    setProductForm({
      title: "",
      description: "",
      shortDescription: "",
      price: "",
      compareAtPrice: "",
      sku: `SKU-${Math.floor(1000 + Math.random() * 9000)}`,
      stockQuantity: "25",
      categoryId: categoriesList[0]?.id || "",
      images: "/images/bhujia-sev.jpg",
      tags: "Wireless, Premium",
      isFeatured: false,
    });
    setIsProductModalOpen(true);
  };

  const handleOpenEditProduct = (prod: any) => {
    setEditingProductId(prod.id);
    setProductForm({
      title: prod.title,
      description: prod.description,
      shortDescription: prod.shortDescription || "",
      price: String(prod.price),
      compareAtPrice: prod.compareAtPrice ? String(prod.compareAtPrice) : "",
      sku: prod.sku || "",
      stockQuantity: String(prod.stockQuantity),
      categoryId: prod.categoryId,
      images: prod.images?.join(", ") || "",
      tags: prod.tags?.join(", ") || "",
      isFeatured: !!prod.isFeatured,
    });
    setIsProductModalOpen(true);
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    const imagesArray = productForm.images
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);

    const tagsArray = productForm.tags
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);

    const payload = {
      title: productForm.title,
      description: productForm.description,
      shortDescription: productForm.shortDescription,
      price: parseFloat(productForm.price),
      compareAtPrice: productForm.compareAtPrice ? parseFloat(productForm.compareAtPrice) : null,
      sku: productForm.sku,
      stockQuantity: parseInt(productForm.stockQuantity, 10),
      categoryId: productForm.categoryId || categoriesList[0]?.id,
      images: imagesArray.length > 0 ? imagesArray : ["https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80"],
      tags: tagsArray,
      isFeatured: productForm.isFeatured,
      vendorId: vendor?.id,
    };

    try {
      if (editingProductId) {
        // PUT update
        const res = await fetch(`/api/products/${editingProductId}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        if (res.ok) {
          setIsProductModalOpen(false);
          fetchData();
        }
      } else {
        // POST create
        const res = await fetch("/api/products", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        if (res.ok) {
          setIsProductModalOpen(false);
          fetchData();
        }
      }
    } catch (e) {
      console.error("Save product error", e);
    }
  };

  const handleDeleteProduct = async (id: string) => {
    if (!confirm("Are you sure you want to delete this product?")) return;
    try {
      const res = await fetch(`/api/products/${id}`, { method: "DELETE" });
      if (res.ok) {
        setProductsList((prev) => prev.filter((p) => p.id !== id));
      }
    } catch (e) {
      console.error("Delete product error", e);
    }
  };

  const handleFulfillItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fulfillingItem) return;

    try {
      const res = await fetch(`/api/orders/${fulfillingItem.orderId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          itemId: fulfillingItem.id,
          itemStatus: "shipped",
          carrierName,
          trackingNumber,
        }),
      });

      if (res.ok) {
        setFulfillingItem(null);
        fetchData();
      }
    } catch (e) {
      console.error("Fulfill item error", e);
    }
  };

  const handleRequestPayout = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/seller/payouts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount: payoutAmount }),
      });

      if (res.ok) {
        const data = await res.json();
        setPayoutsList((prev) => [data.payout, ...prev]);
        setIsPayoutModalOpen(false);
      }
    } catch (e) {
      console.error("Payout error", e);
    }
  };

  const handleSaveStoreSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!vendor) return;

    try {
      const res = await fetch(`/api/vendors/${vendor.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(storeForm),
      });

      if (res.ok) {
        alert("Store settings saved successfully!");
        refreshSession();
      }
    } catch (e) {
      console.error("Save store error", e);
    }
  };

  const metrics = analytics?.metrics || {
    grossRevenue: 48920.50,
    netEarnings: 44028.45,
    platformCommission: 4892.05,
    commissionRate: vendor?.commissionRate || 10.0,
    totalOrders: 142,
    activeProductsCount: productsList.length,
    lowStockCount: 2,
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in duration-200">
      {/* 1. Header Banner */}
      <div className="bg-gradient-to-r from-red-950 via-red-800 to-orange-900 rounded-3xl p-6 sm:p-8 text-white flex flex-col md:flex-row items-start md:items-center justify-between gap-6 shadow-xl border border-orange-700">
        <div className="flex items-center gap-4">
          <img
            src={vendor?.logoUrl || "https://images.unsplash.com/photo-1550009158-9ebf69173e03?auto=format&fit=crop&w=200&q=80"}
            alt={vendor?.storeName || "Store"}
            className="w-16 h-16 rounded-2xl object-cover border-2 border-white/80 shadow-md bg-white/10"
          />
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span
                className={`text-xs font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full border flex items-center gap-1 ${
                  user?.role === "admin"
                    ? "bg-emerald-500/20 text-emerald-300 border-emerald-400/30"
                    : "bg-amber-400/20 text-amber-200 border-amber-400/40"
                }`}
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>{user?.role === "admin" ? "Owner Account · Full Access" : "Staff Account · Limited Access"}</span>
              </span>
              {user?.role === "admin" && (
                <span className="text-orange-200 text-xs">Settlement Fee: {metrics.commissionRate}%</span>
              )}
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
              {vendor?.storeName || "RAJRANI NAMKEEN CENTRE"}
            </h1>
            <p className="text-xs sm:text-sm text-orange-200 mt-0.5 max-w-xl line-clamp-1">
              {vendor?.description || "Manage fresh stock, dispatch orders and monitor store sales."}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-stretch md:self-auto">
          {vendor?.slug && (
            <button
              onClick={() => onOpenStorefront && onOpenStorefront(vendor.slug)}
              className="flex-1 md:flex-none px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white text-xs font-bold rounded-xl border border-white/20 flex items-center justify-center gap-1.5 transition-all"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>View Storefront</span>
            </button>
          )}
          <button
            onClick={handleOpenCreateProduct}
            className="flex-1 md:flex-none px-4 py-2.5 bg-white hover:bg-gray-100 text-orange-900 text-xs font-extrabold rounded-xl shadow-md flex items-center justify-center gap-1.5 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Add Product</span>
          </button>
        </div>
      </div>

      {/* 2. Seller KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Gross Store Revenue */}
        <div className="bg-white p-5 rounded-2xl border border-gray-200/80 shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-gray-500">
            <span className="text-xs font-bold uppercase tracking-wider">Gross Sales</span>
            <div className="w-8 h-8 rounded-lg bg-orange-50 text-orange-600 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-gray-900">
            â¹{metrics.grossRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <p className="text-[11px] text-emerald-600 font-medium flex items-center gap-1">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>+18.4% this quarter</span>
          </p>
        </div>

        {/* Net Settlement Earnings */}
        <div className="bg-white p-5 rounded-2xl border border-gray-200/80 shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-gray-500">
            <span className="text-xs font-bold uppercase tracking-wider">Net Store Earnings</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <Percent className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-emerald-600">
            â¹{metrics.netEarnings.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <p className="text-[11px] text-gray-500">
            After {metrics.commissionRate}% settlement gateway charges
          </p>
        </div>

        {/* Orders Processed */}
        <div className="bg-white p-5 rounded-2xl border border-gray-200/80 shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-gray-500">
            <span className="text-xs font-bold uppercase tracking-wider">Orders Handled</span>
            <div className="w-8 h-8 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center">
              <Truck className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-gray-900">
            {metrics.totalOrders}
          </div>
          <p className="text-[11px] text-purple-600 font-medium">
            Avg Order: ${(metrics.grossRevenue / Math.max(1, metrics.totalOrders)).toFixed(2)}
          </p>
        </div>

        {/* Low Stock Alerts */}
        <div className="bg-white p-5 rounded-2xl border border-gray-200/80 shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-gray-500">
            <span className="text-xs font-bold uppercase tracking-wider">Inventory Health</span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-amber-600">
            {metrics.lowStockCount} items
          </div>
          <p className="text-[11px] text-gray-500">
            {productsList.length} total active products in catalog
          </p>
        </div>
      </div>

      {/* 3. Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-gray-200 pb-2 overflow-x-auto">
        {[
          { id: "overview", label: "Sales Overview", icon: TrendingUp },
          { id: "products", label: `Product Catalog (${productsList.length})`, icon: ShoppingBag },
          { id: "orders", label: `Fulfillments (${ordersList.length})`, icon: Truck },
          ...(user?.role === "admin"
            ? [
                { id: "payouts", label: `Bank Settlements (${payoutsList.length})`, icon: DollarSign },
                { id: "settings", label: "Store Profile & Bank", icon: Building2 },
              ]
            : []),
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center gap-2 ${
              activeTab === tab.id
                ? "bg-orange-600 text-white shadow-md shadow-orange-600/20"
                : "text-gray-600 hover:bg-gray-100"
            }`}
          >
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* TAB 1: Sales Overview */}
      {activeTab === "overview" && (
        <div className="space-y-6">
          {/* Revenue Chart Visual */}
          <div className="bg-white p-6 rounded-3xl border border-gray-200 shadow-2xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-extrabold text-gray-900">Store Sales Performance</h3>
                <p className="text-xs text-gray-500">Monthly gross vs net earnings after gateway charges</p>
              </div>
              <div className="flex items-center gap-4 text-xs">
                <div className="flex items-center gap-1.5">
                  <div className="w-3 h-3 bg-orange-600 rounded-sm" />
                  <span className="text-gray-600 font-medium">Gross Revenue</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-3 h-3 bg-emerald-500 rounded-sm" />
                  <span className="text-gray-600 font-medium">Net Payouts</span>
                </div>
              </div>
            </div>

            {/* Visual Bars */}
            <div className="pt-6 pb-2">
              <div className="grid grid-cols-6 gap-3 sm:gap-6 items-end h-52">
                {(analytics?.monthlySales || [
                  { month: "Jan", gross: 4200, net: 3780 },
                  { month: "Feb", gross: 5800, net: 5220 },
                  { month: "Mar", gross: 7100, net: 6390 },
                  { month: "Apr", gross: 8900, net: 8010 },
                  { month: "May", gross: 11400, net: 10260 },
                  { month: "Jun", gross: 12800, net: 11520 },
                ]).map((item: any, idx: number) => {
                  const maxVal = 15000;
                  const grossHeight = Math.min(100, Math.round((item.gross / maxVal) * 100));
                  const netHeight = Math.min(100, Math.round((item.net / maxVal) * 100));

                  return (
                    <div key={idx} className="flex flex-col items-center gap-2 h-full justify-end group">
                      <div className="text-[10px] font-mono text-gray-400 group-hover:text-orange-600 font-bold opacity-0 group-hover:opacity-100 transition-opacity">
                        â¹{(item.gross / 1000).toFixed(1)}k
                      </div>
                      <div className="w-full max-w-[48px] flex items-end gap-1.5 h-40 bg-gray-50 p-1 rounded-xl">
                        <div
                          className="flex-1 bg-orange-600 hover:bg-orange-500 rounded-lg transition-all"
                          style={{ height: `${grossHeight}%` }}
                          title={`Gross: â¹{item.gross}`}
                        />
                        <div
                          className="w-2.5 bg-emerald-500 hover:bg-emerald-400 rounded-lg transition-all"
                          style={{ height: `${netHeight}%` }}
                          title={`Net: â¹{item.net}`}
                        />
                      </div>
                      <span className="text-xs font-bold text-gray-700">{item.month}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: Product Management (Full CRUD) */}
      {activeTab === "products" && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="relative w-full sm:w-72">
              <input
                type="text"
                placeholder="Search products by title or SKU..."
                value={productSearch}
                onChange={(e) => setProductSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-white border border-gray-200 rounded-xl text-xs focus:outline-hidden focus:border-orange-500"
              />
              <Search className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
            </div>

            <button
              onClick={handleOpenCreateProduct}
              className="w-full sm:w-auto px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 shadow-md shadow-orange-600/20"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Create New Product</span>
            </button>
          </div>

          <div className="bg-white rounded-3xl border border-gray-200 overflow-hidden shadow-2xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-gray-50 text-gray-500 uppercase tracking-wider font-bold border-b border-gray-200 text-[10px]">
                  <tr>
                    <th className="p-4">Product Details</th>
                    <th className="p-4">SKU</th>
                    <th className="p-4">Price</th>
                    <th className="p-4">Inventory</th>
                    <th className="p-4">Sales</th>
                    <th className="p-4">Status</th>
                    <th className="p-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {productsList
                    .filter((p) => p.title.toLowerCase().includes(productSearch.toLowerCase()))
                    .map((prod) => (
                      <tr key={prod.id} className="hover:bg-gray-50/70 transition-colors">
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <img src={prod.images?.[0]} alt={prod.title} className="w-12 h-12 rounded-xl object-cover bg-gray-100 shrink-0" />
                            <div>
                              <div className="font-bold text-gray-900 max-w-sm truncate">{prod.title}</div>
                              <div className="text-[11px] text-gray-500">{prod.category?.name || "General"}</div>
                            </div>
                          </div>
                        </td>
                        <td className="p-4 font-mono font-bold text-gray-600">
                          {prod.sku || "N/A"}
                        </td>
                        <td className="p-4">
                          <span className="font-black text-gray-900">â¹{prod.price.toFixed(2)}</span>
                          {prod.compareAtPrice && (
                            <span className="block text-[10px] text-gray-400 line-through">
                              â¹{prod.compareAtPrice.toFixed(2)}
                            </span>
                          )}
                        </td>
                        <td className="p-4">
                          <span
                            className={`font-bold px-2 py-0.5 rounded-md text-[11px] ${
                              prod.stockQuantity <= 15
                                ? "bg-amber-100 text-amber-800"
                                : "bg-emerald-100 text-emerald-800"
                            }`}
                          >
                            {prod.stockQuantity} in stock
                          </span>
                        </td>
                        <td className="p-4 text-gray-700 font-medium">
                          {prod.salesCount || 0} units
                        </td>
                        <td className="p-4">
                          <span className="bg-emerald-50 text-emerald-700 text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-200">
                            {prod.status}
                          </span>
                        </td>
                        <td className="p-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => handleOpenEditProduct(prod)}
                              className="p-1.5 text-gray-500 hover:text-orange-600 hover:bg-orange-50 rounded-lg transition-colors"
                              title="Edit Product"
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleDeleteProduct(prod.id)}
                              className="p-1.5 text-gray-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                              title="Delete Product"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: Orders & Fulfillment Dispatch */}
      {activeTab === "orders" && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-extrabold text-gray-900">Fulfillment Queue</h3>
            <div className="flex gap-2 text-xs">
              {["all", "processing", "shipped", "delivered"].map((st) => (
                <button
                  key={st}
                  onClick={() => setOrderStatusFilter(st)}
                  className={`px-3 py-1.5 rounded-lg capitalize font-semibold transition-all ${
                    orderStatusFilter === st
                      ? "bg-slate-900 text-white"
                      : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-3xl border border-gray-200 overflow-hidden shadow-2xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-gray-50 text-gray-500 uppercase tracking-wider font-bold border-b border-gray-200 text-[10px]">
                  <tr>
                    <th className="p-4">Item & Order #</th>
                    <th className="p-4">Recipient</th>
                    <th className="p-4">Price & Quantity</th>
                    <th className="p-4">Your Net Earnings</th>
                    <th className="p-4">Fulfillment Status</th>
                    <th className="p-4 text-right">Dispatch Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {ordersList
                    .flatMap((o) => (o.items || []).map((itm: any) => ({ ...itm, order: o })))
                    .filter((i) => (orderStatusFilter === "all" ? true : i.status === orderStatusFilter))
                    .map((item) => (
                      <tr key={item.id} className="hover:bg-gray-50/70 transition-colors">
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <img src={item.productImage} alt={item.productTitle} className="w-10 h-10 rounded-lg object-cover bg-gray-100" />
                            <div>
                              <div className="font-bold text-gray-900 max-w-xs truncate">{item.productTitle}</div>
                              <div className="text-[11px] font-mono font-semibold text-orange-600">
                                {item.order?.orderNumber}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="font-semibold text-gray-900">{item.order?.shippingAddress?.fullName}</div>
                          <div className="text-[11px] text-gray-500">{item.order?.shippingAddress?.city}, {item.order?.shippingAddress?.state}</div>
                        </td>
                        <td className="p-4">
                          <span className="font-bold text-gray-900">â¹{item.totalPrice?.toFixed(2)}</span>
                          <span className="text-[11px] text-gray-400 block">Qty: {item.quantity}</span>
                        </td>
                        <td className="p-4 font-black text-emerald-600">
                          â¹{(item.vendorEarnings || item.totalPrice * 0.9).toFixed(2)}
                        </td>
                        <td className="p-4">
                          <span
                            className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                              item.status === "delivered"
                                ? "bg-emerald-50 text-emerald-700 border border-emerald-200"
                                : item.status === "shipped"
                                ? "bg-blue-50 text-blue-700 border border-blue-200"
                                : "bg-amber-50 text-amber-700 border border-amber-200"
                            }`}
                          >
                            {item.status}
                          </span>
                          {item.trackingNumber && (
                            <div className="text-[10px] text-gray-400 font-mono mt-0.5">
                              {item.carrierName}: {item.trackingNumber}
                            </div>
                          )}
                        </td>
                        <td className="p-4 text-right">
                          {item.status === "processing" ? (
                            <button
                              onClick={() => {
                                setFulfillingItem(item);
                                setTrackingNumber(`TRK-${Math.floor(10000000 + Math.random() * 90000000)}`);
                              }}
                              className="px-3 py-1.5 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl shadow-xs transition-all inline-flex items-center gap-1"
                            >
                              <Truck className="w-3.5 h-3.5" />
                              <span>Fulfill & Add Tracking</span>
                            </button>
                          ) : (
                            <span className="text-gray-400 font-medium">Dispatched</span>
                          )}
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: Settlement Payouts & History */}
      {activeTab === "payouts" && (
        <div className="space-y-6">
          <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-emerald-950 p-6 rounded-3xl text-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-lg border border-emerald-800">
            <div>
              <p className="text-xs uppercase tracking-wider text-emerald-300 font-bold">
                Available Settlement Balance
              </p>
              <div className="text-3xl sm:text-4xl font-black mt-1">
                â¹{metrics.netEarnings.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
              <p className="text-xs text-emerald-200 mt-1">
                Direct ACH transfer to <strong>{vendor?.bankName || "Silicon Valley Bank"} ({vendor?.bankAccountNumber || "•••• 8492"})</strong>
              </p>
            </div>

            <button
              onClick={() => setIsPayoutModalOpen(true)}
              className="px-6 py-3 bg-white hover:bg-gray-100 text-emerald-950 text-xs font-black rounded-2xl shadow-md transition-all flex items-center gap-2 shrink-0 cursor-pointer"
            >
              <DollarSign className="w-4 h-4" />
              <span>Request Payout Transfer</span>
            </button>
          </div>

          <div className="space-y-3">
            <h3 className="text-sm font-extrabold text-gray-900">Payout Settlement Ledger</h3>
            <div className="bg-white rounded-3xl border border-gray-200 overflow-hidden shadow-2xs">
              <table className="w-full text-left text-xs">
                <thead className="bg-gray-50 text-gray-500 uppercase tracking-wider font-bold border-b border-gray-200 text-[10px]">
                  <tr>
                    <th className="p-4">Reference #</th>
                    <th className="p-4">Amount</th>
                    <th className="p-4">Transfer Fee</th>
                    <th className="p-4">Net Received</th>
                    <th className="p-4">Method</th>
                    <th className="p-4">Status</th>
                    <th className="p-4">Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {payoutsList.map((pay) => (
                    <tr key={pay.id} className="hover:bg-gray-50/70 transition-colors">
                      <td className="p-4 font-mono font-bold text-gray-900">
                        {pay.referenceNumber || pay.id}
                      </td>
                      <td className="p-4 font-bold text-gray-900">
                        â¹{pay.amount?.toFixed(2)}
                      </td>
                      <td className="p-4 text-gray-400">
                        â¹{pay.fee?.toFixed(2) || "0.00"}
                      </td>
                      <td className="p-4 font-black text-emerald-600">
                        â¹{pay.netAmount?.toFixed(2)}
                      </td>
                      <td className="p-4 capitalize text-gray-600">
                        {pay.method?.replace("_", " ") || "Bank Transfer"}
                      </td>
                      <td className="p-4">
                        <span className="bg-emerald-50 text-emerald-700 text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-200">
                          {pay.status}
                        </span>
                      </td>
                      <td className="p-4 text-gray-400 text-[11px]">
                        {new Date(pay.createdAt).toLocaleDateString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: Store Profile & Bank Info */}
      {activeTab === "settings" && (
        <form onSubmit={handleSaveStoreSettings} className="bg-white p-6 sm:p-8 rounded-3xl border border-gray-200 shadow-2xs max-w-2xl space-y-6">
          <div>
            <h3 className="text-base font-bold text-gray-900">Storefront Profile & Payout Settings</h3>
            <p className="text-xs text-gray-500">Update your store display name, bio and payout bank details</p>
          </div>

          <div className="space-y-4 text-xs">
            <div>
              <label className="block text-gray-700 font-bold mb-1">Store Name</label>
              <input
                type="text"
                required
                value={storeForm.storeName}
                onChange={(e) => setStoreForm({ ...storeForm, storeName: e.target.value })}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs focus:bg-white focus:border-orange-500"
              />
            </div>

            <div>
              <label className="block text-gray-700 font-bold mb-1">Store Bio & Description</label>
              <textarea
                rows={3}
                value={storeForm.description}
                onChange={(e) => setStoreForm({ ...storeForm, description: e.target.value })}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs focus:bg-white focus:border-orange-500"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-gray-700 font-bold mb-1">Store Logo URL</label>
                <input
                  type="text"
                  value={storeForm.logoUrl}
                  onChange={(e) => setStoreForm({ ...storeForm, logoUrl: e.target.value })}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs focus:bg-white focus:border-orange-500"
                />
              </div>

              <div>
                <label className="block text-gray-700 font-bold mb-1">Store Banner URL</label>
                <input
                  type="text"
                  value={storeForm.bannerUrl}
                  onChange={(e) => setStoreForm({ ...storeForm, bannerUrl: e.target.value })}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs focus:bg-white focus:border-orange-500"
                />
              </div>
            </div>

            <div className="pt-4 border-t border-gray-200 space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-gray-900">
                Banking & Payout Account
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-gray-700 font-bold mb-1">Bank Name</label>
                  <input
                    type="text"
                    value={storeForm.bankName}
                    onChange={(e) => setStoreForm({ ...storeForm, bankName: e.target.value })}
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs focus:bg-white focus:border-orange-500"
                  />
                </div>
                <div>
                  <label className="block text-gray-700 font-bold mb-1">Account Number</label>
                  <input
                    type="text"
                    value={storeForm.bankAccountNumber}
                    onChange={(e) => setStoreForm({ ...storeForm, bankAccountNumber: e.target.value })}
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs focus:bg-white focus:border-orange-500 font-mono"
                  />
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="px-6 py-2.5 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl shadow-md transition-all cursor-pointer"
            >
              Save Store Profile
            </button>
          </div>
        </form>
      )}

      {/* Product Create / Edit Modal */}
      {isProductModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <form
            onSubmit={handleSaveProduct}
            className="bg-white rounded-3xl p-6 sm:p-8 max-w-2xl w-full shadow-2xl border border-gray-100 max-h-[85vh] overflow-y-auto space-y-4 text-xs"
          >
            <div className="flex items-center justify-between pb-2 border-b border-gray-100">
              <h3 className="text-sm font-bold text-gray-900">
                {editingProductId ? "Edit Product" : "Create New Product Listing"}
              </h3>
              <button
                type="button"
                onClick={() => setIsProductModalOpen(false)}
                className="text-gray-400 hover:text-gray-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div>
              <label className="block text-gray-700 font-bold mb-1">Product Title</label>
              <input
                type="text"
                required
                value={productForm.title}
                onChange={(e) => setProductForm({ ...productForm, title: e.target.value })}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-gray-700 font-bold mb-1">Full Description</label>
              <textarea
                rows={3}
                required
                value={productForm.description}
                onChange={(e) => setProductForm({ ...productForm, description: e.target.value })}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-gray-700 font-bold mb-1">Price (â¹)</label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={productForm.price}
                  onChange={(e) => setProductForm({ ...productForm, price: e.target.value })}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2"
                />
              </div>

              <div>
                <label className="block text-gray-700 font-bold mb-1">Original / Compare Price (â¹)</label>
                <input
                  type="number"
                  step="0.01"
                  value={productForm.compareAtPrice}
                  onChange={(e) => setProductForm({ ...productForm, compareAtPrice: e.target.value })}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-gray-700 font-bold mb-1">SKU</label>
                <input
                  type="text"
                  value={productForm.sku}
                  onChange={(e) => setProductForm({ ...productForm, sku: e.target.value })}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 font-mono"
                />
              </div>

              <div>
                <label className="block text-gray-700 font-bold mb-1">Stock Quantity</label>
                <input
                  type="number"
                  required
                  value={productForm.stockQuantity}
                  onChange={(e) => setProductForm({ ...productForm, stockQuantity: e.target.value })}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2"
                />
              </div>

              <div>
                <label className="block text-gray-700 font-bold mb-1">Category</label>
                <select
                  value={productForm.categoryId}
                  onChange={(e) => setProductForm({ ...productForm, categoryId: e.target.value })}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2"
                >
                  {categoriesList.map((cat) => (
                    <option key={cat.id} value={cat.id}>
                      {cat.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-gray-700 font-bold mb-1">Image URLs (comma separated)</label>
              <input
                type="text"
                value={productForm.images}
                onChange={(e) => setProductForm({ ...productForm, images: e.target.value })}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-gray-700 font-bold mb-1">Tags (comma separated)</label>
              <input
                type="text"
                value={productForm.tags}
                onChange={(e) => setProductForm({ ...productForm, tags: e.target.value })}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2"
              />
            </div>

            <div className="flex gap-2 justify-end pt-3 border-t border-gray-100">
              <button
                type="button"
                onClick={() => setIsProductModalOpen(false)}
                className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold rounded-xl"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-6 py-2 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl"
              >
                {editingProductId ? "Save Changes" : "Publish Product"}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Fulfillment Dispatch Modal */}
      {fulfillingItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <form
            onSubmit={handleFulfillItem}
            className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-gray-100 space-y-4 text-xs"
          >
            <div className="flex items-center justify-between pb-2 border-b border-gray-100">
              <h3 className="text-sm font-bold text-gray-900">Dispatch & Attach Tracking</h3>
              <button
                type="button"
                onClick={() => setFulfillingItem(null)}
                className="text-gray-400 hover:text-gray-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-gray-600">
              Fulfill item: <strong>{fulfillingItem.productTitle}</strong>
            </p>

            <div>
              <label className="block text-gray-700 font-bold mb-1">Courier Carrier</label>
              <select
                value={carrierName}
                onChange={(e) => setCarrierName(e.target.value)}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 font-medium"
              >
                <option value="FedEx Express">FedEx Express</option>
                <option value="UPS Ground">UPS Ground</option>
                <option value="DHL Express">DHL Express</option>
                <option value="USPS Priority Mail">USPS Priority Mail</option>
              </select>
            </div>

            <div>
              <label className="block text-gray-700 font-bold mb-1">Tracking Number Code</label>
              <input
                type="text"
                required
                value={trackingNumber}
                onChange={(e) => setTrackingNumber(e.target.value)}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 font-mono font-bold text-orange-600"
              />
            </div>

            <div className="flex gap-2 justify-end pt-2">
              <button
                type="button"
                onClick={() => setFulfillingItem(null)}
                className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold rounded-xl"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl"
              >
                Confirm Dispatch
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Request Payout Modal */}
      {isPayoutModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <form
            onSubmit={handleRequestPayout}
            className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-gray-100 space-y-4 text-xs"
          >
            <div className="flex items-center justify-between pb-2 border-b border-gray-100">
              <h3 className="text-sm font-bold text-gray-900">Request Bank Settlement Payout</h3>
              <button
                type="button"
                onClick={() => setIsPayoutModalOpen(false)}
                className="text-gray-400 hover:text-gray-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div>
              <label className="block text-gray-700 font-bold mb-1">Payout Amount (â¹)</label>
              <input
                type="number"
                step="0.01"
                required
                value={payoutAmount}
                onChange={(e) => setPayoutAmount(e.target.value)}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-sm font-bold text-gray-900"
              />
            </div>

            <div className="bg-gray-50 p-3 rounded-xl border border-gray-200 text-[11px] text-gray-600 space-y-1">
              <div className="flex justify-between">
                <span>Transfer Method:</span>
                <span className="font-semibold text-gray-900">NEFT Bank Transfer</span>
              </div>
              <div className="flex justify-between">
                <span>Fixed Processing Fee:</span>
                <span className="font-semibold text-gray-900">1.5% gateway charge</span>
              </div>
              <div className="flex justify-between">
                <span>Destination Bank:</span>
                <span className="font-semibold text-gray-900">{vendor?.bankName || "Silicon Valley Bank"}</span>
              </div>
            </div>

            <div className="flex gap-2 justify-end pt-2">
              <button
                type="button"
                onClick={() => setIsPayoutModalOpen(false)}
                className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold rounded-xl"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-6 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl"
              >
                Confirm Transfer
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}

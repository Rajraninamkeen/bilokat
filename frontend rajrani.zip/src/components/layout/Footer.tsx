"use client";

import React, { useState } from "react";
import {
  Wheat,
  ShieldCheck,
  Truck,
  RotateCcw,
  Flame,
  MapPin,
  Phone,
  ArrowRight,
  BadgeCheck,
  Check,
} from "lucide-react";

interface FooterProps {
  onSellerPortalClick: () => void;
  onAdminStudioClick: () => void;
  onCategoryClick: (slug: string) => void;
}

export function Footer({ onSellerPortalClick, onAdminStudioClick, onCategoryClick }: FooterProps) {
  const [subscribed, setSubscribed] = useState(false);
  const [email, setEmail] = useState("");

  return (
    <footer className="bg-gradient-to-b from-red-950 to-stone-950 text-orange-100 border-t border-orange-900/60 mt-20">
      {/* 1. Trust pillars */}
      <div className="border-b border-orange-900/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-2xl bg-orange-500/10 border border-orange-400/20 flex items-center justify-center text-orange-300 shrink-0">
                <Flame className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-white font-semibold text-sm">Fresh Daily Batches</h4>
                <p className="text-xs text-orange-200/60 mt-1">
                  Every pack is fried the same morning in pure groundnut oil — small-batch, never stored.
                </p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-400/20 flex items-center justify-center text-emerald-300 shrink-0">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-white font-semibold text-sm">FSSAI Certified Kitchen</h4>
                <p className="text-xs text-orange-200/60 mt-1">
                  Lic. No. 12214034001234. No palm oil. No auntificial colours or preservatives.
                </p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-2xl bg-yellow-500/10 border border-yellow-400/20 flex items-center justify-center text-yellow-300 shrink-0">
                <Truck className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-white font-semibold text-sm">Pan-India Delivery</h4>
                <p className="text-xs text-orange-200/60 mt-1">
                  Delhivery, Blue Dart & DTDC partners. Free delivery on orders above ₹499.
                </p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-2xl bg-rose-500/10 border border-rose-400/20 flex items-center justify-center text-rose-300 shrink-0">
                <RotateCcw className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-white font-semibold text-sm">Taste Guarantee</h4>
                <p className="text-xs text-orange-200/60 mt-1">
                  Damaged or stale packet? Instant replacement or full refund — no questions asked.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Main columns */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          {/* Brand */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-orange-500 to-red-600 flex items-center justify-center text-white shadow-md">
                <Wheat className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xl font-black text-white tracking-tight">BILOKAT</span>
                <span className="block text-[9.5px] font-bold text-orange-300/80 tracking-widest uppercase">
                  Rajrani Namkeen Centre
                </span>
              </div>
            </div>
            <p className="text-xs text-orange-200/60 leading-relaxed max-w-sm">
              A Bikaner institution since 1985. Three generations of the Gupta family have hand-made bhujia, sev and mixtures using stone-ground besan, desi ghee and hand-picked spices — with the same taste your tastebuds remember.
            </p>
            <div className="space-y-1.5 text-xs text-orange-200/70">
              <p className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                <span>Shop 12, Main Bhujia Bazaar, Bikaner, Rajasthan 334001</span>
              </p>
              <p className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                <span>+91 98290 12345 · WhatsApp orders welcome</span>
              </p>
            </div>

            <div className="pt-2">
              <h5 className="text-xs font-semibold text-white uppercase tracking-wider mb-2">
                Fresh Batch Alerts & Offers
              </h5>
              {subscribed ? (
                <div className="flex items-center gap-2 text-emerald-300 text-xs py-2 bg-emerald-950/40 border border-emerald-800/40 rounded-xl px-3 max-w-sm">
                  <Check className="w-4 h-4 shrink-0" />
                  <span>Done! You&apos;ll get fresh batch & offer alerts.</span>
                </div>
              ) : (
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (email) {
                      setSubscribed(true);
                      setEmail("");
                    }
                  }}
                  className="flex gap-2 max-w-sm"
                >
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email"
                    className="flex-1 bg-orange-950/60 border border-orange-900/60 rounded-xl px-3 py-2 text-xs text-white placeholder-orange-300/40 focus:outline-hidden focus:border-orange-400"
                  />
                  <button
                    type="submit"
                    className="bg-orange-500 hover:bg-orange-400 text-white text-xs font-semibold px-4 py-2 rounded-xl transition-colors shrink-0 flex items-center gap-1"
                  >
                    <span>Subscribe</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </form>
              )}
            </div>
          </div>

          {/* Shop */}
          <div>
            <h5 className="text-xs font-bold text-white uppercase tracking-wider mb-4">Shop Namkeen</h5>
            <ul className="space-y-2.5 text-xs text-orange-200/70">
              {[
                ["Bhujia & Sev", "bhujia-sev"],
                ["Mixtures", "mixtures"],
                ["Mathri & Papadi", "mathri-papadi"],
                ["Dals & Peanuts", "dals-peanuts"],
                ["Fresh Snacks (Bikaner)", "fresh-snacks"],
                ["Healthy & Diet", "healthy-diet"],
                ["Festive Combos & Gifts", "festive-combos"],
              ].map(([label, slug]) => (
                <li key={slug}>
                  <button onClick={() => onCategoryClick(slug)} className="hover:text-white transition-colors">
                    {label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* For Store Owner */}
          <div>
            <h5 className="text-xs font-bold text-white uppercase tracking-wider mb-4">Store Management</h5>
            <ul className="space-y-2.5 text-xs text-orange-200/70">
              <li>
                <button
                  onClick={onSellerPortalClick}
                  className="text-orange-300 hover:text-orange-200 font-medium flex items-center gap-1 transition-colors"
                >
                  <span>Store Panel (Products & Orders)</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </li>
              <li>
                <button onClick={onAdminStudioClick} className="hover:text-white transition-colors">
                  Owner Analytics & Coupons
                </button>
              </li>
              <li>
                <button onClick={onSellerPortalClick} className="hover:text-white transition-colors">
                  Bank Settlements (Payouts)
                </button>
              </li>
              <li>
                <button onClick={onSellerPortalClick} className="hover:text-white transition-colors">
                  Store Profile & Bank Details
                </button>
              </li>
              <li className="pt-2 text-[11px] text-orange-300/50">
                Bulk / wedding / corporate orders: call +91 98290 12345
              </li>
            </ul>
          </div>

          {/* Offers & Info */}
          <div>
            <h5 className="text-xs font-bold text-white uppercase tracking-wider mb-4">Offers & Info</h5>
            <ul className="space-y-2.5 text-xs text-orange-200/70">
              <li>
                <span className="text-white font-semibold">Active Coupons:</span>
                <div className="flex flex-wrap gap-1.5 mt-1.5">
                  {["WELCOME50", "BILOKAT10", "DIWALI15", "BULK20"].map((c) => (
                    <span
                      key={c}
                      className="bg-orange-950/80 text-yellow-300 font-mono text-[10px] px-2 py-0.5 rounded-md border border-orange-800/60"
                    >
                      {c}
                    </span>
                  ))}
                </div>
              </li>
              <li className="flex items-center gap-2 pt-2">
                <BadgeCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>GST inclusive pricing · GSTIN 08AABCR3456F1Z5</span>
              </li>
              <li className="text-[11px] text-orange-300/50">
                UPI, cards, net-banking & COD accepted. Fresh counter items deliver within Bikaner only.
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* 3. Bottom */}
      <div className="bg-black/40 border-t border-orange-900/40 py-6 text-xs text-orange-300/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p>© {new Date().getFullYear()} RAJRANI NAMKEEN CENTRE · BILOKAT is a registered brand · Bikaner, Rajasthan</p>
          <div className="flex items-center gap-3">
            <span>FSSAI Certified</span>
            <span>•</span>
            <span>Secure UPI Payments</span>
            <span>•</span>
            <span>Made with love in Bikaner</span>
          </div>
        </div>
      </div>
    </footer>
  );
}

"use client";

import React, { useState, useEffect, useRef } from "react";
import { useAuth } from "@/context/AuthContext";
import { useCart } from "@/context/CartContext";
import { useWishlist } from "@/context/WishlistContext";
import {
  ShoppingBag,
  Heart,
  Search,
  ChevronDown,
  Store,
  LayoutDashboard,
  Truck,
  CheckCircle2,
  X,
  Layers,
  Wheat,
  Sparkles,
  Cookie,
  Nut,
  Croissant,
  Salad,
  Gift,
  ArrowRight,
  Package,
  ShieldCheck,
} from "lucide-react";

interface NavbarProps {
  currentView: "marketplace" | "seller" | "admin" | "wishlist" | "orders" | "storefront";
  setCurrentView: (view: "marketplace" | "seller" | "admin" | "wishlist" | "orders" | "storefront") => void;
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  onOpenStorefront?: (vendorSlug: string) => void;
}

export function Navbar({
  currentView,
  setCurrentView,
  selectedCategory,
  setSelectedCategory,
  searchQuery,
  setSearchQuery,
}: NavbarProps) {
  const { user, demoPersonas, switchUser, openAuthModal } = useAuth();
  const { itemCount, toggleCart, freeShippingThreshold } = useCart();
  const { wishlistCount } = useWishlist();

  const [isPersonaMenuOpen, setIsPersonaMenuOpen] = useState(false);
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const searchRef = useRef<HTMLDivElement>(null);
  const personaRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) setIsSearchFocused(false);
      if (personaRef.current && !personaRef.current.contains(event.target as Node)) setIsPersonaMenuOpen(false);
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    if (searchQuery.trim().length > 1) {
      const timer = setTimeout(async () => {
        try {
          const res = await fetch(`/api/products?q=${encodeURIComponent(searchQuery)}&limit=5`);
          if (res.ok) {
            const data = await res.json();
            setSearchResults(data.products || []);
          }
        } catch (e) {
          console.error("Search error", e);
        }
      }, 200);
      return () => clearTimeout(timer);
    }
    setSearchResults([]);
  }, [searchQuery]);

  const categoriesList = [
    { name: "All Namkeen", slug: "all", icon: Layers },
    { name: "Bhujia & Sev", slug: "bhujia-sev", icon: Wheat },
    { name: "Mixtures", slug: "mixtures", icon: Sparkles },
    { name: "Mathri & Papadi", slug: "mathri-papadi", icon: Cookie },
    { name: "Dals & Peanuts", slug: "dals-peanuts", icon: Nut },
    { name: "Fresh Snacks", slug: "fresh-snacks", icon: Croissant },
    { name: "Healthy & Diet", slug: "healthy-diet", icon: Salad },
    { name: "Combos & Gifts", slug: "festive-combos", icon: Gift },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-orange-200 shadow-xs">
      {/* 1. Top Announcement Bar */}
      <div className="bg-gradient-to-r from-red-900 via-red-800 to-orange-900 text-orange-50 text-xs py-1.5 px-4 sm:px-8 font-medium">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-1.5">
          <div className="flex items-center gap-2">
            <span className="bg-yellow-400/20 text-yellow-300 text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full border border-yellow-400/40">
              Since 1985 · Bikaner
            </span>
            <span className="hidden md:inline text-orange-200">|</span>
            <span className="flex items-center gap-1.5">
              <Truck className="w-3.5 h-3.5 text-yellow-300 inline" />
              <span>
                Free delivery on orders above <strong className="text-yellow-300">₹{freeShippingThreshold}</strong> · Pan-India
              </span>
            </span>
          </div>
          <div className="flex items-center gap-3 text-orange-100">
            <span>
              Use <strong className="text-yellow-300 font-mono tracking-wide">BILOKAT10</strong> for 10% off
            </span>
            <span className="hidden sm:inline text-orange-300">•</span>
            <span className="hidden sm:flex items-center gap-1 text-orange-200">
              <ShieldCheck className="w-3.5 h-3.5 text-yellow-300" />
              FSSAI Lic. 12214034001234
            </span>
          </div>
        </div>
      </div>

      {/* 2. Main Nav */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18 gap-4">
          {/* Brand */}
          <button
            onClick={() => {
              setCurrentView("marketplace");
              setSelectedCategory("all");
              setSearchQuery("");
            }}
            className="flex items-center gap-2.5 text-left group focus:outline-hidden shrink-0"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-orange-600 via-orange-500 to-red-600 flex items-center justify-center text-white shadow-md shadow-orange-500/30 group-hover:scale-105 transition-transform">
              <Wheat className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xl font-black tracking-tight text-gray-900 group-hover:text-orange-600 transition-colors">
                BILOKAT
              </span>
              <span className="block text-[9.5px] font-bold text-orange-700/90 tracking-widest uppercase -mt-0.5">
                Rajrani Namkeen Centre
              </span>
            </div>
          </button>

          {/* Live Search */}
          <div className="flex-1 max-w-2xl relative" ref={searchRef}>
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  if (currentView !== "marketplace") setCurrentView("marketplace");
                }}
                onFocus={() => setIsSearchFocused(true)}
                placeholder="Search bhujia, sev, kaiju mixture, mathri, samosa, hampers..."
                className="w-full pl-11 pr-10 py-2.5 bg-orange-50/70 hover:bg-orange-50 focus:bg-white border border-orange-100 focus:border-orange-400 focus:ring-3 focus:ring-orange-100 rounded-full text-sm text-gray-900 placeholder-orange-900/40 transition-all outline-hidden"
              />
              <Search className="w-4 h-4 text-orange-400 absolute left-4 top-3.5 pointer-events-none" />
              {searchQuery && (
                <button onClick={() => setSearchQuery("")} className="absolute right-3.5 top-3 text-gray-400 hover:text-gray-600">
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {isSearchFocused && searchResults.length > 0 && (
              <div className="absolute left-0 right-0 top-full mt-2 bg-white rounded-2xl shadow-2xl border border-orange-100 overflow-hidden z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                <div className="p-2 border-b border-orange-50 bg-orange-50/60 flex items-center justify-between text-xs text-orange-900/70 px-3">
                  <span className="font-medium">Products matching &quot;{searchQuery}&quot;</span>
                  <span>{searchResults.length} found</span>
                </div>
                <div className="divide-y divide-orange-50 max-h-80 overflow-y-auto">
                  {searchResults.map((product) => (
                    <div
                      key={product.id}
                      onClick={() => {
                        setSearchQuery(product.title.replace("BILOKAT ", ""));
                        setIsSearchFocused(false);
                      }}
                      className="p-3 hover:bg-orange-50/70 flex items-center gap-3 cursor-pointer transition-colors"
                    >
                      <img src={product.images?.[0]} alt={product.title} className="w-10 h-10 rounded-lg object-cover bg-orange-50 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium text-gray-900 truncate">{product.title}</div>
                        <div className="text-xs text-gray-500 flex items-center gap-2">
                          <span className="text-orange-700 font-bold">₹{product.price}</span>
                          <span>•</span>
                          <span className="truncate">{product.category?.name}</span>
                        </div>
                      </div>
                      <ArrowRight className="w-4 h-4 text-gray-400 shrink-0" />
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right actions */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* View Tabs — visible only to owner & authorised staff */}
            <div className="hidden lg:flex items-center bg-orange-100/70 p-1 rounded-xl text-xs font-semibold">
              <button
                onClick={() => setCurrentView("marketplace")}
                className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
                  ["marketplace", "storefront", "wishlist", "orders"].includes(currentView)
                    ? "bg-white text-orange-700 shadow-xs"
                    : "text-orange-900/60 hover:text-orange-900"
                }`}
              >
                <Store className="w-3.5 h-3.5" />
                <span>Shop</span>
              </button>
              {(user?.role === "admin" || user?.role === "seller") && (
                <button
                  onClick={() => setCurrentView("seller")}
                  className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
                    currentView === "seller"
                      ? "bg-orange-600 text-white shadow-xs"
                      : "text-orange-900/60 hover:text-orange-900"
                  }`}
                >
                  <LayoutDashboard className="w-3.5 h-3.5" />
                  <span>Store Panel</span>
                </button>
              )}
              {user?.role === "admin" && (
                <button
                  onClick={() => setCurrentView("admin")}
                  className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
                    currentView === "admin"
                      ? "bg-red-900 text-white shadow-xs"
                      : "text-orange-900/60 hover:text-orange-900"
                  }`}
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Owner Panel</span>
                </button>
              )}
            </div>

            {/* Account Switcher */}
            <div className="relative" ref={personaRef}>
              <button
                onClick={() => setIsPersonaMenuOpen((prev) => !prev)}
                className="flex items-center gap-2 pl-1.5 pr-2.5 py-1.5 bg-orange-50 hover:bg-orange-100 border border-orange-200 rounded-full text-xs font-medium text-gray-700 transition-all"
              >
                <img
                  src={user?.avatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80"}
                  alt={user?.name || "Account"}
                  className="w-6 h-6 rounded-full object-cover border border-white shadow-xs"
                />
                <span className="hidden md:inline max-w-[90px] truncate font-semibold">{user?.name?.split(" ")[0]}</span>
                <span
                  className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md uppercase tracking-wider ${
                    user?.role === "admin"
                      ? "bg-red-100 text-red-700"
                      : user?.role === "seller"
                      ? "bg-amber-100 text-amber-800"
                      : "bg-orange-100 text-orange-700"
                  }`}
                >
                  {user?.role === "admin" ? "Owner" : user?.role === "seller" ? "Staff" : "Customer"}
                </span>
                <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
              </button>

              {isPersonaMenuOpen && (
                <div className="absolute right-0 top-full mt-2 w-72 bg-white rounded-2xl shadow-2xl border border-orange-100 p-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                  <div className="px-3 py-2 border-b border-orange-50">
                    <p className="text-[11px] font-bold uppercase tracking-wider text-orange-900/60">Switch Account</p>
                    <p className="text-xs text-gray-500">Sign in as owner or a customer</p>
                  </div>
                  <div className="py-1 space-y-1 max-h-72 overflow-y-auto">
                    {demoPersonas.map((persona) => {
                      const isActive = user?.id === persona.id;
                      return (
                        <button
                          key={persona.id}
                          onClick={() => {
                            switchUser(persona.id);
                            setIsPersonaMenuOpen(false);
                            setCurrentView(
                              persona.role === "admin" ? "admin" : persona.role === "seller" ? "seller" : "marketplace"
                            );
                          }}
                          className={`w-full flex items-center gap-3 p-2 rounded-xl text-left transition-all ${
                            isActive ? "bg-orange-50 border border-orange-200" : "hover:bg-orange-50/60 border border-transparent"
                          }`}
                        >
                          <img
                            src={persona.avatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80"}
                            alt={persona.name}
                            className="w-8 h-8 rounded-full object-cover shrink-0"
                          />
                          <div className="flex-1 min-w-0">
                            <div className="text-xs font-semibold text-gray-900 truncate flex items-center gap-1.5">
                              <span>{persona.name}</span>
                              {isActive && <CheckCircle2 className="w-3.5 h-3.5 text-orange-600 shrink-0" />}
                            </div>
                            <div className="text-[11px] text-gray-500 truncate">
                              {persona.role === "admin"
                                ? "Owner · Full Access"
                                : persona.role === "seller"
                                ? "Staff · Store Panel Access"
                                : persona.email}
                            </div>
                          </div>
                          <span
                            className={`text-[9px] font-bold px-1.5 py-0.5 rounded-sm uppercase tracking-wider shrink-0 ${
                              persona.role === "admin"
                                ? "bg-red-100 text-red-700"
                                : persona.role === "seller"
                                ? "bg-amber-100 text-amber-800"
                                : "bg-orange-100 text-orange-700"
                            }`}
                          >
                            {persona.role === "admin" ? "Owner" : persona.role === "seller" ? "Staff" : "Customer"}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                  <div className="pt-2 mt-1 border-t border-orange-50 flex flex-col gap-1 text-xs">
                    <button
                      onClick={() => {
                        setCurrentView("orders");
                        setIsPersonaMenuOpen(false);
                      }}
                      className="w-full text-left px-3 py-1.5 text-gray-700 hover:bg-orange-50 rounded-lg font-medium flex items-center gap-2"
                    >
                      <Package className="w-3.5 h-3.5 text-orange-600" />
                      <span>My Orders & Track Delivery</span>
                    </button>
                    <button
                      onClick={() => {
                        openAuthModal("register");
                        setIsPersonaMenuOpen(false);
                      }}
                      className="w-full text-left px-3 py-1.5 text-orange-700 hover:bg-orange-50 rounded-lg font-medium"
                    >
                      + Create New Account
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Wishlist */}
            <button
              onClick={() => setCurrentView("wishlist")}
              className={`p-2.5 rounded-full relative transition-colors ${
                currentView === "wishlist" ? "bg-rose-50 text-rose-600" : "text-gray-600 hover:bg-orange-50 hover:text-orange-700"
              }`}
              title="My Wishlist"
            >
              <Heart className={`w-5 h-5 ${wishlistCount > 0 ? "fill-rose-500 text-rose-500" : ""}`} />
              {wishlistCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-rose-500 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                  {wishlistCount}
                </span>
              )}
            </button>

            {/* Cart */}
            <button
              onClick={toggleCart}
              className="flex items-center gap-2 px-3.5 py-2 bg-orange-600 hover:bg-orange-700 active:scale-95 text-white font-medium text-xs rounded-full shadow-md shadow-orange-600/30 transition-all"
            >
              <ShoppingBag className="w-4 h-4" />
              <span className="hidden sm:inline font-semibold">Cart</span>
              <span className="bg-orange-500 text-white px-1.5 py-0.5 rounded-full font-bold text-[11px]">{itemCount}</span>
            </button>
          </div>
        </div>

        {/* 3. Category ribbon */}
        <div className="flex items-center gap-2 py-2 overflow-x-auto no-scrollbar border-t border-orange-100 text-xs">
          {categoriesList.map((cat) => {
            const Icon = cat.icon;
            const isSelected = selectedCategory === cat.slug;
            return (
              <button
                key={cat.slug}
                onClick={() => {
                  setSelectedCategory(cat.slug);
                  if (currentView !== "marketplace") setCurrentView("marketplace");
                }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full whitespace-nowrap transition-all font-medium ${
                  isSelected ? "bg-red-900 text-white shadow-xs" : "text-orange-900/70 hover:text-orange-900 hover:bg-orange-100"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{cat.name}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
}

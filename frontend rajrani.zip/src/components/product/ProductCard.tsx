"use client";

import React, { useState } from "react";
import { useCart } from "@/context/CartContext";
import { useWishlist } from "@/context/WishlistContext";
import {
  Star,
  Heart,
  ShoppingBag,
  Store,
  Check,
  Eye,
  Sparkles,
} from "lucide-react";

interface ProductCardProps {
  product: {
    id: string;
    title: string;
    slug: string;
    price: number;
    compareAtPrice?: number | null;
    shortDescription?: string | null;
    images?: string[];
    rating?: number;
    reviewCount?: number;
    stockQuantity?: number;
    isFeatured?: boolean;
    category?: { name: string; slug: string };
    vendor?: { id: string; storeName: string; slug: string; rating?: number };
    vendorId: string;
  };
  onSelectProduct: (product: any) => void;
  onSelectVendor?: (vendorSlug: string) => void;
}

export function ProductCard({ product, onSelectProduct, onSelectVendor }: ProductCardProps) {
  const { addItem } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();
  const [isAdding, setIsAdding] = useState(false);

  const discountPercent =
    product.compareAtPrice && product.compareAtPrice > product.price
      ? Math.round(((product.compareAtPrice - product.price) / product.compareAtPrice) * 100)
      : null;

  const inWishlist = isInWishlist(product.id);
  const image = product.images?.[0] || "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80";

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsAdding(true);
    addItem(
      {
        id: product.id,
        vendorId: product.vendorId,
        vendorName: product.vendor?.storeName,
        title: product.title,
        price: product.price,
        images: product.images,
        stockQuantity: product.stockQuantity,
      },
      1
    );
    setTimeout(() => setIsAdding(false), 800);
  };

  const handleWishlistClick = async (e: React.MouseEvent) => {
    e.stopPropagation();
    await toggleWishlist(product.id);
  };

  const handleVendorClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onSelectVendor && product.vendor?.slug) {
      onSelectVendor(product.vendor.slug);
    }
  };

  return (
    <div
      onClick={() => onSelectProduct(product)}
      className="group bg-white rounded-2xl border border-gray-200/80 hover:border-orange-300 shadow-2xs hover:shadow-xl transition-all duration-300 flex flex-col overflow-hidden cursor-pointer relative"
    >
      {/* Product Image Box */}
      <div className="relative aspect-square w-full bg-gray-50 overflow-hidden">
        <img
          src={image}
          alt={product.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
        />

        {/* Top Badges (Discount, Featured) */}
        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1.5 z-10">
          {discountPercent && (
            <span className="bg-rose-600 text-white text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-md shadow-sm">
              -{discountPercent}%
            </span>
          )}
          {product.isFeatured && (
            <span className="bg-orange-600/90 backdrop-blur-xs text-white text-[10px] font-bold px-2 py-0.5 rounded-md flex items-center gap-1 shadow-sm">
              <Sparkles className="w-2.5 h-2.5" />
              <span>Featured</span>
            </span>
          )}
        </div>

        {/* Wishlist Heart Button */}
        <button
          onClick={handleWishlistClick}
          className="absolute top-2.5 right-2.5 w-8 h-8 rounded-full bg-white/90 backdrop-blur-xs flex items-center justify-center text-gray-600 hover:text-rose-500 hover:bg-white shadow-md transition-all z-10"
          title={inWishlist ? "Remove from Wishlist" : "Add to Wishlist"}
        >
          <Heart
            className={`w-4 h-4 transition-transform active:scale-125 ${
              inWishlist ? "fill-rose-500 text-rose-500" : ""
            }`}
          />
        </button>

        {/* Quick View Overlay on hover */}
        <div className="absolute inset-0 bg-slate-900/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
          <span className="bg-white/95 text-gray-900 text-xs font-semibold px-3 py-1.5 rounded-full shadow-lg flex items-center gap-1.5 transform translate-y-2 group-hover:translate-y-0 transition-transform">
            <Eye className="w-3.5 h-3.5 text-orange-600" />
            <span>Quick View</span>
          </span>
        </div>
      </div>

      {/* Product Content */}
      <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
        <div>
          {/* Vendor Badge */}
          {product.vendor && (
            <button
              onClick={handleVendorClick}
              className="text-[11px] font-semibold text-gray-700 hover:text-orange-600 flex items-center gap-1 transition-colors mb-1 truncate max-w-full"
            >
              <Store className="w-3 h-3 text-orange-700 shrink-0" />
              <span className="truncate">{product.vendor.storeName}</span>
            </button>
          )}

          {/* Product Title */}
          <h3 className="text-xs sm:text-sm font-bold text-gray-900 line-clamp-2 leading-snug group-hover:text-orange-600 transition-colors">
            {product.title}
          </h3>

          {/* Rating Stars & Count */}
          <div className="flex items-center gap-1.5 mt-1.5">
            <div className="flex items-center text-amber-400">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              <span className="text-xs font-bold text-gray-800 ml-1">
                {(product.rating || 5.0).toFixed(1)}
              </span>
            </div>
            <span className="text-gray-300">•</span>
            <span className="text-[11px] text-gray-600">
              ({product.reviewCount || 0} reviews)
            </span>
          </div>
        </div>

        {/* Price & Action Row */}
        <div className="pt-2 border-t border-gray-100 flex items-center justify-between">
          <div className="flex flex-col">
            <div className="flex items-baseline gap-1.5">
              <span className="text-base sm:text-lg font-black text-gray-900">
                â¹{product.price.toFixed(2)}
              </span>
              {product.compareAtPrice && product.compareAtPrice > product.price && (
                <span className="text-xs text-gray-600 line-through">
                  â¹{product.compareAtPrice.toFixed(2)}
                </span>
              )}
            </div>
            {product.stockQuantity !== undefined && product.stockQuantity <= 15 ? (
              <span className="text-[10px] font-semibold text-amber-600">
                Only {product.stockQuantity} left
              </span>
            ) : (
              <span className="text-[10px] font-semibold text-emerald-600">
                In Stock
              </span>
            )}
          </div>

          {/* Quick Add Button */}
          <button
            onClick={handleQuickAdd}
            disabled={isAdding}
            className={`p-2.5 rounded-xl font-semibold text-xs flex items-center justify-center transition-all ${
              isAdding
                ? "bg-emerald-600 text-white"
                : "bg-orange-50 text-orange-700 hover:bg-orange-600 hover:text-white"
            }`}
            title="Add to Cart"
          >
            {isAdding ? <Check className="w-4 h-4 animate-in zoom-in" /> : <ShoppingBag className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </div>
  );
}

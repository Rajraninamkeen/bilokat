"use client";

import React, { useState, useEffect } from "react";
import { useCart } from "@/context/CartContext";
import { useWishlist } from "@/context/WishlistContext";
import { useAuth } from "@/context/AuthContext";
import {
  X,
  Star,
  Heart,
  ShoppingBag,
  Store,
  ShieldCheck,
  Truck,
  RotateCcw,
  Check,
  Plus,
  Minus,
  MessageSquare,
  Sparkles,
  ExternalLink,
  ThumbsUp,
  Share2,
} from "lucide-react";

interface ProductDetailModalProps {
  productId: string | null;
  onClose: () => void;
  onSelectVendor?: (vendorSlug: string) => void;
}

export function ProductDetailModal({ productId, onClose, onSelectVendor }: ProductDetailModalProps) {
  const { addItem } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();
  const { user } = useAuth();

  const [productData, setProductData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState<string>("");
  const [selectedVariants, setSelectedVariants] = useState<Record<string, string>>({});
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<"overview" | "specs" | "reviews">("overview");

  // Review form state
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewTitle, setReviewTitle] = useState("");
  const [reviewComment, setReviewComment] = useState("");
  const [isSubmittingReview, setIsSubmittingReview] = useState(false);
  const [reviewSuccess, setReviewSuccess] = useState(false);

  // Vendor reply input state
  const [replyTextMap, setReplyTextMap] = useState<Record<string, string>>({});

  useEffect(() => {
    if (!productId) return;
    setLoading(true);
    setReviewSuccess(false);

    fetch(`/api/products/${productId}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.product) {
          setProductData(data.product);
          setSelectedImage(data.product.images?.[0] || "");

          // Initialize variant selections
          if (data.product.attributes) {
            const initialVars: Record<string, string> = {};
            Object.entries(data.product.attributes).forEach(([key, val]) => {
              if (Array.isArray(val) && val.length > 0) {
                initialVars[key] = val[0];
              }
            });
            setSelectedVariants(initialVars);
          }
        }
      })
      .catch((err) => console.error("Error fetching product", err))
      .finally(() => setLoading(false));
  }, [productId]);

  if (!productId) return null;

  const product = productData;
  const inWishlist = product ? isInWishlist(product.id) : false;

  const handleAddToCart = () => {
    if (!product) return;
    addItem(
      {
        id: product.id,
        vendorId: product.vendorId,
        vendorName: product.vendor?.storeName,
        title: product.title,
        price: product.price,
        images: product.images,
        stockQuantity: product.stockQuantity,
      },
      quantity,
      selectedVariants
    );
  };

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!product || !reviewComment.trim()) return;
    setIsSubmittingReview(true);

    try {
      const res = await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          productId: product.id,
          rating: reviewRating,
          title: reviewTitle,
          comment: reviewComment,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setReviewSuccess(true);
        setReviewComment("");
        setReviewTitle("");
        // Append new review
        setProductData((prev: any) => ({
          ...prev,
          reviews: [data.review, ...(prev.reviews || [])],
          reviewCount: (prev.reviewCount || 0) + 1,
        }));
      }
    } catch (e) {
      console.error("Failed to submit review", e);
    } finally {
      setIsSubmittingReview(false);
    }
  };

  const handleVendorReply = async (reviewId: string) => {
    const text = replyTextMap[reviewId];
    if (!text || !text.trim()) return;

    try {
      const res = await fetch("/api/reviews", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          reviewId,
          vendorReply: text.trim(),
        }),
      });

      if (res.ok) {
        setProductData((prev: any) => ({
          ...prev,
          reviews: prev.reviews.map((r: any) =>
            r.id === reviewId ? { ...r, vendorReply: text.trim(), vendorRepliedAt: new Date() } : r
          ),
        }));
        setReplyTextMap((prev) => ({ ...prev, [reviewId]: "" }));
      }
    } catch (e) {
      console.error("Failed to post vendor reply", e);
    }
  };

  const handleVoteHelpful = async (reviewId: string) => {
    try {
      await fetch("/api/reviews", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reviewId, voteHelpful: true }),
      });
      setProductData((prev: any) => ({
        ...prev,
        reviews: prev.reviews.map((r: any) =>
          r.id === reviewId ? { ...r, helpfulCount: (r.helpfulCount || 0) + 1 } : r
        ),
      }));
    } catch (e) {
      console.error("Failed to vote helpful", e);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto p-3 sm:p-6">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity duration-200"
      />

      {/* Modal Dialog */}
      <div className="relative w-full max-w-4xl bg-white rounded-3xl shadow-2xl overflow-hidden z-10 border border-gray-100 flex flex-col max-h-[90vh]">
        {/* Header Close */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 w-9 h-9 rounded-full bg-white/90 backdrop-blur-xs shadow-md border border-gray-100 flex items-center justify-center text-gray-500 hover:text-gray-900 hover:bg-white transition-all"
        >
          <X className="w-5 h-5" />
        </button>

        {loading || !product ? (
          <div className="p-16 flex flex-col items-center justify-center space-y-4">
            <div className="w-10 h-10 border-4 border-orange-600 border-t-transparent rounded-full animate-spin" />
            <p className="text-xs font-semibold text-gray-500">Loading product details...</p>
          </div>
        ) : (
          <div className="overflow-y-auto flex-1">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 p-6 sm:p-8">
              {/* Left Column: Image Gallery */}
              <div className="space-y-4">
                <div className="aspect-square bg-gray-50 rounded-2xl overflow-hidden border border-gray-100 relative shadow-inner">
                  <img
                    src={selectedImage || product.images?.[0]}
                    alt={product.title}
                    className="w-full h-full object-cover"
                  />
                  {product.compareAtPrice && product.compareAtPrice > product.price && (
                    <span className="absolute top-3 left-3 bg-rose-600 text-white text-xs font-black uppercase tracking-wider px-2.5 py-1 rounded-lg shadow-md">
                      SAVE {Math.round(((product.compareAtPrice - product.price) / product.compareAtPrice) * 100)}%
                    </span>
                  )}
                </div>

                {/* Thumbnails */}
                {product.images && product.images.length > 1 && (
                  <div className="flex gap-2.5 overflow-x-auto pb-1">
                    {product.images.map((img: string, idx: number) => (
                      <button
                        key={idx}
                        onClick={() => setSelectedImage(img)}
                        className={`w-16 h-16 rounded-xl overflow-hidden border-2 transition-all shrink-0 ${
                          selectedImage === img
                            ? "border-orange-600 ring-2 ring-orange-200"
                            : "border-gray-200 hover:border-gray-300 opacity-70 hover:opacity-100"
                        }`}
                      >
                        <img src={img} alt="Thumb" className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>
                )}

                {/* Vendor Information Card */}
                {product.vendor && (
                  <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <img
                        src={product.vendor.logoUrl || "https://images.unsplash.com/photo-1550009158-9ebf69173e03?auto=format&fit=crop&w=200&q=80"}
                        alt={product.vendor.storeName}
                        className="w-11 h-11 rounded-xl object-cover border border-white shadow-xs"
                      />
                      <div>
                        <div className="flex items-center gap-1.5">
                          <h4 className="text-xs font-bold text-gray-900">{product.vendor.storeName}</h4>
                          <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-1.5 py-0.2 rounded-sm flex items-center gap-0.5">
                            <ShieldCheck className="w-3 h-3 text-emerald-600" />
                            <span>Verified</span>
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-[11px] text-gray-500 mt-0.5">
                          <span className="flex items-center text-amber-500 font-semibold">
                            <Star className="w-3 h-3 fill-amber-400 mr-0.5" />
                            {(product.vendor.rating || 4.8).toFixed(1)}
                          </span>
                          <span>•</span>
                          <span>{product.vendor.reviewCount || 40}+ Seller Reviews</span>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        onClose();
                        if (onSelectVendor && product.vendor?.slug) {
                          onSelectVendor(product.vendor.slug);
                        }
                      }}
                      className="px-3 py-1.5 bg-white hover:bg-gray-100 border border-gray-200 rounded-xl text-xs font-semibold text-gray-700 transition-colors flex items-center gap-1 shadow-2xs"
                    >
                      <span>Store</span>
                      <ExternalLink className="w-3 h-3 text-gray-400" />
                    </button>
                  </div>
                )}
              </div>

              {/* Right Column: Product Metadata & Actions */}
              <div className="flex flex-col justify-between space-y-6">
                <div className="space-y-4">
                  <div>
                    <span className="text-xs font-bold text-orange-600 uppercase tracking-wider">
                      {product.category?.name || "Namkeen"}
                    </span>
                    <h2 className="text-xl sm:text-2xl font-black text-gray-900 tracking-tight mt-1 leading-snug">
                      {product.title}
                    </h2>
                    <p className="text-xs text-gray-500 mt-1">SKU: {product.sku || "N/A"}</p>
                  </div>

                  {/* Rating Stars Summary */}
                  <div className="flex items-center gap-2">
                    <div className="flex items-center text-amber-400">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className={`w-4 h-4 ${
                            star <= Math.round(product.rating || 5)
                              ? "fill-amber-400 text-amber-400"
                              : "text-gray-200"
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-xs font-bold text-gray-900">
                      {(product.rating || 5.0).toFixed(1)}
                    </span>
                    <span className="text-xs text-gray-400">•</span>
                    <button
                      onClick={() => setActiveTab("reviews")}
                      className="text-xs text-orange-600 hover:underline font-medium"
                    >
                      {product.reviews?.length || product.reviewCount || 0} Customer Reviews
                    </button>
                  </div>

                  {/* Price */}
                  <div className="flex items-baseline gap-3 pt-2 border-t border-gray-100">
                    <span className="text-2xl sm:text-3xl font-black text-gray-900">
                      â¹{product.price.toFixed(2)}
                    </span>
                    {product.compareAtPrice && product.compareAtPrice > product.price && (
                      <span className="text-base text-gray-600 line-through">
                        â¹{product.compareAtPrice.toFixed(2)}
                      </span>
                    )}
                  </div>

                  {/* Short Description */}
                  <p className="text-xs sm:text-sm text-gray-600 leading-relaxed">
                    {product.shortDescription || product.description}
                  </p>

                  {/* Variant Selection (Colors, Sizes, Options) */}
                  {product.attributes && Object.keys(product.attributes).length > 0 && (
                    <div className="space-y-3 pt-2">
                      {Object.entries(product.attributes).map(([attrKey, attrVal]) => {
                        if (!Array.isArray(attrVal)) return null;
                        return (
                          <div key={attrKey} className="space-y-1.5">
                            <label className="text-xs font-bold text-gray-800 capitalize">
                              Select {attrKey}: <span className="text-orange-600 font-semibold">{selectedVariants[attrKey]}</span>
                            </label>
                            <div className="flex flex-wrap gap-2">
                              {attrVal.map((option: string) => {
                                const isSelected = selectedVariants[attrKey] === option;
                                return (
                                  <button
                                    key={option}
                                    onClick={() => setSelectedVariants({ ...selectedVariants, [attrKey]: option })}
                                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                                      isSelected
                                        ? "bg-orange-600 border-orange-600 text-white shadow-xs"
                                        : "bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100"
                                    }`}
                                  >
                                    {option}
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {/* Stock Alert Status */}
                  <div className="pt-2">
                    {product.stockQuantity > 0 ? (
                      <div className="flex items-center gap-2 text-xs font-semibold text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200/60 max-w-fit">
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span>In Stock ({product.stockQuantity} available) - Ready to dispatch</span>
                      </div>
                    ) : (
                      <div className="text-xs font-semibold text-rose-700 bg-rose-50 px-3 py-1.5 rounded-xl border border-rose-200 max-w-fit">
                        Out of Stock
                      </div>
                    )}
                  </div>
                </div>

                {/* Actions: Quantity + Add to Cart + Wishlist */}
                <div className="space-y-3 pt-4 border-t border-gray-200">
                  <div className="flex items-center gap-3">
                    {/* Quantity Picker */}
                    <div className="flex items-center border border-gray-200 rounded-2xl p-1 bg-gray-50">
                      <button
                        onClick={() => setQuantity(Math.max(1, quantity - 1))}
                        className="w-8 h-8 flex items-center justify-center text-gray-600 hover:bg-white rounded-xl transition-colors"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="w-10 text-center text-xs font-bold text-gray-900">{quantity}</span>
                      <button
                        onClick={() => setQuantity(Math.min(product.stockQuantity || 99, quantity + 1))}
                        className="w-8 h-8 flex items-center justify-center text-gray-600 hover:bg-white rounded-xl transition-colors"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Add to Cart Primary Button */}
                    <button
                      onClick={handleAddToCart}
                      className="flex-1 py-3.5 bg-orange-600 hover:bg-orange-700 active:scale-98 text-white text-xs font-bold rounded-2xl shadow-lg shadow-orange-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
                    >
                      <ShoppingBag className="w-4 h-4" />
                      <span>Add to Cart • ${(product.price * quantity).toFixed(2)}</span>
                    </button>

                    {/* Wishlist Toggle Button */}
                    <button
                      onClick={() => toggleWishlist(product.id)}
                      className={`p-3.5 rounded-2xl border transition-all ${
                        inWishlist
                          ? "bg-rose-50 border-rose-200 text-rose-600"
                          : "bg-gray-50 border-gray-200 text-gray-600 hover:text-rose-600 hover:bg-rose-50"
                      }`}
                      title="Save to Wishlist"
                    >
                      <Heart className={`w-5 h-5 ${inWishlist ? "fill-rose-500 text-rose-500" : ""}`} />
                    </button>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-gray-600 pt-1">
                    <span className="flex items-center gap-1">
                      <Truck className="w-3.5 h-3.5 text-orange-600" />
                      <span>Free delivery above â¹499</span>
                    </span>
                    <span className="flex items-center gap-1">
                      <RotateCcw className="w-3.5 h-3.5 text-orange-600" />
                      <span>Taste Replacement Guarantee</span>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom Tabs: Specifications, Full Description, Reviews */}
            <div className="border-t border-gray-200 bg-gray-50/70 p-6 sm:p-8">
              {/* Tab Navigation */}
              <div className="flex items-center gap-2 border-b border-gray-200 pb-3 mb-6">
                <button
                  onClick={() => setActiveTab("overview")}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                    activeTab === "overview"
                      ? "bg-orange-600 text-white shadow-xs"
                      : "text-gray-600 hover:bg-gray-200/70"
                  }`}
                >
                  Full Description
                </button>
                <button
                  onClick={() => setActiveTab("specs")}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                    activeTab === "specs"
                      ? "bg-orange-600 text-white shadow-xs"
                      : "text-gray-600 hover:bg-gray-200/70"
                  }`}
                >
                  Specifications
                </button>
                <button
                  onClick={() => setActiveTab("reviews")}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                    activeTab === "reviews"
                      ? "bg-orange-600 text-white shadow-xs"
                      : "text-gray-600 hover:bg-gray-200/70"
                  }`}
                >
                  Verified Reviews ({product.reviews?.length || 0})
                </button>
              </div>

              {/* Tab 1: Description */}
              {activeTab === "overview" && (
                <div className="prose prose-sm max-w-none text-gray-700 text-xs sm:text-sm leading-relaxed">
                  <p>{product.description}</p>
                  {product.tags && product.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 mt-4">
                      {product.tags.map((tag: string) => (
                        <span key={tag} className="text-xs bg-white border border-gray-200 text-gray-600 px-2.5 py-1 rounded-lg">
                          #{tag}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Tab 2: Specifications */}
              {activeTab === "specs" && (
                <div className="bg-white border border-gray-200 rounded-2xl overflow-hidden divide-y divide-gray-100 text-xs">
                  <div className="p-3 flex justify-between">
                    <span className="text-gray-500 font-medium">SKU</span>
                    <span className="font-bold text-gray-900">{product.sku || "N/A"}</span>
                  </div>
                  <div className="p-3 flex justify-between">
                    <span className="text-gray-500 font-medium">Department</span>
                    <span className="font-bold text-gray-900">{product.category?.name}</span>
                  </div>
                  <div className="p-3 flex justify-between">
                    <span className="text-gray-500 font-medium">Seller Store</span>
                    <span className="font-bold text-gray-900">{product.vendor?.storeName}</span>
                  </div>
                  {product.attributes &&
                    Object.entries(product.attributes).map(([k, v]) => (
                      <div key={k} className="p-3 flex justify-between">
                        <span className="text-gray-500 font-medium capitalize">{k}</span>
                        <span className="font-bold text-gray-900">
                          {Array.isArray(v) ? v.join(", ") : String(v)}
                        </span>
                      </div>
                    ))}
                </div>
              )}

              {/* Tab 3: Customer Reviews */}
              {activeTab === "reviews" && (
                <div className="space-y-6">
                  {/* Reviews Summary Header */}
                  <div className="bg-white border border-gray-200 rounded-2xl p-5 flex flex-col sm:flex-row items-center gap-6">
                    <div className="text-center sm:text-left space-y-1">
                      <div className="text-4xl font-black text-gray-900">
                        {(product.rating || 5.0).toFixed(1)}
                      </div>
                      <div className="flex items-center text-amber-400">
                        {[1, 2, 3, 4, 5].map((s) => (
                          <Star key={s} className="w-4 h-4 fill-amber-400 text-amber-400" />
                        ))}
                      </div>
                      <p className="text-xs text-gray-500">Based on {product.reviews?.length || 0} reviews</p>
                    </div>

                    <div className="flex-1 w-full space-y-1.5 text-xs">
                      {[5, 4, 3, 2, 1].map((rating) => {
                        const count = (product.reviews || []).filter((r: any) => r.rating === rating).length;
                        const pct = product.reviews?.length ? Math.round((count / product.reviews.length) * 100) : 0;
                        return (
                          <div key={rating} className="flex items-center gap-2">
                            <span className="w-10 text-gray-600 font-medium">{rating} Stars</span>
                            <div className="flex-1 bg-gray-100 rounded-full h-2 overflow-hidden">
                              <div className="bg-amber-400 h-full rounded-full" style={{ width: `${pct}%` }} />
                            </div>
                            <span className="w-8 text-right text-gray-400 font-mono text-[11px]">{count}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Write a review form */}
                  <div className="bg-white border border-gray-200 rounded-2xl p-5 space-y-3">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-gray-900">
                      Write a Customer Review
                    </h4>
                    {reviewSuccess ? (
                      <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs p-3 rounded-xl flex items-center gap-2">
                        <Check className="w-4 h-4 text-emerald-600" />
                        <span>Thank you! Your verified review has been published.</span>
                      </div>
                    ) : (
                      <form onSubmit={handleSubmitReview} className="space-y-3 text-xs">
                        <div>
                          <label className="block text-gray-700 font-medium mb-1">Your Rating</label>
                          <div className="flex items-center gap-1.5 text-amber-400">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <button
                                type="button"
                                key={star}
                                onClick={() => setReviewRating(star)}
                                className="p-1 hover:scale-110 transition-transform"
                              >
                                <Star
                                  className={`w-5 h-5 ${
                                    star <= reviewRating ? "fill-amber-400 text-amber-400" : "text-gray-300"
                                  }`}
                                />
                              </button>
                            ))}
                            <span className="text-xs font-bold text-gray-700 ml-2">{reviewRating} out of 5</span>
                          </div>
                        </div>

                        <div>
                          <label className="block text-gray-700 font-medium mb-1">Review Headline</label>
                          <input
                            type="text"
                            value={reviewTitle}
                            onChange={(e) => setReviewTitle(e.target.value)}
                            placeholder="e.g. Incredible sound clarity and build quality!"
                            className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 outline-hidden focus:bg-white focus:border-orange-500"
                          />
                        </div>

                        <div>
                          <label className="block text-gray-700 font-medium mb-1">Detailed Feedback</label>
                          <textarea
                            rows={3}
                            required
                            value={reviewComment}
                            onChange={(e) => setReviewComment(e.target.value)}
                            placeholder="What did you like or dislike? How does it perform?"
                            className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 outline-hidden focus:bg-white focus:border-orange-500"
                          />
                        </div>

                        <button
                          type="submit"
                          disabled={isSubmittingReview || !reviewComment.trim()}
                          className="px-5 py-2.5 bg-orange-600 hover:bg-orange-700 disabled:opacity-50 text-white font-bold rounded-xl transition-all"
                        >
                          {isSubmittingReview ? "Submitting..." : "Submit Review"}
                        </button>
                      </form>
                    )}
                  </div>

                  {/* Reviews List */}
                  <div className="space-y-4">
                    {product.reviews && product.reviews.length > 0 ? (
                      product.reviews.map((rev: any) => (
                        <div key={rev.id} className="bg-white border border-gray-200 rounded-2xl p-4 space-y-2.5">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2.5">
                              <img
                                src={rev.user?.avatar || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80"}
                                alt={rev.user?.name || "Customer"}
                                className="w-7 h-7 rounded-full object-cover"
                              />
                              <div>
                                <span className="text-xs font-bold text-gray-900">{rev.user?.name || "Customer"}</span>
                                {rev.isVerifiedPurchase && (
                                  <span className="ml-2 text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded-sm border border-emerald-200">
                                    Verified Buyer
                                  </span>
                                )}
                              </div>
                            </div>
                            <span className="text-[11px] text-gray-400">
                              {new Date(rev.createdAt).toLocaleDateString()}
                            </span>
                          </div>

                          <div className="flex items-center text-amber-400">
                            {[1, 2, 3, 4, 5].map((s) => (
                              <Star
                                key={s}
                                className={`w-3.5 h-3.5 ${
                                  s <= rev.rating ? "fill-amber-400 text-amber-400" : "text-gray-200"
                                }`}
                              />
                            ))}
                            {rev.title && (
                              <span className="text-xs font-bold text-gray-900 ml-2">{rev.title}</span>
                            )}
                          </div>

                          <p className="text-xs text-gray-700 leading-relaxed">{rev.comment}</p>

                          {/* Vendor Reply if present */}
                          {rev.vendorReply && (
                            <div className="bg-orange-50/60 border-l-2 border-orange-600 p-3 rounded-r-xl mt-2 text-xs space-y-1">
                              <div className="flex items-center gap-1.5 text-orange-900 font-bold text-[11px]">
                                <Store className="w-3.5 h-3.5 text-orange-600" />
                                <span>Response from {product.vendor?.storeName}:</span>
                              </div>
                              <p className="text-orange-950 text-xs">{rev.vendorReply}</p>
                            </div>
                          )}

                          {/* Seller Reply Box (if user is seller/admin) */}
                          {user && (user.role === "seller" || user.role === "admin") && !rev.vendorReply && (
                            <div className="mt-2 pt-2 border-t border-gray-100 flex gap-2">
                              <input
                                type="text"
                                placeholder={`Reply as ${product.vendor?.storeName}...`}
                                value={replyTextMap[rev.id] || ""}
                                onChange={(e) => setReplyTextMap({ ...replyTextMap, [rev.id]: e.target.value })}
                                className="flex-1 bg-gray-50 border border-gray-200 rounded-xl px-3 py-1.5 text-xs outline-hidden focus:bg-white"
                              />
                              <button
                                onClick={() => handleVendorReply(rev.id)}
                                className="px-3 py-1.5 bg-orange-600 hover:bg-orange-700 text-white text-xs font-semibold rounded-xl"
                              >
                                Reply
                              </button>
                            </div>
                          )}

                          {/* Helpful button */}
                          <div className="flex items-center gap-3 pt-1 text-[11px] text-gray-400">
                            <button
                              onClick={() => handleVoteHelpful(rev.id)}
                              className="hover:text-gray-600 flex items-center gap-1 transition-colors"
                            >
                              <ThumbsUp className="w-3 h-3" />
                              <span>Helpful ({rev.helpfulCount || 0})</span>
                            </button>
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="text-xs text-gray-500 py-4 text-center">
                        No reviews yet. Be the first verified customer to leave a review!
                      </p>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

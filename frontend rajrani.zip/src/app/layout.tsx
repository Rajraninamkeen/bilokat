import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { AuthProvider } from "@/context/AuthContext";
import { CartProvider } from "@/context/CartContext";
import { WishlistProvider } from "@/context/WishlistContext";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "BILOKAT Namkeen | Rajrani Namkeen Centre · Bikaner Since 1985",
  description:
    "Order authentic Bikaneri namkeen online — BILOKAT bhujia, sev, premium kaju mixture, desi-ghee mathri and festive hampers. Fresh daily batches from Rajrani Namkeen Centre, Bikaner. Pan-India delivery.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={`${inter.className} min-h-screen bg-orange-50/30 text-gray-900 antialiased`}>
        <AuthProvider>
          <CartProvider>
            <WishlistProvider>{children}</WishlistProvider>
          </CartProvider>
        </AuthProvider>
      </body>
    </html>
  );
}

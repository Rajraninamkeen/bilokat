import { NextResponse } from "next/server";
import { db } from "@/db";
import { categories, products } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { ensureDatabaseReady } from "@/db/init";

export async function GET() {
  try {
    await ensureDatabaseReady();

    const allCategories = await db.select().from(categories).orderBy(categories.displayOrder);

    // Count products per category
    const productCounts = await db
      .select({
        categoryId: products.categoryId,
        count: sql<number>`count(*)`,
      })
      .from(products)
      .where(eq(products.status, "active"))
      .groupBy(products.categoryId);

    const countMap = new Map<string, number>();
    productCounts.forEach((pc) => {
      countMap.set(pc.categoryId, Number(pc.count));
    });

    const enrichedCategories = allCategories.map((cat) => ({
      ...cat,
      productCount: countMap.get(cat.id) || 0,
    }));

    return NextResponse.json({ categories: enrichedCategories });
  } catch (error) {
    console.error("Categories GET error:", error);
    return NextResponse.json({ error: "Failed to fetch categories" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    await ensureDatabaseReady();
    const session = await getCurrentUser();

    if (!session || session.user.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized. Admin role required." }, { status: 403 });
    }

    const body = await req.json();
    const { name, description, icon = "Tag", imageUrl, isFeatured = false, displayOrder = 0 } = body;

    if (!name) {
      return NextResponse.json({ error: "Category name is required" }, { status: 400 });
    }

    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
    const id = `cat_${slug}_${Math.random().toString(36).substring(2, 5)}`;

    const newCategory = {
      id,
      name,
      slug,
      description: description || null,
      icon,
      imageUrl: imageUrl || "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80",
      parentId: null,
      isFeatured: !!isFeatured,
      displayOrder: parseInt(displayOrder, 10) || 0,
    };

    await db.insert(categories).values(newCategory);

    return NextResponse.json({ success: true, category: newCategory });
  } catch (error) {
    console.error("Category POST error:", error);
    return NextResponse.json({ error: "Failed to create category" }, { status: 500 });
  }
}

import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  orders,
  orderItems,
  products,
  vendors,
  coupons,
  users,
  type InsertOrder,
  type InsertOrderItem,
} from "@/db/schema";
import { eq, desc, inArray, sql } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { ensureDatabaseReady } from "@/db/init";

export async function GET(req: Request) {
  try {
    await ensureDatabaseReady();
    const session = await getCurrentUser();

    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { user, vendor } = session;
    const { searchParams } = new URL(req.url);
    const status = searchParams.get("status");

    if (user.role === "admin") {
      // Admin sees all orders
      const allOrders = await db.select().from(orders).orderBy(desc(orders.createdAt));

      // Fetch items for all orders
      const orderIds = allOrders.map((o) => o.id);
      let items: any[] = [];
      if (orderIds.length > 0) {
        items = await db
          .select({
            item: orderItems,
            vendor: {
              id: vendors.id,
              storeName: vendors.storeName,
            },
          })
          .from(orderItems)
          .innerJoin(vendors, eq(orderItems.vendorId, vendors.id))
          .where(inArray(orderItems.orderId, orderIds));
      }

      const ordersWithItems = allOrders.map((ord) => ({
        ...ord,
        items: items.filter((i) => i.item.orderId === ord.id).map((i) => ({ ...i.item, vendor: i.vendor })),
      }));

      return NextResponse.json({ orders: ordersWithItems });
    } else if (user.role === "seller" && vendor) {
      // Seller sees orders that have their items
      const sellerItems = await db
        .select({
          item: orderItems,
          order: orders,
        })
        .from(orderItems)
        .innerJoin(orders, eq(orderItems.orderId, orders.id))
        .where(eq(orderItems.vendorId, vendor.id))
        .orderBy(desc(orders.createdAt));

      // Group items by order
      const orderMap = new Map<string, any>();
      sellerItems.forEach(({ item, order }) => {
        if (!orderMap.has(order.id)) {
          orderMap.set(order.id, {
            ...order,
            items: [],
            sellerEarningsTotal: 0,
            sellerPlatformCommission: 0,
          });
        }
        const ord = orderMap.get(order.id);
        ord.items.push(item);
        ord.sellerEarningsTotal += item.vendorEarnings || 0;
        ord.sellerPlatformCommission += item.platformCommission || 0;
      });

      const sellerOrders = Array.from(orderMap.values());
      return NextResponse.json({ orders: sellerOrders });
    } else {
      // Customer sees their own orders
      const customerOrders = await db
        .select()
        .from(orders)
        .where(eq(orders.userId, user.id))
        .orderBy(desc(orders.createdAt));

      const orderIds = customerOrders.map((o) => o.id);
      let items: any[] = [];
      if (orderIds.length > 0) {
        items = await db
          .select({
            item: orderItems,
            vendor: {
              id: vendors.id,
              storeName: vendors.storeName,
            },
          })
          .from(orderItems)
          .innerJoin(vendors, eq(orderItems.vendorId, vendors.id))
          .where(inArray(orderItems.orderId, orderIds));
      }

      const ordersWithItems = customerOrders.map((ord) => ({
        ...ord,
        items: items.filter((i) => i.item.orderId === ord.id).map((i) => ({ ...i.item, vendor: i.vendor })),
      }));

      return NextResponse.json({ orders: ordersWithItems });
    }
  } catch (error) {
    console.error("Orders GET error:", error);
    return NextResponse.json({ error: "Failed to fetch orders" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    await ensureDatabaseReady();
    const session = await getCurrentUser();

    if (!session) {
      return NextResponse.json({ error: "Please log in to place an order" }, { status: 401 });
    }

    const body = await req.json();
    const {
      items, // array of { productId, quantity, selectedVariant }
      shippingAddress,
      billingAddress,
      shippingMethod = "standard",
      paymentMethod = "credit_card",
      couponCode,
      notes,
    } = body;

    if (!items || !Array.isArray(items) || items.length === 0) {
      return NextResponse.json({ error: "Cart is empty" }, { status: 400 });
    }

    if (!shippingAddress || !shippingAddress.fullName || !shippingAddress.addressLine1 || !shippingAddress.city) {
      return NextResponse.json({ error: "Complete shipping address is required" }, { status: 400 });
    }

    // Fetch product details for all cart items
    const productIds = items.map((i: any) => i.productId);
    const dbProducts = await db
      .select({
        product: products,
        vendor: vendors,
      })
      .from(products)
      .innerJoin(vendors, eq(products.vendorId, vendors.id))
      .where(inArray(products.id, productIds));

    const productMap = new Map<string, { product: typeof products.$inferSelect; vendor: typeof vendors.$inferSelect }>();
    dbProducts.forEach((p) => productMap.set(p.product.id, p));

    // Calculate subtotal
    let subtotal = 0;
    const resolvedItems: Array<{
      product: typeof products.$inferSelect;
      vendor: typeof vendors.$inferSelect;
      quantity: number;
      selectedVariant: any;
      itemTotal: number;
    }> = [];

    for (const item of items) {
      const dbEntry = productMap.get(item.productId);
      if (!dbEntry) {
        return NextResponse.json({ error: `Product not found: ${item.productId}` }, { status: 400 });
      }

      const qty = Math.max(1, parseInt(item.quantity, 10) || 1);
      const itemTotal = dbEntry.product.price * qty;
      subtotal += itemTotal;

      resolvedItems.push({
        product: dbEntry.product,
        vendor: dbEntry.vendor,
        quantity: qty,
        selectedVariant: item.selectedVariant || {},
        itemTotal,
      });
    }

    // Coupon discount calculation
    let discountTotal = 0;
    let appliedCoupon = null;
    if (couponCode) {
      const couponResult = await db
        .select()
        .from(coupons)
        .where(eq(coupons.code, couponCode.trim().toUpperCase()))
        .limit(1);

      if (couponResult.length > 0 && couponResult[0].isActive) {
        const cpn = couponResult[0];
        if (subtotal >= (cpn.minSpend || 0)) {
          if (cpn.discountType === "percentage") {
            discountTotal = (subtotal * cpn.discountValue) / 100;
            if (cpn.maxDiscount && discountTotal > cpn.maxDiscount) {
              discountTotal = cpn.maxDiscount;
            }
          } else {
            discountTotal = cpn.discountValue;
          }
          appliedCoupon = cpn;
        }
      }
    }

    discountTotal = Math.min(discountTotal, subtotal);

    // Shipping fee calculation (INR)
    let shippingFee = 0;
    if (shippingMethod === "express") {
      shippingFee = 99;
    } else if (shippingMethod === "next_day") {
      shippingFee = 149;
    } else {
      // standard: Free if subtotal >= 499, else 49
      shippingFee = subtotal >= 499 ? 0 : 49;
    }

    // GST 12% (branded namkeen)
    const taxableAmount = Math.max(0, subtotal - discountTotal);
    const tax = Math.round(taxableAmount * 0.12 * 100) / 100;
    const grandTotal = Math.round((taxableAmount + shippingFee + tax) * 100) / 100;

    const orderId = `ord_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const randomOrderDigits = Math.floor(10000 + Math.random() * 90000);
    const orderNumber = `RNC-${randomOrderDigits}`;

    let platformCommissionTotal = 0;

    // Prepare Order Items
    const lineItemInserts: InsertOrderItem[] = resolvedItems.map((ri, index) => {
      const commissionRate = ri.vendor.commissionRate || 10.0;
      const platformComm = Math.round(((ri.itemTotal * commissionRate) / 100) * 100) / 100;
      const vendorEarn = Math.round((ri.itemTotal - platformComm) * 100) / 100;

      platformCommissionTotal += platformComm;

      return {
        id: `itm_${orderId}_${index + 1}`,
        orderId,
        vendorId: ri.vendor.id,
        productId: ri.product.id,
        productTitle: ri.product.title,
        productImage: ri.product.images?.[0] || "",
        selectedVariant: ri.selectedVariant,
        unitPrice: ri.product.price,
        quantity: ri.quantity,
        totalPrice: ri.itemTotal,
        vendorCommissionRate: commissionRate,
        platformCommission: platformComm,
        vendorEarnings: vendorEarn,
        status: "processing",
        carrierName: null,
        trackingNumber: null,
        createdAt: new Date(),
      };
    });

    // Create Master Order
    const newOrder: InsertOrder = {
      id: orderId,
      orderNumber,
      userId: session.user.id,
      status: "processing",
      subtotal,
      discountTotal,
      couponCode: appliedCoupon ? appliedCoupon.code : null,
      shippingFee,
      tax,
      grandTotal,
      platformCommissionTotal: Math.round(platformCommissionTotal * 100) / 100,
      paymentStatus: "paid",
      paymentMethod,
      shippingAddress,
      billingAddress: billingAddress || shippingAddress,
      shippingMethod,
      notes: notes || null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    await db.insert(orders).values(newOrder);
    await db.insert(orderItems).values(lineItemInserts);

    // Update product stock and sales count, and vendor sales totals
    for (const ri of resolvedItems) {
      await db
        .update(products)
        .set({
          stockQuantity: sql`GREATEST(0, ${products.stockQuantity} - ${ri.quantity})`,
          salesCount: sql`${products.salesCount} + ${ri.quantity}`,
          updatedAt: new Date(),
        })
        .where(eq(products.id, ri.product.id));

      await db
        .update(vendors)
        .set({
          totalSales: sql`${vendors.totalSales} + ${ri.itemTotal}`,
          updatedAt: new Date(),
        })
        .where(eq(vendors.id, ri.vendor.id));
    }

    // Increment coupon usage
    if (appliedCoupon) {
      await db
        .update(coupons)
        .set({ timesUsed: sql`${coupons.timesUsed} + 1` })
        .where(eq(coupons.id, appliedCoupon.id));
    }

    return NextResponse.json({
      success: true,
      order: {
        ...newOrder,
        items: lineItemInserts,
      },
    });
  } catch (error) {
    console.error("Order POST error:", error);
    return NextResponse.json({ error: "Failed to place order" }, { status: 500 });
  }
}

import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders, orderItems, vendors, users, products } from "@/db/schema";
import { eq, or } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { ensureDatabaseReady } from "@/db/init";

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    await ensureDatabaseReady();
    const { id } = await params;
    const session = await getCurrentUser();

    const orderRows = await db
      .select({
        order: orders,
        user: {
          id: users.id,
          name: users.name,
          email: users.email,
        },
      })
      .from(orders)
      .innerJoin(users, eq(orders.userId, users.id))
      .where(or(eq(orders.id, id), eq(orders.orderNumber, id)))
      .limit(1);

    if (orderRows.length === 0) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 });
    }

    const { order, user } = orderRows[0];

    // Fetch order items with vendor details
    const items = await db
      .select({
        item: orderItems,
        vendor: {
          id: vendors.id,
          storeName: vendors.storeName,
          slug: vendors.slug,
          logoUrl: vendors.logoUrl,
        },
      })
      .from(orderItems)
      .innerJoin(vendors, eq(orderItems.vendorId, vendors.id))
      .where(eq(orderItems.orderId, order.id));

    const formattedItems = items.map((i) => ({
      ...i.item,
      vendor: i.vendor,
    }));

    return NextResponse.json({
      order: {
        ...order,
        customer: user,
        items: formattedItems,
      },
    });
  } catch (error) {
    console.error("Order GET error:", error);
    return NextResponse.json({ error: "Failed to fetch order" }, { status: 500 });
  }
}

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    await ensureDatabaseReady();
    const session = await getCurrentUser();

    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Order status / fulfilment changes are restricted to the owner & authorised staff
    if (session.user.role !== "admin" && session.user.role !== "seller") {
      return NextResponse.json({ error: "Owner or authorised staff access required" }, { status: 403 });
    }

    const { id } = await params;
    const body = await req.json();
    const {
      status, // update overall order status
      itemId, // update specific line item fulfillment
      itemStatus,
      carrierName,
      trackingNumber,
    } = body;

    const orderRows = await db.select().from(orders).where(or(eq(orders.id, id), eq(orders.orderNumber, id))).limit(1);
    if (orderRows.length === 0) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 });
    }
    const order = orderRows[0];

    // Update specific line item
    if (itemId) {
      const itemUpdate: any = {};
      if (itemStatus) itemUpdate.status = itemStatus;
      if (carrierName) itemUpdate.carrierName = carrierName;
      if (trackingNumber) itemUpdate.trackingNumber = trackingNumber;
      if (itemStatus === "shipped") itemUpdate.shippedAt = new Date();
      if (itemStatus === "delivered") itemUpdate.deliveredAt = new Date();

      await db.update(orderItems).set(itemUpdate).where(eq(orderItems.id, itemId));

      // Check if all items in order are shipped or delivered, update parent order accordingly
      const allItems = await db.select().from(orderItems).where(eq(orderItems.orderId, order.id));
      const allDelivered = allItems.every((i) => i.id === itemId ? itemStatus === "delivered" : i.status === "delivered");
      const allShipped = allItems.every((i) => i.id === itemId ? (itemStatus === "shipped" || itemStatus === "delivered") : (i.status === "shipped" || i.status === "delivered"));

      if (allDelivered) {
        await db.update(orders).set({ status: "delivered", updatedAt: new Date() }).where(eq(orders.id, order.id));
      } else if (allShipped) {
        await db.update(orders).set({ status: "shipped", updatedAt: new Date() }).where(eq(orders.id, order.id));
      }
    }

    // Direct order status update (e.g. by admin)
    if (status && !itemId) {
      await db.update(orders).set({ status, updatedAt: new Date() }).where(eq(orders.id, order.id));
      // Optionally sync items
      if (status === "delivered" || status === "cancelled") {
        await db.update(orderItems).set({ status }).where(eq(orderItems.orderId, order.id));
      }
    }

    return NextResponse.json({ success: true, message: "Order updated successfully" });
  } catch (error) {
    console.error("Order PATCH error:", error);
    return NextResponse.json({ error: "Failed to update order" }, { status: 500 });
  }
}

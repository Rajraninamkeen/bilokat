import { NextResponse } from "next/server";
import { db } from "@/db";
import { wishlists, products, vendors, categories } from "@/db/schema";
import { eq, and, desc } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { ensureDatabaseReady } from "@/db/init";

export async function GET() {
  try {
    await ensureDatabaseReady();
    const session = await getCurrentUser();

    if (!session) {
      return NextResponse.json({ wishlist: [] });
    }

    const items = await db
      .select({
        wishlist: wishlists,
        product: products,
        vendor: vendors,
        category: categories,
      })
      .from(wishlists)
      .innerJoin(products, eq(wishlists.productId, products.id))
      .innerJoin(vendors, eq(products.vendorId, vendors.id))
      .innerJoin(categories, eq(products.categoryId, categories.id))
      .where(eq(wishlists.userId, session.user.id))
      .orderBy(desc(wishlists.createdAt));

    const formatted = items.map((i) => ({
      ...i.wishlist,
      product: {
        ...i.product,
        vendor: i.vendor,
        category: i.category,
      },
    }));

    return NextResponse.json({ wishlist: formatted });
  } catch (error) {
    console.error("Wishlist GET error:", error);
    return NextResponse.json({ error: "Failed to fetch wishlist" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    await ensureDatabaseReady();
    const session = await getCurrentUser();

    if (!session) {
      return NextResponse.json({ error: "Please sign in to save items to your wishlist" }, { status: 401 });
    }

    const body = await req.json();
    const { productId } = body;

    if (!productId) {
      return NextResponse.json({ error: "productId is required" }, { status: 400 });
    }

    // Check if already in wishlist
    const existing = await db
      .select()
      .from(wishlists)
      .where(and(eq(wishlists.userId, session.user.id), eq(wishlists.productId, productId)))
      .limit(1);

    if (existing.length > 0) {
      // Remove from wishlist
      await db
        .delete(wishlists)
        .where(and(eq(wishlists.userId, session.user.id), eq(wishlists.productId, productId)));

      return NextResponse.json({ inWishlist: false, message: "Removed from wishlist" });
    } else {
      // Add to wishlist
      const newWishlist = {
        id: `wsh_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
        userId: session.user.id,
        productId,
        createdAt: new Date(),
      };
      await db.insert(wishlists).values(newWishlist);

      return NextResponse.json({ inWishlist: true, message: "Added to wishlist" });
    }
  } catch (error) {
    console.error("Wishlist POST error:", error);
    return NextResponse.json({ error: "Failed to update wishlist" }, { status: 500 });
  }
}

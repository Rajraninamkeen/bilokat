import { NextResponse } from "next/server";
import { db } from "@/db";
import { coupons } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { ensureDatabaseReady } from "@/db/init";

export async function GET() {
  try {
    await ensureDatabaseReady();
    const allCoupons = await db.select().from(coupons).orderBy(desc(coupons.createdAt));
    return NextResponse.json({ coupons: allCoupons });
  } catch (error) {
    console.error("Coupons GET error:", error);
    return NextResponse.json({ error: "Failed to fetch coupons" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    await ensureDatabaseReady();
    const session = await getCurrentUser();

    if (!session || (session.user.role !== "admin" && session.user.role !== "seller")) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
    }

    const body = await req.json();
    const {
      code,
      description,
      discountType = "percentage",
      discountValue,
      minSpend = 0,
      maxDiscount,
      usageLimit = 1000,
      vendorId,
    } = body;

    if (!code || discountValue === undefined) {
      return NextResponse.json({ error: "Coupon code and discount value are required" }, { status: 400 });
    }

    const cleanCode = code.trim().toUpperCase().replace(/[^A-Z0-9_-]/g, "");
    const existing = await db.select().from(coupons).where(eq(coupons.code, cleanCode)).limit(1);

    if (existing.length > 0) {
      return NextResponse.json({ error: "A coupon with this code already exists" }, { status: 400 });
    }

    const newCoupon = {
      id: `cpn_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
      code: cleanCode,
      description: description || `${discountValue}${discountType === "percentage" ? "%" : "$"} OFF`,
      discountType,
      discountValue: parseFloat(discountValue),
      minSpend: parseFloat(minSpend) || 0,
      maxDiscount: maxDiscount ? parseFloat(maxDiscount) : null,
      vendorId: vendorId || (session.user.role === "seller" && session.vendor ? session.vendor.id : null),
      usageLimit: parseInt(usageLimit, 10) || 1000,
      timesUsed: 0,
      isActive: true,
      createdAt: new Date(),
    };

    await db.insert(coupons).values(newCoupon);

    return NextResponse.json({ success: true, coupon: newCoupon });
  } catch (error) {
    console.error("Coupons POST error:", error);
    return NextResponse.json({ error: "Failed to create coupon" }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    await ensureDatabaseReady();
    const session = await getCurrentUser();

    if (!session || session.user.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized. Admin role required." }, { status: 403 });
    }

    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "Coupon ID is required" }, { status: 400 });
    }

    await db.delete(coupons).where(eq(coupons.id, id));
    return NextResponse.json({ success: true, message: "Coupon deleted" });
  } catch (error) {
    console.error("Coupons DELETE error:", error);
    return NextResponse.json({ error: "Failed to delete coupon" }, { status: 500 });
  }
}

import { NextResponse } from "next/server";
import { db } from "@/db";
import { coupons } from "@/db/schema";
import { eq } from "drizzle-orm";
import { ensureDatabaseReady } from "@/db/init";

export async function POST(req: Request) {
  try {
    await ensureDatabaseReady();
    const body = await req.json();
    const { code, subtotal = 0 } = body;

    if (!code) {
      return NextResponse.json({ valid: false, error: "Coupon code is required" }, { status: 400 });
    }

    const cleanCode = code.trim().toUpperCase();
    const couponResult = await db.select().from(coupons).where(eq(coupons.code, cleanCode)).limit(1);

    if (couponResult.length === 0) {
      return NextResponse.json({ valid: false, error: "Invalid coupon code" }, { status: 404 });
    }

    const coupon = couponResult[0];

    if (!coupon.isActive) {
      return NextResponse.json({ valid: false, error: "This coupon is no longer active" }, { status: 400 });
    }

    if (coupon.usageLimit && (coupon.timesUsed || 0) >= coupon.usageLimit) {
      return NextResponse.json({ valid: false, error: "Coupon usage limit has been reached" }, { status: 400 });
    }

    if (coupon.minSpend && subtotal < coupon.minSpend) {
      return NextResponse.json(
        {
          valid: false,
          error: `Minimum order spend of â¹{coupon.minSpend.toFixed(2)} required for this coupon`,
        },
        { status: 400 }
      );
    }

    let discountAmount = 0;
    if (coupon.discountType === "percentage") {
      discountAmount = (subtotal * coupon.discountValue) / 100;
      if (coupon.maxDiscount && discountAmount > coupon.maxDiscount) {
        discountAmount = coupon.maxDiscount;
      }
    } else {
      discountAmount = coupon.discountValue;
    }

    discountAmount = Math.min(discountAmount, subtotal);

    return NextResponse.json({
      valid: true,
      coupon: {
        id: coupon.id,
        code: coupon.code,
        description: coupon.description,
        discountType: coupon.discountType,
        discountValue: coupon.discountValue,
        discountAmount: Math.round(discountAmount * 100) / 100,
      },
    });
  } catch (error) {
    console.error("Coupon validate error:", error);
    return NextResponse.json({ valid: false, error: "Failed to validate coupon" }, { status: 500 });
  }
}

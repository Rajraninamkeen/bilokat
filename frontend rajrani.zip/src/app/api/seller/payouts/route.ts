import { NextResponse } from "next/server";
import { db } from "@/db";
import { vendorPayouts, vendors } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { ensureDatabaseReady } from "@/db/init";

export async function GET() {
  try {
    await ensureDatabaseReady();
    const session = await getCurrentUser();

    if (!session || (session.user.role !== "seller" && session.user.role !== "admin")) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
    }

    let vendor = session.vendor;
    if (!vendor) {
      vendor = (await db.select().from(vendors).limit(1))[0];
    }

    if (!vendor) {
      return NextResponse.json({ payouts: [] });
    }

    const payouts = await db
      .select()
      .from(vendorPayouts)
      .where(eq(vendorPayouts.vendorId, vendor.id))
      .orderBy(desc(vendorPayouts.createdAt));

    return NextResponse.json({ payouts });
  } catch (error) {
    console.error("Payouts GET error:", error);
    return NextResponse.json({ error: "Failed to fetch payouts" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    await ensureDatabaseReady();
    const session = await getCurrentUser();

    if (!session || !session.vendor) {
      return NextResponse.json({ error: "Vendor account required" }, { status: 403 });
    }

    const body = await req.json();
    const { amount, method = "bank_transfer", notes } = body;

    const withdrawAmount = parseFloat(amount);
    if (!withdrawAmount || withdrawAmount <= 0) {
      return NextResponse.json({ error: "Valid payout amount required" }, { status: 400 });
    }

    const fee = Math.round(withdrawAmount * 0.015 * 100) / 100; // 1.5% gateway settlement charge
    const netAmount = Math.max(0, withdrawAmount - fee);

    const newPayout = {
      id: `pay_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      vendorId: session.vendor.id,
      amount: withdrawAmount,
      fee,
      netAmount,
      status: "completed",
      method,
      referenceNumber: `TXN-ACH-${Math.floor(100000 + Math.random() * 900000)}`,
      notes: notes || "Seller requested payout transfer",
      processedAt: new Date(),
      createdAt: new Date(),
    };

    await db.insert(vendorPayouts).values(newPayout);

    return NextResponse.json({ success: true, payout: newPayout });
  } catch (error) {
    console.error("Payout POST error:", error);
    return NextResponse.json({ error: "Failed to process payout" }, { status: 500 });
  }
}

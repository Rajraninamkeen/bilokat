import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { users, vendors } from "@/db/schema";
import { ensureDatabaseReady } from "@/db/init";

export async function GET() {
  try {
    await ensureDatabaseReady();
    const session = await getCurrentUser();

    // Also get all available users for persona switching
    const allUsers = await db.select().from(users);
    const allVendors = await db.select().from(vendors);

    const demoPersonas = allUsers.map((u) => {
      const v = allVendors.find((ven) => ven.userId === u.id);
      return {
        id: u.id,
        name: u.name,
        email: u.email,
        role: u.role,
        avatar: u.avatar,
        storeName: v?.storeName || null,
        vendorId: v?.id || null,
      };
    });

    return NextResponse.json({
      user: session?.user || null,
      vendor: session?.vendor || null,
      demoPersonas,
    });
  } catch (error) {
    console.error("Auth me error:", error);
    return NextResponse.json({ error: "Failed to fetch session" }, { status: 500 });
  }
}

import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { db } from "@/db";
import { users, vendors } from "@/db/schema";
import { eq } from "drizzle-orm";
import { SESSION_COOKIE_NAME } from "@/lib/auth";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { userId } = body;

    if (!userId) {
      return NextResponse.json({ error: "userId is required" }, { status: 400 });
    }

    const userResult = await db.select().from(users).where(eq(users.id, userId)).limit(1);
    const user = userResult[0];

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    const vendorResult = await db.select().from(vendors).where(eq(vendors.userId, user.id)).limit(1);
    const vendor = vendorResult[0] || null;

    const cookieStore = await cookies();
    cookieStore.set(SESSION_COOKIE_NAME, user.id, {
      path: "/",
      httpOnly: true,
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 30, // 30 days
    });

    return NextResponse.json({
      success: true,
      user,
      vendor,
    });
  } catch (error) {
    console.error("Switch user error:", error);
    return NextResponse.json({ error: "Failed to switch user" }, { status: 500 });
  }
}

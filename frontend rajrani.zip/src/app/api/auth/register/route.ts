import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, vendors } from "@/db/schema";
import { eq } from "drizzle-orm";
import { cookies } from "next/headers";
import { SESSION_COOKIE_NAME } from "@/lib/auth";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { name, email, password, role = "customer", phone, storeName, storeDescription } = body;

    if (!name || !email) {
      return NextResponse.json({ error: "Name and email are required" }, { status: 400 });
    }

    // Check if user already exists
    const existing = await db.select().from(users).where(eq(users.email, email.toLowerCase().trim())).limit(1);
    if (existing.length > 0) {
      return NextResponse.json({ error: "User with this email already exists" }, { status: 400 });
    }

    const userId = `usr_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const newUser = {
      id: userId,
      name,
      email: email.toLowerCase().trim(),
      passwordHash: password ? "demo_hashed" : null,
      role: role === "seller" ? "seller" : "customer",
      phone: phone || null,
      avatar: `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80`,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    await db.insert(users).values(newUser);

    let createdVendor = null;
    if (role === "seller" && storeName) {
      const vendorId = `ven_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      const slug = storeName.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
      
      const newVendor = {
        id: vendorId,
        userId: userId,
        storeName,
        slug: slug || `store-${Date.now()}`,
        description: storeDescription || `Welcome to ${storeName}`,
        contactEmail: email,
        contactPhone: phone || null,
        status: "active",
        isVerified: true,
        commissionRate: 10.0,
        logoUrl: "https://images.unsplash.com/photo-1572021335469-31706a17aaef?auto=format&fit=crop&w=300&q=80",
        bannerUrl: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=1200&q=80",
        totalSales: 0,
        rating: 5.0,
        reviewCount: 0,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      await db.insert(vendors).values(newVendor);
      createdVendor = newVendor;
    }

    const cookieStore = await cookies();
    cookieStore.set(SESSION_COOKIE_NAME, userId, {
      path: "/",
      httpOnly: true,
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 30,
    });

    return NextResponse.json({
      success: true,
      user: newUser,
      vendor: createdVendor,
    });
  } catch (error) {
    console.error("Register error:", error);
    return NextResponse.json({ error: "Failed to create account" }, { status: 500 });
  }
}

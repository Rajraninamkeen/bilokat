import { NextResponse } from "next/server";
import { db } from "@/db";
import { products, categories, vendors, reviews, users } from "@/db/schema";
import { eq, or, and, desc } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { ensureDatabaseReady } from "@/db/init";

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    await ensureDatabaseReady();
    const { id } = await params;

    // Search by ID or slug
    const prodRows = await db
      .select({
        product: products,
        category: categories,
        vendor: vendors,
      })
      .from(products)
      .innerJoin(categories, eq(products.categoryId, categories.id))
      .innerJoin(vendors, eq(products.vendorId, vendors.id))
      .where(or(eq(products.id, id), eq(products.slug, id)))
      .limit(1);

    if (prodRows.length === 0) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 });
    }

    const { product, category, vendor } = prodRows[0];

    // Get reviews for this product with user info
    const reviewRows = await db
      .select({
        review: reviews,
        user: {
          id: users.id,
          name: users.name,
          avatar: users.avatar,
        },
      })
      .from(reviews)
      .innerJoin(users, eq(reviews.userId, users.id))
      .where(eq(reviews.productId, product.id))
      .orderBy(desc(reviews.createdAt));

    const productReviews = reviewRows.map((r) => ({
      ...r.review,
      user: r.user,
    }));

    // Get related products in same category
    const relatedRows = await db
      .select({
        product: products,
        vendor: vendors,
      })
      .from(products)
      .innerJoin(vendors, eq(products.vendorId, vendors.id))
      .where(and(eq(products.categoryId, product.categoryId), eq(products.status, "active")))
      .limit(6);

    const relatedProducts = relatedRows
      .filter((r) => r.product.id !== product.id)
      .slice(0, 4)
      .map((r) => ({
        ...r.product,
        vendor: r.vendor,
      }));

    return NextResponse.json({
      product: {
        ...product,
        category,
        vendor,
        reviews: productReviews,
      },
      relatedProducts,
    });
  } catch (error) {
    console.error("Product GET error:", error);
    return NextResponse.json({ error: "Failed to fetch product" }, { status: 500 });
  }
}

export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    await ensureDatabaseReady();
    const session = await getCurrentUser();

    if (!session || (session.user.role !== "seller" && session.user.role !== "admin")) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
    }

    const { id } = await params;
    const body = await req.json();

    const existingResult = await db.select().from(products).where(eq(products.id, id)).limit(1);
    const existing = existingResult[0];

    if (!existing) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 });
    }

    // If seller, ensure they own the product
    if (session.user.role === "seller" && session.vendor && existing.vendorId !== session.vendor.id) {
      return NextResponse.json({ error: "Forbidden. You can only edit your own products." }, { status: 403 });
    }

    const {
      title,
      description,
      shortDescription,
      price,
      compareAtPrice,
      costPrice,
      sku,
      stockQuantity,
      categoryId,
      images,
      tags,
      attributes,
      status,
      isFeatured,
      isApproved,
    } = body;

    const updateData: Partial<typeof products.$inferInsert> = {
      updatedAt: new Date(),
    };

    if (title !== undefined) updateData.title = title;
    if (description !== undefined) updateData.description = description;
    if (shortDescription !== undefined) updateData.shortDescription = shortDescription;
    if (price !== undefined) updateData.price = parseFloat(price);
    if (compareAtPrice !== undefined) updateData.compareAtPrice = compareAtPrice ? parseFloat(compareAtPrice) : null;
    if (costPrice !== undefined) updateData.costPrice = costPrice ? parseFloat(costPrice) : null;
    if (sku !== undefined) updateData.sku = sku;
    if (stockQuantity !== undefined) updateData.stockQuantity = parseInt(stockQuantity, 10);
    if (categoryId !== undefined) updateData.categoryId = categoryId;
    if (images !== undefined) updateData.images = images;
    if (tags !== undefined) updateData.tags = tags;
    if (attributes !== undefined) updateData.attributes = attributes;
    if (status !== undefined) updateData.status = status;
    if (isFeatured !== undefined) updateData.isFeatured = isFeatured;
    if (isApproved !== undefined && session.user.role === "admin") updateData.isApproved = isApproved;

    await db.update(products).set(updateData).where(eq(products.id, id));

    const updated = (await db.select().from(products).where(eq(products.id, id)).limit(1))[0];

    return NextResponse.json({ success: true, product: updated });
  } catch (error) {
    console.error("Product PUT error:", error);
    return NextResponse.json({ error: "Failed to update product" }, { status: 500 });
  }
}

export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    await ensureDatabaseReady();
    const session = await getCurrentUser();

    if (!session || (session.user.role !== "seller" && session.user.role !== "admin")) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
    }

    const { id } = await params;
    const existing = (await db.select().from(products).where(eq(products.id, id)).limit(1))[0];

    if (!existing) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 });
    }

    if (session.user.role === "seller" && session.vendor && existing.vendorId !== session.vendor.id) {
      return NextResponse.json({ error: "Forbidden. You can only delete your own products." }, { status: 403 });
    }

    await db.delete(products).where(eq(products.id, id));

    return NextResponse.json({ success: true, message: "Product deleted" });
  } catch (error) {
    console.error("Product DELETE error:", error);
    return NextResponse.json({ error: "Failed to delete product" }, { status: 500 });
  }
}

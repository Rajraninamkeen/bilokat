import { NextResponse } from "next/server";
import { db } from "@/db";
import { products, categories, vendors, reviews, type InsertProduct } from "@/db/schema";
import { eq, and, gte, lte, ilike, desc, asc, sql } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { ensureDatabaseReady } from "@/db/init";

export async function GET(req: Request) {
  try {
    await ensureDatabaseReady();
    const { searchParams } = new URL(req.url);

    const query = searchParams.get("q") || searchParams.get("search");
    const category = searchParams.get("category"); // slug or id
    const vendorId = searchParams.get("vendorId");
    const minPrice = searchParams.get("minPrice") ? parseFloat(searchParams.get("minPrice")!) : undefined;
    const maxPrice = searchParams.get("maxPrice") ? parseFloat(searchParams.get("maxPrice")!) : undefined;
    const minRating = searchParams.get("minRating") ? parseFloat(searchParams.get("minRating")!) : undefined;
    const isFeatured = searchParams.get("featured") === "true";
    const status = searchParams.get("status") || "active";
    const sort = searchParams.get("sort") || "featured";
    const limit = searchParams.get("limit") ? parseInt(searchParams.get("limit")!) : 50;

    // Fetch all active products joined with vendor & category
    const rows = await db
      .select({
        product: products,
        category: categories,
        vendor: vendors,
      })
      .from(products)
      .innerJoin(categories, eq(products.categoryId, categories.id))
      .innerJoin(vendors, eq(products.vendorId, vendors.id));

    let filtered = rows.map((r) => ({
      ...r.product,
      category: r.category,
      vendor: r.vendor,
    }));

    // Apply status filter (if not "all")
    if (status !== "all") {
      filtered = filtered.filter((p) => p.status === status);
    }

    // Apply Search Query
    if (query && query.trim() !== "") {
      const qLower = query.toLowerCase().trim();
      filtered = filtered.filter((p) => {
        const titleMatch = p.title.toLowerCase().includes(qLower);
        const descMatch = p.description.toLowerCase().includes(qLower);
        const vendorMatch = p.vendor?.storeName.toLowerCase().includes(qLower);
        const tagMatch = Array.isArray(p.tags) && p.tags.some((t) => t.toLowerCase().includes(qLower));
        const catMatch = p.category?.name.toLowerCase().includes(qLower);
        return titleMatch || descMatch || vendorMatch || tagMatch || catMatch;
      });
    }

    // Apply Category filter
    if (category && category !== "all") {
      filtered = filtered.filter(
        (p) => p.category?.slug === category || p.categoryId === category
      );
    }

    // Apply Vendor filter
    if (vendorId && vendorId !== "all") {
      filtered = filtered.filter((p) => p.vendorId === vendorId || p.vendor?.slug === vendorId);
    }

    // Apply Price filter
    if (minPrice !== undefined && !isNaN(minPrice)) {
      filtered = filtered.filter((p) => p.price >= minPrice);
    }
    if (maxPrice !== undefined && !isNaN(maxPrice)) {
      filtered = filtered.filter((p) => p.price <= maxPrice);
    }

    // Apply Rating filter
    if (minRating !== undefined && !isNaN(minRating)) {
      filtered = filtered.filter((p) => (p.rating || 0) >= minRating);
    }

    // Apply Featured filter
    if (isFeatured) {
      filtered = filtered.filter((p) => p.isFeatured);
    }

    // Sorting
    filtered.sort((a, b) => {
      switch (sort) {
        case "price_asc":
          return a.price - b.price;
        case "price_desc":
          return b.price - a.price;
        case "rating":
          return (b.rating || 0) - (a.rating || 0);
        case "sales":
        case "popular":
          return (b.salesCount || 0) - (a.salesCount || 0);
        case "newest":
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        case "featured":
        default:
          if (a.isFeatured && !b.isFeatured) return -1;
          if (!a.isFeatured && b.isFeatured) return 1;
          return (b.salesCount || 0) - (a.salesCount || 0);
      }
    });

    const paginated = filtered.slice(0, limit);

    return NextResponse.json({
      products: paginated,
      total: filtered.length,
    });
  } catch (error) {
    console.error("Products GET error:", error);
    return NextResponse.json({ error: "Failed to fetch products" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    await ensureDatabaseReady();
    const session = await getCurrentUser();

    if (!session || (session.user.role !== "seller" && session.user.role !== "admin")) {
      return NextResponse.json({ error: "Unauthorized. Seller or Admin required." }, { status: 403 });
    }

    const body = await req.json();
    const {
      title,
      description,
      shortDescription,
      price,
      compareAtPrice,
      costPrice,
      sku,
      stockQuantity = 10,
      categoryId,
      images = [],
      tags = [],
      attributes = {},
      isFeatured = false,
      vendorId: explicitVendorId,
    } = body;

    if (!title || !description || price === undefined || !categoryId) {
      return NextResponse.json({ error: "Title, description, price, and category are required" }, { status: 400 });
    }

    // Determine vendorId
    let targetVendorId = explicitVendorId;
    if (!targetVendorId) {
      if (session.vendor) {
        targetVendorId = session.vendor.id;
      } else {
        // Fallback to first vendor if admin is creating
        const firstVendor = (await db.select().from(vendors).limit(1))[0];
        targetVendorId = firstVendor?.id;
      }
    }

    if (!targetVendorId) {
      return NextResponse.json({ error: "Valid vendor account required to create products" }, { status: 400 });
    }

    const productId = `prd_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const baseSlug = title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "");
    const slug = `${baseSlug}-${Math.random().toString(36).substring(2, 6)}`;

    const newProduct: InsertProduct = {
      id: productId,
      vendorId: targetVendorId,
      categoryId,
      title,
      slug,
      description,
      shortDescription: shortDescription || title,
      price: parseFloat(price),
      compareAtPrice: compareAtPrice ? parseFloat(compareAtPrice) : null,
      costPrice: costPrice ? parseFloat(costPrice) : null,
      sku: sku || `SKU-${Math.random().toString(36).substring(2, 8).toUpperCase()}`,
      stockQuantity: parseInt(stockQuantity, 10) || 0,
      images: Array.isArray(images) && images.length > 0 ? images : ["/images/hero-namkeen.jpg"],
      tags: Array.isArray(tags) ? tags : [],
      attributes: typeof attributes === "object" ? attributes : {},
      status: "active",
      isFeatured: !!isFeatured,
      isApproved: true,
      rating: 5.0,
      reviewCount: 0,
      salesCount: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    await db.insert(products).values(newProduct);

    return NextResponse.json({ success: true, product: newProduct });
  } catch (error) {
    console.error("Products POST error:", error);
    return NextResponse.json({ error: "Failed to create product" }, { status: 500 });
  }
}

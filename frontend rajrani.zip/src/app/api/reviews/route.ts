import { NextResponse } from "next/server";
import { db } from "@/db";
import { reviews, products, vendors, users } from "@/db/schema";
import { eq, desc, and, sql } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { ensureDatabaseReady } from "@/db/init";

export async function GET(req: Request) {
  try {
    await ensureDatabaseReady();
    const { searchParams } = new URL(req.url);
    const productId = searchParams.get("productId");
    const vendorId = searchParams.get("vendorId");

    let query = db
      .select({
        review: reviews,
        user: {
          id: users.id,
          name: users.name,
          avatar: users.avatar,
        },
        product: {
          id: products.id,
          title: products.title,
        },
      })
      .from(reviews)
      .innerJoin(users, eq(reviews.userId, users.id))
      .innerJoin(products, eq(reviews.productId, products.id));

    const rows = await query.orderBy(desc(reviews.createdAt));
    let filtered = rows;

    if (productId) {
      filtered = filtered.filter((r) => r.review.productId === productId);
    }
    if (vendorId) {
      filtered = filtered.filter((r) => r.review.vendorId === vendorId);
    }

    const formatted = filtered.map((r) => ({
      ...r.review,
      user: r.user,
      product: r.product,
    }));

    return NextResponse.json({ reviews: formatted });
  } catch (error) {
    console.error("Reviews GET error:", error);
    return NextResponse.json({ error: "Failed to fetch reviews" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    await ensureDatabaseReady();
    const session = await getCurrentUser();

    if (!session) {
      return NextResponse.json({ error: "Please log in to submit a review" }, { status: 401 });
    }

    const body = await req.json();
    const { productId, rating, title, comment } = body;

    if (!productId || !rating || !comment) {
      return NextResponse.json({ error: "Product ID, rating (1-5), and review comment are required" }, { status: 400 });
    }

    const product = (await db.select().from(products).where(eq(products.id, productId)).limit(1))[0];
    if (!product) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 });
    }

    const reviewId = `rev_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`;
    const newReview = {
      id: reviewId,
      productId,
      userId: session.user.id,
      vendorId: product.vendorId,
      rating: Math.max(1, Math.min(5, parseInt(rating, 10))),
      title: title || "Customer Review",
      comment,
      isVerifiedPurchase: true,
      helpfulCount: 0,
      createdAt: new Date(),
    };

    await db.insert(reviews).values(newReview);

    // Recalculate average rating for product
    const allProdReviews = await db.select().from(reviews).where(eq(reviews.productId, productId));
    const avgRating = allProdReviews.reduce((acc, r) => acc + r.rating, 0) / allProdReviews.length;

    await db
      .update(products)
      .set({
        rating: Math.round(avgRating * 10) / 10,
        reviewCount: allProdReviews.length,
        updatedAt: new Date(),
      })
      .where(eq(products.id, productId));

    // Recalculate vendor rating
    const allVendorReviews = await db.select().from(reviews).where(eq(reviews.vendorId, product.vendorId));
    const vendorAvg = allVendorReviews.reduce((acc, r) => acc + r.rating, 0) / allVendorReviews.length;

    await db
      .update(vendors)
      .set({
        rating: Math.round(vendorAvg * 10) / 10,
        reviewCount: allVendorReviews.length,
        updatedAt: new Date(),
      })
      .where(eq(vendors.id, product.vendorId));

    return NextResponse.json({
      success: true,
      review: {
        ...newReview,
        user: {
          id: session.user.id,
          name: session.user.name,
          avatar: session.user.avatar,
        },
      },
    });
  } catch (error) {
    console.error("Reviews POST error:", error);
    return NextResponse.json({ error: "Failed to submit review" }, { status: 500 });
  }
}

export async function PATCH(req: Request) {
  try {
    await ensureDatabaseReady();
    const session = await getCurrentUser();

    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { reviewId, vendorReply, voteHelpful } = body;

    if (!reviewId) {
      return NextResponse.json({ error: "reviewId is required" }, { status: 400 });
    }

    if (voteHelpful) {
      await db
        .update(reviews)
        .set({ helpfulCount: sql`${reviews.helpfulCount} + 1` })
        .where(eq(reviews.id, reviewId));
      return NextResponse.json({ success: true, message: "Marked as helpful" });
    }

    if (vendorReply) {
      if (session.user.role !== "seller" && session.user.role !== "admin") {
        return NextResponse.json({ error: "Seller account required to post reply" }, { status: 403 });
      }

      await db
        .update(reviews)
        .set({
          vendorReply,
          vendorRepliedAt: new Date(),
        })
        .where(eq(reviews.id, reviewId));

      return NextResponse.json({ success: true, message: "Vendor reply saved" });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Reviews PATCH error:", error);
    return NextResponse.json({ error: "Failed to update review" }, { status: 500 });
  }
}

import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq, inArray, desc } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { ensureDatabaseReady } from "@/db/init";

// Owner-only staff management: list team, add staff, revoke access.
export async function GET() {
  try {
    await ensureDatabaseReady();
    const session = await getCurrentUser();

    if (!session || session.user.role !== "admin") {
      return NextResponse.json({ error: "Owner access required" }, { status: 403 });
    }

    const team = await db
      .select()
      .from(users)
      .where(inArray(users.role, ["admin", "seller"]))
      .orderBy(desc(users.createdAt));

    return NextResponse.json({
      team: team.map((u) => ({
        id: u.id,
        name: u.name,
        email: u.email,
        phone: u.phone,
        role: u.role,
        avatar: u.avatar,
        createdAt: u.createdAt,
      })),
    });
  } catch (error) {
    console.error("Staff GET error:", error);
    return NextResponse.json({ error: "Failed to load team" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    await ensureDatabaseReady();
    const session = await getCurrentUser();

    if (!session || session.user.role !== "admin") {
      return NextResponse.json({ error: "Only the owner can add staff accounts" }, { status: 403 });
    }

    const body = await req.json();
    const { name, email, phone } = body;

    if (!name?.trim() || !email?.trim()) {
      return NextResponse.json({ error: "Staff name and email are required" }, { status: 400 });
    }

    const cleanEmail = email.toLowerCase().trim();
    const existing = await db.select().from(users).where(eq(users.email, cleanEmail)).limit(1);
    if (existing.length > 0) {
      return NextResponse.json({ error: "An account with this email already exists" }, { status: 400 });
    }

    const staffUser = {
      id: `usr_staff_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name: name.trim(),
      email: cleanEmail,
      role: "seller", // internal role for authorised Store Panel staff
      phone: phone?.trim() || null,
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80",
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    await db.insert(users).values(staffUser);

    return NextResponse.json({ success: true, staff: staffUser });
  } catch (error) {
    console.error("Staff POST error:", error);
    return NextResponse.json({ error: "Failed to add staff member" }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    await ensureDatabaseReady();
    const session = await getCurrentUser();

    if (!session || session.user.role !== "admin") {
      return NextResponse.json({ error: "Only the owner can revoke staff access" }, { status: 403 });
    }

    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "Staff ID is required" }, { status: 400 });
    }

    if (id === session.user.id) {
      return NextResponse.json({ error: "You cannot revoke the owner account" }, { status: 400 });
    }

    // Downgrade staff account to a regular customer (access revoked, history kept)
    await db.update(users).set({ role: "customer", updatedAt: new Date() }).where(eq(users.id, id));

    return NextResponse.json({ success: true, message: "Staff access revoked" });
  } catch (error) {
    console.error("Staff DELETE error:", error);
    return NextResponse.json({ error: "Failed to revoke staff access" }, { status: 500 });
  }
}

"use client";

import React, { useState, useEffect, useCallback } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { ProductCard } from "@/components/product/ProductCard";
import { CartDrawer } from "@/components/cart/CartDrawer";
import { CheckoutModal } from "@/components/checkout/CheckoutModal";
import { ProductDetailModal } from "@/components/product/ProductDetailModal";
import { OrderTrackingModal } from "@/components/order/OrderTrackingModal";
import { AdminDashboard } from "@/components/admin/AdminDashboard";
import { SellerDashboard } from "@/components/seller/SellerDashboard";
import { SellerStorefront } from "@/components/seller/SellerStorefront";
import { WishlistPage } from "@/components/wishlist/WishlistPage";
import { OrdersPage } from "@/components/order/OrdersPage";
import { AuthModal } from "@/components/auth/AuthModal";
import { AccessDenied } from "@/components/auth/PanelGate";
import { useAuth } from "@/context/AuthContext";
import {
  SlidersHorizontal,
  Star,
  ArrowRight,
  Search,
  Flame,
  BadgeCheck,
  HandPlatter,
  Sparkles,
  X,
} from "lucide-react";

export default function StorefrontPage() {
  const { user } = useAuth();
  const [currentView, setCurrentView] = useState<
    "marketplace" | "seller" | "admin" | "wishlist" | "orders" | "storefront"
  >("marketplace");

  const isOwner = user?.role === "admin";
  const isStaff = user?.role === "seller";

  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [minPrice, setMinPrice] = useState<number | "">("");
  const [maxPrice, setMaxPrice] = useState<number | "">("");
  const [minRating, setMinRating] = useState<number>(0);
  const [sortOption, setSortOption] = useState<string>("featured");

  const [products, setProducts] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  const [isCheckoutModalOpen, setIsCheckoutModalOpen] = useState(false);
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  const [trackingOrderId, setTrackingOrderId] = useState<string | null>(null);
  const [storefrontVendorSlug, setStorefrontVendorSlug] = useState<string | null>(null);
  const [isMobileFiltersOpen, setIsMobileFiltersOpen] = useState(false);

  const fetchProducts = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (selectedCategory && selectedCategory !== "all") params.append("category", selectedCategory);
      if (searchQuery) params.append("q", searchQuery);
      if (minPrice !== "") params.append("minPrice", String(minPrice));
      if (maxPrice !== "") params.append("maxPrice", String(maxPrice));
      if (minRating > 0) params.append("minRating", String(minRating));
      if (sortOption) params.append("sort", sortOption);

      const res = await fetch(`/api/products?${params.toString()}`);
      if (res.ok) {
        const data = await res.json();
        setProducts(data.products || []);
      }
    } catch (e) {
      console.error("Failed to load products", e);
    } finally {
      setLoading(false);
    }
  }, [selectedCategory, searchQuery, minPrice, maxPrice, minRating, sortOption]);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  useEffect(() => {
    fetch("/api/categories")
      .then((res) => res.json())
      .then((data) => setCategories(data.categories || []))
      .catch((e) => console.error("Categories fetch error", e));
  }, []);

  const handleOrderSuccess = (orderId: string) => {
    setIsCheckoutModalOpen(false);
    setTrackingOrderId(orderId);
  };

  const clearAllFilters = () => {
    setSelectedCategory("all");
    setSearchQuery("");
    setMinPrice("");
    setMaxPrice("");
    setMinRating(0);
    setSortOption("featured");
  };

  const activeFiltersCount =
    (selectedCategory !== "all" ? 1 : 0) +
    (minPrice !== "" ? 1 : 0) +
    (maxPrice !== "" ? 1 : 0) +
    (minRating > 0 ? 1 : 0) +
    (searchQuery ? 1 : 0);

  const showHero = !searchQuery && selectedCategory === "all" && currentView === "marketplace";

  const FiltersPanel = (
    <div className="space-y-6">
      {/* Categories */}
      <div className="space-y-2 text-xs">
        <label className="font-bold text-gray-800 uppercase tracking-wide text-[11px]">Namkeen Range</label>
        <div className="space-y-1">
          <button
            onClick={() => setSelectedCategory("all")}
            className={`w-full text-left px-3 py-1.5 rounded-xl transition-all ${
              selectedCategory === "all" ? "bg-orange-50 text-orange-700 font-bold" : "text-gray-600 hover:bg-orange-50/60"
            }`}
          >
            All Namkeen
          </button>
          {categories.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedCategory(c.slug)}
              className={`w-full text-left px-3 py-1.5 rounded-xl transition-all flex items-center justify-between ${
                selectedCategory === c.slug ? "bg-orange-50 text-orange-700 font-bold" : "text-gray-600 hover:bg-orange-50/60"
              }`}
            >
              <span className="truncate">{c.name}</span>
              <span className="text-[10px] text-gray-400">({c.productCount || 0})</span>
            </button>
          ))}
        </div>
      </div>

      {/* Price */}
      <div className="space-y-2 text-xs pt-4 border-t border-orange-100">
        <label className="font-bold text-gray-800 uppercase tracking-wide text-[11px]">Price (₹)</label>
        <div className="grid grid-cols-2 gap-2">
          <input
            type="number"
            placeholder="Min"
            value={minPrice}
            onChange={(e) => setMinPrice(e.target.value === "" ? "" : parseFloat(e.target.value))}
            className="w-full bg-orange-50/60 border border-orange-100 rounded-xl px-3 py-1.5 text-xs outline-hidden focus:bg-white focus:border-orange-400"
          />
          <input
            type="number"
            placeholder="Max"
            value={maxPrice}
            onChange={(e) => setMaxPrice(e.target.value === "" ? "" : parseFloat(e.target.value))}
            className="w-full bg-orange-50/60 border border-orange-100 rounded-xl px-3 py-1.5 text-xs outline-hidden focus:bg-white focus:border-orange-400"
          />
        </div>
      </div>

      {/* Rating */}
      <div className="space-y-2 text-xs pt-4 border-t border-orange-100">
        <label className="font-bold text-gray-800 uppercase tracking-wide text-[11px]">Customer Rating</label>
        <div className="space-y-1">
          {[4.8, 4.5, 4.0, 0].map((r) => (
            <button
              key={r}
              onClick={() => setMinRating(r)}
              className={`w-full text-left px-3 py-1.5 rounded-xl transition-all flex items-center gap-1.5 ${
                minRating === r ? "bg-orange-50 text-orange-700 font-bold" : "text-gray-600 hover:bg-orange-50/60"
              }`}
            >
              {r > 0 ? (
                <>
                  <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                  <span>{r.toFixed(1)} & Up</span>
                </>
              ) : (
                <span>All Ratings</span>
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex flex-col bg-orange-50/30 text-gray-900 selection:bg-orange-500 selection:text-white">
      <Navbar
        currentView={currentView}
        setCurrentView={setCurrentView}
        selectedCategory={selectedCategory}
        setSelectedCategory={setSelectedCategory}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
      />

      <main className="flex-1">
        {currentView === "seller" &&
          (isOwner || isStaff ? (
            <SellerDashboard onOpenProductDetail={(id) => setSelectedProductId(id)} />
          ) : (
            <AccessDenied panelName="Store Panel" onBackToShop={() => setCurrentView("marketplace")} />
          ))}
        {currentView === "admin" &&
          (isOwner ? (
            <AdminDashboard onOpenProductDetail={(id) => setSelectedProductId(id)} />
          ) : (
            <AccessDenied panelName="Owner Panel" ownerOnly onBackToShop={() => setCurrentView("marketplace")} />
          ))}
        {currentView === "wishlist" && (
          <WishlistPage
            onSelectProduct={(p) => setSelectedProductId(p.id)}
            onExploreClick={() => {
              setCurrentView("marketplace");
              setSelectedCategory("all");
            }}
          />
        )}
        {currentView === "orders" && (
          <OrdersPage
            onOpenTracking={(id) => setTrackingOrderId(id)}
            onExploreClick={() => {
              setCurrentView("marketplace");
              setSelectedCategory("all");
            }}
            onSelectProduct={(id) => setSelectedProductId(id)}
          />
        )}
        {currentView === "storefront" && storefrontVendorSlug && (
          <SellerStorefront
            vendorSlug={storefrontVendorSlug}
            onBack={() => setCurrentView("marketplace")}
            onSelectProduct={(p) => setSelectedProductId(p.id)}
          />
        )}

        {currentView === "marketplace" && (
          <div className="space-y-10 pb-16">
            {/* HERO */}
            {showHero && (
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
                <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-red-950 via-red-900 to-orange-900 text-white shadow-2xl border border-red-900/60">
                  <div className="relative z-10 grid lg:grid-cols-2 items-center">
                    <div className="p-8 sm:p-12 space-y-5">
                      <div className="inline-flex items-center gap-2 bg-yellow-400/15 border border-yellow-400/40 px-3 py-1 rounded-full text-yellow-300 text-xs font-bold uppercase tracking-wider">
                        <Flame className="w-3.5 h-3.5" />
                        <span>Fresh Batch Every Morning · Since 1985</span>
                      </div>
                      <h1 className="text-3xl sm:text-5xl font-black tracking-tight leading-tight">
                        Asli Bikaneri Namkeen,{" "}
                        <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-orange-400">
                          Ghar Ke Jaisa Swaad.
                        </span>
                      </h1>
                      <p className="text-sm sm:text-base text-orange-100/80 leading-relaxed max-w-lg">
                        BILOKAT — pure groundnut oil, stone-ground besan, hand-picked spices. No palm oil, no preservatives. Made by the Gupta family at Bhujia Bazaar, Bikaner, and delivered pan-India.
                      </p>
                      <div className="flex flex-wrap items-center gap-2 pt-1">
                        {[
                          ["WELCOME50", "Flat ₹50 off (1st order)"],
                          ["BILOKAT10", "10% off ₹299+"],
                          ["DIWALI15", "15% off ₹999+"],
                        ].map(([code, label]) => (
                          <span
                            key={code}
                            className="bg-white/10 hover:bg-white/15 border border-white/20 text-xs px-2.5 py-1.5 rounded-lg"
                          >
                            <span className="font-mono font-bold text-yellow-300">{code}</span>
                            <span className="text-orange-100/80"> · {label}</span>
                          </span>
                        ))}
                      </div>
                      <div className="flex flex-wrap gap-3 pt-2">
                        <a
                          href="#catalog"
                          className="px-6 py-3 bg-yellow-400 hover:bg-yellow-300 text-red-950 text-sm font-extrabold rounded-2xl shadow-lg shadow-yellow-500/20 transition-all inline-flex items-center gap-2"
                        >
                          <span>Shop Namkeen</span>
                          <ArrowRight className="w-4 h-4" />
                        </a>
                        <button
                          onClick={() => setSelectedCategory("festive-combos")}
                          className="px-6 py-3 bg-white/10 hover:bg-white/20 border border-white/25 text-white text-sm font-bold rounded-2xl transition-all"
                        >
                          Festive Hampers
                        </button>
                      </div>
                    </div>
                    <div className="relative h-64 lg:h-full min-h-[280px]">
                      <img
                        src="/images/hero-namkeen.jpg"
                        alt="BILOKAT namkeen spread"
                        className="absolute inset-0 w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-l lg:bg-gradient-to-r from-transparent via-transparent to-red-950/40 lg:from-red-950 lg:via-red-950/30 lg:to-transparent" />
                      <div className="absolute bottom-4 right-4 bg-white/95 backdrop-blur-xs rounded-2xl px-4 py-2.5 shadow-xl flex items-center gap-3">
                        <div className="w-9 h-9 rounded-xl bg-orange-100 text-orange-700 flex items-center justify-center">
                          <BadgeCheck className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="text-xs font-black text-gray-900">4.9★ · 218+ reviews</p>
                          <p className="text-[10px] text-gray-500">FSSAI Certified · No Palm Oil</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Story strip */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-4">
                  {[
                    {
                      icon: Flame,
                      title: "Fried Fresh Daily",
                      desc: "Morning batches from the Bikaner counter — nothing pre-packed or stale.",
                    },
                    {
                      icon: BadgeCheck,
                      title: "Pure Groundnut Oil",
                      desc: "Zero palm oil, zero preservatives. Desi ghee mathri made the 1985 way.",
                    },
                    {
                      icon: HandPlatter,
                      title: "Taste Guarantee",
                      desc: "Damaged or stale packet? Instant free replacement — no questions.",
                    },
                  ].map((f) => (
                    <div
                      key={f.title}
                      className="bg-white rounded-2xl border border-orange-100 p-4 flex items-start gap-3 shadow-2xs"
                    >
                      <div className="w-10 h-10 rounded-xl bg-orange-100 text-orange-700 flex items-center justify-center shrink-0">
                        <f.icon className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="text-xs font-black text-gray-900">{f.title}</h4>
                        <p className="text-[11px] text-gray-500 mt-0.5 leading-relaxed">{f.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* CATALOG */}
            <div id="catalog" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 scroll-mt-24">
              <div className="flex flex-col lg:flex-row gap-8 items-start">
                {/* Desktop filters */}
                <aside className="hidden lg:block w-64 bg-white rounded-3xl border border-orange-100 p-6 shadow-2xs sticky top-24 shrink-0">
                  <div className="flex items-center justify-between pb-3 border-b border-orange-50">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-gray-900 flex items-center gap-2">
                      <SlidersHorizontal className="w-3.5 h-3.5 text-orange-600" />
                      <span>Filters</span>
                    </h3>
                    {activeFiltersCount > 0 && (
                      <button onClick={clearAllFilters} className="text-[11px] text-rose-600 hover:underline font-semibold">
                        Reset ({activeFiltersCount})
                      </button>
                    )}
                  </div>
                  <div className="pt-4">{FiltersPanel}</div>
                </aside>

                {/* Products */}
                <div className="flex-1 w-full space-y-6">
                  <div className="bg-white rounded-2xl border border-orange-100 p-4 shadow-2xs flex flex-col sm:flex-row items-center justify-between gap-4">
                    <div className="flex items-center gap-3 w-full sm:w-auto">
                      <button
                        onClick={() => setIsMobileFiltersOpen(true)}
                        className="lg:hidden px-3.5 py-2 bg-orange-100 hover:bg-orange-200 rounded-xl text-xs font-bold text-orange-800 flex items-center gap-1.5"
                      >
                        <SlidersHorizontal className="w-3.5 h-3.5" />
                        <span>Filters {activeFiltersCount > 0 ? `(${activeFiltersCount})` : ""}</span>
                      </button>
                      <div className="text-xs text-gray-500">
                        Showing <strong className="text-gray-900">{products.length}</strong> fresh products
                      </div>
                    </div>
                    <div className="flex items-center gap-2 self-end sm:self-auto text-xs">
                      <span className="text-gray-500 font-medium">Sort by:</span>
                      <select
                        value={sortOption}
                        onChange={(e) => setSortOption(e.target.value)}
                        className="bg-orange-50/60 border border-orange-100 rounded-xl px-3 py-2 text-xs font-semibold text-gray-800 focus:bg-white focus:outline-hidden focus:border-orange-400"
                      >
                        <option value="featured">Bestsellers</option>
                        <option value="popular">Most Ordered</option>
                        <option value="price_asc">Price: Low to High</option>
                        <option value="price_desc">Price: High to Low</option>
                        <option value="rating">Highest Rated</option>
                        <option value="newest">Newest</option>
                      </select>
                    </div>
                  </div>

                  {loading ? (
                    <div className="py-24 flex flex-col items-center justify-center space-y-4">
                      <div className="w-10 h-10 border-4 border-orange-600 border-t-transparent rounded-full animate-spin" />
                      <p className="text-xs font-semibold text-gray-500">Packing fresh stock...</p>
                    </div>
                  ) : products.length === 0 ? (
                    <div className="bg-white rounded-3xl border border-orange-100 p-16 text-center space-y-4 shadow-2xs">
                      <div className="w-16 h-16 rounded-full bg-orange-50 border border-orange-100 flex items-center justify-center mx-auto text-orange-400">
                        <Search className="w-8 h-8" />
                      </div>
                      <div className="space-y-1">
                        <h3 className="text-base font-bold text-gray-900">Kuch nahi mila!</h3>
                        <p className="text-xs text-gray-500">Try another keyword — bhujia, mixture, mathri, samosa...</p>
                      </div>
                      <button
                        onClick={clearAllFilters}
                        className="px-5 py-2 bg-orange-600 text-white text-xs font-bold rounded-xl shadow-md"
                      >
                        Reset All Filters
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
                      {products.map((product) => (
                        <ProductCard
                          key={product.id}
                          product={product}
                          onSelectProduct={(p) => setSelectedProductId(p.id)}
                        />
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      <Footer
        onSellerPortalClick={() => setCurrentView("seller")}
        onAdminStudioClick={() => setCurrentView("admin")}
        onCategoryClick={(slug) => {
          setSelectedCategory(slug);
          setCurrentView("marketplace");
        }}
      />

      {/* Mobile Filters Drawer */}
      {isMobileFiltersOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div onClick={() => setIsMobileFiltersOpen(false)} className="absolute inset-0 bg-stone-950/60 backdrop-blur-xs" />
          <div className="absolute inset-y-0 left-0 w-4/5 max-w-xs bg-white shadow-2xl p-5 overflow-y-auto animate-in slide-in-from-left duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-orange-100 mb-4">
              <h3 className="text-sm font-extrabold text-gray-900 flex items-center gap-2">
                <SlidersHorizontal className="w-4 h-4 text-orange-600" />
                <span>Filters</span>
              </h3>
              <button onClick={() => setIsMobileFiltersOpen(false)} className="p-1.5 text-gray-500">
                <X className="w-5 h-5" />
              </button>
            </div>
            {FiltersPanel}
            <div className="flex gap-2 mt-6 pt-4 border-t border-orange-100">
              <button
                onClick={() => {
                  clearAllFilters();
                  setIsMobileFiltersOpen(false);
                }}
                className="flex-1 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-bold rounded-xl"
              >
                Reset
              </button>
              <button
                onClick={() => setIsMobileFiltersOpen(false)}
                className="flex-1 py-2.5 bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold rounded-xl"
              >
                Show {products.length} Items
              </button>
            </div>
          </div>
        </div>
      )}

      <CartDrawer onProceedToCheckout={() => setIsCheckoutModalOpen(true)} />
      <CheckoutModal isOpen={isCheckoutModalOpen} onClose={() => setIsCheckoutModalOpen(false)} onOrderSuccess={handleOrderSuccess} />
      {selectedProductId && (
        <ProductDetailModal productId={selectedProductId} onClose={() => setSelectedProductId(null)} />
      )}
      {trackingOrderId && (
        <OrderTrackingModal
          orderId={trackingOrderId}
          onClose={() => setTrackingOrderId(null)}
          onSelectProduct={(id) => setSelectedProductId(id)}
        />
      )}
      <AuthModal />
    </div>
  );
}
